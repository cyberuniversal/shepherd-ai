# Complete Summary

This research focuses on enabling autonomous robotic systems to interpret and execute missions specified in natural language, overcoming technical challenges in semantic reasoning and coordination. By leveraging a Large Language Model (LLM)-enabled planner, the study demonstrates a novel system where unmanned aerial and ground vehicles collaboratively achieve missions, adapting to evolving specifications. The research showcases successful task-driven navigation in diverse environments and emphasizes the importance of effective communication and coordination for heterogeneous robot teams in real-world scenarios.

## **I. INTRODUCTION**

The field of robotics often involves exploring unknown and unstructured environments, such as for infrastructure inspection, search and rescue missions, disaster response, and more. Heterogeneous teams of aerial and ground robots offer unique advantages in fast exploration tasks due to their complementary capabilities compared to teams of identical robots. For example:

- UAVs can swiftly navigate obstacle-free spaces at high altitudes, enabling high speeds and providing a bird's eye view of the area.
- High-altitude UAVs can also serve as communication nodes without obstacles and establish line-of-sight connections with ground nodes.
- However, UAVs face constraints in payload, compute power, and operation time due to size, weight, and power limitations.

On the other hand, UGVs can carry heavier payloads and operate for longer durations but have speed constraints due to planning trajectories to avoid obstacles and considering terrain traversability. Existing literature often pre-defines tasks for robots, such as UAVs localizing ground robots or generating maps. Some key points to note include:

- Prior research has focused on language-specified tasks in single-robot, small-scale, structured environments, assuming ideal conditions like perfect knowledge of the environment and seamless communications.
- The goal is to move towards a heterogeneous robotic team that can understand high-level intent from user instructions, infer subtasks, consider platform constraints, and adapt to dynamic environments for operation.

Furthermore, the need for planners that can handle dynamic mission specifications without fixed tasks on aerial or ground vehicles remains an open question. The development of robot teams that can communicate opportunistically without being limited by continuous range poses ongoing challenges in air-ground robotics. This work extends previous research on air-ground collaboration, opportunistic communication, and language-driven planning by proposing a novel language-guided air-ground teaming system, which includes the following contributions:

- Experimental validation and deployment in kilometer-scale scenarios in semi-urban and rural environments.
- Focus on creating robot teams that can communicate opportunistically and adapt to dynamic mission specifications to achieve complex tasks efficiently.

## **II. RELATED WORK A. Air-ground Robot Teaming**

Research on air-ground robot teaming has evolved over more than two decades with various applications and advancements:

- Early studies by Elfes et al. utilized robotic blimps for transmitting aerial images to ground robots, aiding in visual navigation.
- Aerial vehicles have been employed in early works for tasks like localization, tracking, and obstacle avoidance, acting as a complementary perspective to ground robots.
- Pioneering research highlighted the use of air-ground teams for mapping purposes, particularly after disasters like earthquakes, demonstrating the effectiveness in assessing damages and reducing risks for rescue personnel.
- Existing literature in air-ground robot teaming has predominantly focused on static task assignments, where roles such as providing aerial information for mapping or serving as a communication relay are predefined.
- In disaster scenarios, the collaboration between aerial and ground robots has shown promising results, showcasing the potential for effective coordination and information sharing to enhance mission outcomes.

## **B. Semantic Representations for Navigation**

Semantic planning relies on representations that combine contextual information for high-level planning and traversability details for precise control. While most existing semantic mapping research focuses on solo robot tasks, recent advancements aim to extend these capabilities to multi-robot scenarios.

**Key Points:**

- Scene graphs have emerged as a prevalent tool in semantic planning, capturing objects, topological details, and navigable areas efficiently.
- Recent innovations integrate foundation models into mapping systems to generate open-vocabulary representations, assigning semantic attributes to map entities.
- Multi-robot collaboration demands consistent reference frames between robots, which is addressed by techniques like consistent multi-robot state estimation.
- Systems like Hydra-Multi and SPOMP tackle multi-robot semantic representations by creating shared scene graphs using loop-closure detection and relative localization modules.
- To optimize communication and computation efficiency, sparse map representations are preferred, a factor considered in this work.
- The proposed approach introduces a sparse map shared by both UAV and UGV, demonstrating real-time map building by the UAV and its utilization by the UGV for successful mission execution and information augmentation.

## **Language-Specified Mission Planning**

The robotics community has been exploring the use of language for specifying tasks and missions, leveraging advancements in Large Language Models (LLMs).

**LLM-Enabled Planners:**

- LLM-enabled planners, like GPT-4, are employed in various robotics domains such as mobile manipulation, service robotics, autonomous driving, and navigation without requiring fine-tuning.
- These planners utilize pre-trained LLMs through in-context prompts, enabling channeling of common sense abilities for specific tasks.

**Implementation and Runtimes:**

- Planners are fed with behaviors like graph navigation goals, formal planning language predicates, or lower-level APIs for code generation to map out tasks during runtime.
- Environment maps, such as graphs or semantic regions, are provided at runtime for planning, with some research focusing on formal languages like Linear Temporal Logic (LTL) or Planning Domain Definition Language (PDDL).

**Advancements in Mission Planning:**

- Previous research on language-specified missions in robotics mainly dealt with well-structured environments or simulations with accurate knowledge of the surroundings.
- While traditional instructions outline subtasks and semantics, newer approaches consider underspecified missions with high-level user intent, like the SPINE planning architecture, allowing for more flexible mission definition.

## **Multi-robot Communications**

Communication in air-ground robot teams falls into three main categories:

- **Ensured Network Connectivity**:
    - Involves positioning robots to ensure continuous communication among all network nodes.
    - Key for scenarios requiring human intervention or regular reporting to a central base.
    - Limited by communication quality, especially in non-line-of-sight environments.
- **Rendezvous Approaches**:
    - Require physical meetings among robots for information exchange.
    - Alternatively, robots form continuous communication networks, allowing exploration in communication-challenging areas.
    - Effective for tasks like underground mapping in the SubT challenge but can restrict mobility with fewer robots.
- **Opportunistic Communication (MOCHA)**:
    - MOCHA technique enables large-scale exploration without communication limitations.
    - Features a gossip communication approach that enhances robot mobility.
    - Utilizes the aerial robot as a data carrier to prevent isolation of ground robots.
    - Demonstrated successful performance in large-scale simulations and real-world experiments.

This research integrates MOCHA for communication within the robot team and for the UAV's communication-aware planning, ensuring effective collaboration and mission execution.

## **Robot Teaming with Human in the Loop**

Human-in-the-loop frameworks play a crucial role in enhancing robot teaming by integrating human oversight and domain-specific tasking into multi-robot systems. The effectiveness of human-robot teaming has been extensively researched, with Novitzky et al. using the "capture the flag" game to evaluate how to task robot teammates effectively.

Key points included:

- Previous systems for robot teams with human oversight often relied on predefined tasks or semantic labels, limiting the human's ability to re-task robots dynamically during operation.
- Interface design variations have been explored, such as map interfaces for basic commands and advanced methods like virtual reality and gesture control for more sophisticated robot control.
- Compared to other interfaces, natural language interaction with robots offers greater expressiveness and allows for more decision-making by the robot system, enhancing the human-robot collaborative process.
- The system presented in this study stands out as the first one to enable human-robot teaming through natural language interaction, showcasing a unique capability in heterogeneous teaming scenarios.

## **System Overview: Mission Specification**

The system architecture and mission specification involve interaction between a human operator and autonomous unmanned ground vehicles (UGVs) and unmanned aerial vehicles (UAVs) to accomplish tasks specified in natural language:

- **Human-UGV Interaction:**
    - The human operator requests task assistance from one or more UGVs.
    - UGVs infer scene semantics for task execution and generate a list of labels for the UAV to search for.
- **UAV Contribution:**
    - The UAV creates an initial graph showing traversable regions and objects of interest.
    - This graph is incrementally shared with UGVs via MOCHA (Mobile City Hall) system.
    - UGVs can request additional labels during the mission, which are transmitted to the UAV for processing.
    - The UAV serves as a communication relay among robots and operators when required.
- **UGV Execution and Reporting:**
    - UGVs use the received graph to plan trajectories to objects of interest.
    - Discovered objects are reported back to the operator.
    - Current system supports multiple UGVs independently without coordination.
- **Enhancements and Data Sources:**
    - Partial environment graphs can be pre-generated using external data sources like satellite images to optimize mission planning.

## **System Architecture**

The system architecture overview includes various sub-components, as depicted in a figure. Key points regarding the system setup are as follows:

- The architecture utilizes a Global Navigation Satellite System (GNSS) to determine the robots' positions accurately.
- GNSS is used not only for locating the robots but also for annotating graph nodes with coordinates.
- Detailed descriptions of the sub-components are provided in Section IV of the paper.

## **Communications**

The communication setup for the collaboration between the unmanned aerial vehicle (UAV) and unmanned ground vehicle (UGV) involved the following key components and practices:

- Message transmission details are outlined in Tab. 1, providing insight into the types of messages exchanged by each robot over MOCHA, with an average message size after 10 minutes into the mission.
- Physical communication was facilitated using Rajant breadcrumb radios, serving as the underlying layer for MOCHA operations. Different radios were utilized: Rajant DX-2 and Cardinal radios for the robots, and a FE1 radio for the base station.
- The Rajant Breadcrumb API played a crucial role in monitoring link quality metrics like the received signal strength indicator (RSSI), which was essential for initiating communication exchanges between the robots.
- To support LLM API calls for SPINE, dummy ME4 nodes were strategically placed to function as communication relays. Although these nodes were inactive participants, their presence enhanced the efficiency of the opportunistic communication process.

## **IV. METHODOLOGY**

The methodology section outlines the components onboard the UAV and UGV and how they work together:

- A key aspect is the use of an openset semantic-metric map shared between the robots for efficient communication and updates to the decision maker.
- The UGVs employ a semantic-topological graph representation, where nodes are regions or objects. Regions signify traversable points in freespace, connected by edges showing obstacle-free paths, while localized objects are represented as object nodes.
- The mapping approaches for both UGV and UAV incorporate Grounding DINO to detect and include objects of interest in the map, adjusting for their visual and computational capabilities.

## **A. UAV Semantic Mapper**

The UAV Semantic Mapper module aims to create an object-centric semantic map with a common frame of reference for UAVs and UGVs to use for planning. Key points include:

- **Design and Components:** The module comprises components depicted in figures, with examples of semantic maps. It assumes road as the traversable component for UGVs but can handle other classes as needed.
- **Mission Initialization:** At the beginning of each mission, the aerial robot receives a set of labels through MOCHA and listens for images with GNSS location and orientation data from a custom GNSS/INS system.
- **Localization:** Ensuring quality aerial maps involves addressing challenges related to orientation estimation and synchronization. Techniques like GTSAM are utilized to fuse GNSS and IMU data for accurate pose estimation.
- **Object Detection:** Grounded SAM2 is employed for aerial object detection using models like Grounding DINO and SAM2, adapting to memory constraints by optionally using a smaller segmentation module, SlimSAM, for compute efficiency.
- **Graph Construction:** Object coordinates are estimated from pixel centroids, with road as the semantic class for region graph construction. Techniques like distance transforms and filtering methods are applied to ensure accurate construction of the semantic graph network.

## **UGV Semantic Mapper**

The UGV semantic mapper plays a crucial role in the system by maintaining a local occupancy map that contributes to free space exploration facilitated by the planner. Here are the key points regarding the UGV semantic mapper:

- **Input and Processing**:
    - Accepts inputs like RGB + Depth, LiDAR data, and semantic configuration.
    - Utilizes LiDAR for odometry estimation and local occupancy mapping.
    - Employs RGB+D for object detection and captioning using dedicated tools like Faster-LIO and GroundGrid.
- **Semantic Mapping Process**:
    - Constructs and updates semantic maps based on connectivity using the occupancy map.
    - Integrates a vision-language model (LLaVA) to enhance semantic information available to the planner.
- **Functionality and Performance**:
    - Detection and tracking modules operate at around 5 Hz, the vision-language model at approximately 1 Hz, and occupancy map construction exceeds 10 Hz, all functioning onboard.

Overall, the UGV semantic mapper enhances the system's capabilities by enriching semantic information, facilitating object detection, and providing crucial data for the planner's decision-making processes.

## **SPINE Planning**

In SPINE planning, the researchers configure a pre-trained Large Language Model (LLM) with components like role description, mapping interface, and behavior library description to facilitate plan generation. Here's an overview of the key points:

- **LLM Configuration**: The LLM is set up through a system prompt with distinct components for role description, mapping interface, and behavior library description.
- **Plan Generation**: SPINE generates plans by composing behaviors for navigation, active mapping, and user interaction. This involves creating a behavior sequence at each planning iteration that is validated by a separate module.
- **Chain-of-Thought Reasoning**: The LLM justifies each action sequence to ensure coherent decision-making, thereby reducing errors like hallucinations or ungrounded behavior.
- **Plan Validation**: Plans are filtered through a validation module to ensure correctness and feasibility, especially in considering constraints like traversability to enhance the robustness of planning.
- **Online Map Correction**: The system corrects prior semantic graphs online based on feedback from controllers to identify and rectify errors, such as spurious traversability edges, crucial for replanning and ensuring effective autonomy.

By leveraging the LLM for semantic mapping and plan generation, SPINE planning integrates high-level reasoning to facilitate natural language-guided missions in unknown environments effectively.

## **D. Mission Execution**

The mission execution involves a sequence of tasks performed by both the UAV and UGV in collaboration:

- The UAV initially explores the area of interest following a predefined set of waypoints to avoid unsafe regions.
- After a specific time interval, the UAV switches to search and communication modes to locate ground robots for data transmission, using the last known pose as a reference.
- Once the ground robot is located and data is transmitted, the UAV reverts to exploration mode to cover all designated waypoints.
- The UGV, equipped with the SPINE system, receives navigation subtasks from the UAV and communicates with a low-level planner. These commands guide the UGV along paths on a semantic graph for navigation, with exploration commands expanding the semantic graph.
- Navigation paths based on the semantic graph are then transmitted to the ROS Move Base controller for trajectory planning by the Jackal controller.

## **V. EXPERIMENTS**

The experiments in this study are divided into three main sets to evaluate different aspects of the system:

### **A. Aerial Autonomy Incremental Graph Construction**

- Evaluation of the incremental graph construction of the Aerial Autonomy component.
- Focus on the UAV platform, Falcon 4, controlled by PX4 firmware.
- Primary sensors include a Blackfly S RGB camera and a VectorNav IMU.

### **B. Ground Autonomy in Partially Known Environments**

- Testing the Ground Autonomy's capability to execute language-specified missions in partially known environments.
- The UGV platform, Clearpath Jackal, equipped with an AMD CPU, Nvidia GPU, LiDAR, and stereo camera.
- Use of U-blox ZED-F9P GNSS for localization and a VectorNav VN-100 for global heading corrections.

### **C. Air-Ground Teaming in Unknown Environments**

- Demonstration of air-ground teamwork in unknown environments based on language-specified missions in controlled settings.
- Experimentation done in different environments: Buckner and Range 15 for Ground Autonomy, and Pennovation for the full air-ground system.
- Environments feature dynamic elements like cars and people, along with various obstacles.

### **Platforms:**

- UAV platform: Falcon 4 with primary sensors being a Blackfly S camera and a VectorNav IMU.
- UGV platform: Clearpath Jackal with an AMD CPU, Nvidia GPU, LiDAR, and stereo camera.
- Use of U-blox ZED-F9P GNSS for localization and VectorNav VN-100 for heading corrections.

### **Environments:**

- Ground Autonomy tested in Bucker and Range 15 rural environments, each emphasizing different autonomy components.
- Full air-ground system demonstrated in Pennovation, an urban office park with diverse structures.
- Environments included various obstacles like fences, walls, and dynamic elements such as moving cars and people.

## **Aerial Mapping**

The aerial mapping experiments were designed to assess the effectiveness of the proposed method, focusing on object detection quality and map size relative to distance traveled. Key points included:

- Object Detections: The evaluation involved manually annotating desired objects in two datasets to measure the false positive rate of the detector. Notably, the labels for evaluation were specific to each dataset.
- Evaluation Results: The object detector demonstrated exceptional performance with zero-shot transfer to the data, even considering the UAV camera's viewpoint. The results were illustrated in Tab. 2.
- Qualitative Analysis: The detected objects were qualitatively evaluated, depicted in Fig. & Fig., showcasing the efficiency of the object detection module in the aerial mapping experiments.

## **Incremental Graph Construction**

The researchers showcase the efficiency of the aerial semantic graph generated by the UAV through incremental graph construction. Key points included:

- Evaluation of the constructed graph quality is demonstrated with an example overlaying the incremental semantic-metric map onto a satellite image.
- Maps generated in this method are linear in distance traveled, allowing storage of areas up to 20,000 m2 in just kilobytes.
- Compared to previous work, the size of messages transmitted between robots is significantly smaller, enhancing efficiency.
- After flying 1000 m, the size of the uncompressed graph is roughly 12 to 17 KB, in contrast to 530 to 699 KB in the semantic map image of previous methods.

## **B. Ground Autonomy**

The researchers evaluate the Unmanned Ground Vehicle (UGV) autonomy platform independently of the Unmanned Aerial Vehicle (UAV). Here's a summary of the key points included:

- **Evaluation Experiments:**
    - Designed to assess UGV autonomy in completing missions with different specifications, environments, and priors.
    - Priors are generated from registered satellite data, containing traversability info and relevant semantics but may have errors that UGV corrects online.
- **Experimental Objectives:**
    - Evaluate UGV's ability to infer navigation, exploration, and information acquisition goals from natural language instructions, reactive behavior to findings, and completion of missions accordingly.
- **Experimental Setup:**
    - Five mission specifications are considered and evaluated multiple times.
    - Priors are constructed for each environment but not tailored for specific tasks.
- **Primary Purpose of Priors:**
    - To guide the UGV away from undetectable obstacles like ditches.
- **Results and Discussion:**
    - Mission success, distance covered, and API call numbers are reported, indicating subtask steps inferred by the system.
    - Successful completion of missions S2 to S5 but two failures in S1 due to environmental scale and unexpected events.
- **Emblematic Missions:**
    - Examples include missions like checking a blocked bridge.
    - SPINE navigates to the bridge, discovers obstacles, and provides detailed descriptions using Large Language Models.
    - UGV autonomously navigates, records relevant information, and reports back to the user.
- **Mission Execution:**
    - In a specific mission, UGV traverses 1200 meters, involving all autonomy stack layers.
    - Use of active perception to rectify errors in mission specifics.
- **Active Perception:**
    - Appendix provides detailed examples of how active perception is utilized in the UGV missions.

## **Air-Ground Teaming Evaluation**

The evaluation compares the air-ground teaming system to single-UGV variants in executing language-specified missions in unfamiliar settings:

- **Baselines**:
    - **UGV w/ GT**: Uses a full map from satellite imagery for mission guidance, demonstrating the highest possible performance with the UGV's autonomy stack.
    - **UGV**: Operates without a prior map, requiring exploration to fulfill the mission, such as responding to a chemical spill by identifying relevant semantics, mapping the area, and reporting findings.
- **Mission Scenario**:
    - Involves triaging a chemical spill using the directive "triage the chemical spill 100 meters X," with X as a given location point. The system infers relevant semantics without explicit information like identifying chemical barrels.
- **Experimental Setup**:
    - Conducted multiple trials for each baseline and the system, with location priors in different directions, and results evaluated in terms of success rate, UGV travel distance, and time spent in autonomous mode.
- **Results**:
    - **UGV Performance**: Achieves 100% success with a full prior map but struggles without it, especially for long-scale exploration.
    - **System Performance**: Attains an 83.3% success rate while maintaining a comparable autonomous operation time and covering a similar travel distance as the optimally guided UGV.

The evaluation underscores the system's ability to operate effectively in unknown environments with language-specified missions, showcasing its adaptability and efficiency in collaborative air-ground missions.

## **VI. System Demonstration**

In this section, the researchers shift from controlled settings to showcase the system's capability in missions where tasks need to be inferred by the system, relying on reasoning abilities. They utilize a smaller model for generating object masks to ensure computational feasibility. The demonstrations involve two experiments conducted in the Pennovation environment, focusing on ground robots, opportunistic communication, and air-ground team behavior.

Key points included:

- The system's performance is evaluated based on total distance traveled, mission duration, human interactions, API calls, edges removed by the planner, and the percentage of autonomous operation by the UGV.
- Human-in-the-loop functionality is emphasized, with the operator continuously updating and re-tasking the robot based on real-time information.
- Metrics reported include user interactions, API calls, edges removed by the planner, and the percentage of time the UGV operated autonomously.
- Detailed results of the experiments are presented in a tabulated format for easy reference and comparison.

## **System Demonstration 1: Mapping and Inspection**

In a mission prompted by a natural language query regarding construction activity in the eastern roads, the system successfully identified relevant classes like cranes and construction signs using a language-enabled planner. Key points included:

- The UAV created a semantic graph incrementally and shared it with the UGV, which then traversed 756 meters, receiving 21 updates from a human operator who redirected the UGV based on the findings.
- The UGV operated autonomously for almost 90% of the time, with manual interventions mainly due to dynamic obstacles like buses and undetectable small obstacles such as puddles.
- Compared to UGV-only experiments, the ratio of API calls to user interactions was lower, indicating the UGV's need for occasional human operator intervention.
- Information provided by the UGV during the mission included detected objects, scene captions, and even negative details like identifying non-construction sites, enhancing the mission's effectiveness.

## **System Demonstration 2: Triaging**

The system demonstration involves a mission where a high-altitude UAV and a UGV collaborate to search for people based on user instructions:

- The user initially directs the UGV to specific coordinates to complement the UAV's flight path.
- The system categorizes relevant classes like person, tree, car, bicycle, etc., to guide the mission.
- The UAV is given the same classes to create a semantic map for the mission.
- SPINE offers understandable justifications for chosen classes, like benches and trash cans suggesting places where people may be or have left belongings.
- The UGV explores the environment with the user, providing descriptions of unexplored areas for situational awareness and planning.
- Despite accurate identification of five people, there was one false positive detection, and a person in the UGV's view was not registered by the tracker.

## **VII. Discussion, Conclusion, and Future Work**

The section wraps up by discussing the obtained results, highlighting key contributions, and suggesting future research directions:

- **Discussion and Conclusion**:
    - Results and outcomes of the study are deliberated upon.
    - The significance of the findings in the context of the research goals is emphasized.
    - An overview of the key takeaways and implications of the research is provided.
- **Key Contributions**:
    - The paper's main contributions, such as the successful collaboration between UAV and UGV in executing missions specified in natural language, are summarized.
    - The advancements in semantic reasoning, coordination strategies between heterogeneous robots, and the utilization of a Large Language Model (LLM)-enabled planner are underscored.
    - Noteworthy achievements in task-driven navigation and semantic mapping are outlined.
- **Future Work**:
    - Potential avenues for future research and development are outlined.
    - Areas that could benefit from further exploration and improvement are identified.
    - Suggestions for enhancing the current system's capabilities and addressing any limitations are presented.

## **A. Discussion**

The UGV faced challenges in estimating traversability due to difficulties in identifying negative and small positive obstacles, limiting its safe exploration areas. Examples include failure to detect a curb during system demonstrations.

- Traversability information from the UAV's semantic graph was valuable but contained false positives like buildings marked as roads, requiring online corrections by the UGV.

The safety operator intervened when false positives led the UGV through obstacles like curbs. This was notable in scenarios with lower task specificity and the use of a smaller model for generating object masks, resulting in complex trajectories for the UGV.

- Although GNSS was used for map registration between robots, the UGV relied solely on LiDAR odometry for state estimation. LiDAR odometry, while robust, experienced drift in dynamic scenes.

The LLM-enabled planner exhibited limitations in robust exploration, particularly evident in UGV-only exploration experiments, indicating a reliance on strong prior information from the UAV.

## **Conclusion**

The researchers' system demonstrates semantic inference from mission specifications, where the unmanned aerial vehicle (UAV) constructs a semantic map based on the mission requirements, which is then passed to the ground vehicle. Key points included:

- The ground vehicle utilizes a Large Language Model (LLM)-enabled planner to understand and execute subtasks essential for fulfilling the mission.
- The planner employs real-time semantic mapping to enhance and rectify the received semantic map from the UAV.
- Continuous communication between the aerial and ground vehicles occurs through intermittent updates of the map via an opportunistic communication network.
- Evaluation of the system involved testing it with seven different specifications in both urban and rural settings, successfully navigating missions spanning up to kilometer-scale distances.

## **Future Work & Open Challenges**

The authors propose several directions for future work and highlight some challenges that need to be addressed in the system:

- Onboard Language Models:
    - Currently relying on an uplink for communication with the OpenAI GPT-4o model, the system needs to explore onboard language models to reduce this dependency.
- Task Decomposition:
    - Aim to decompose main tasks into subtasks that onboard LLMs can handle, improving task efficiency and execution.
- Interface Natural Language:
    - Maintaining a natural language interface between robots allows for sparse communication, enhancing interpretability for humans involved in the process.
- Traversability Estimation:
    - Address issues with aerial image segmentation to prevent failures in UGV planning due to imperfections like localizations errors or misinterpretations of objects.
- Road Segmentation Challenges:
    - Consider the limitations of coarse traversability estimation methods based on segmenting roads, paths, and grass, as they may not be universally applicable to all robot types.
- Robot-Based Traversability:
    - Explore incorporating robot-specific traversability considerations to enhance navigation, for instance, tailoring paths for robots based on their capabilities.
- Dense Depth Image Utilization:
    - Plan to implement the use of dense depth images to identify obstacles like tree roots or potholes for robot avoidance, enhancing overall navigation safety and efficiency.
- Semantic Region Mapping:
    - Develop the capability to cluster semantically relevant objects into regions, facilitating interactive tasks such as directing the aerial robot to survey specific locations based on semantic queries.

## **ACKNOWLEDGMENTS**

The authors express gratitude to several individuals for their contributions during the field experiments conducted for this research:

- Acknowledgment of assistance from Katie Mao, Frank Gonzalez, Dexter Ong, and Kashish Garg is extended.
- Recognition of support and help from Dr. Michael Novitzky and Tyler Errico during the field experiments at USMA West Point is also noted.