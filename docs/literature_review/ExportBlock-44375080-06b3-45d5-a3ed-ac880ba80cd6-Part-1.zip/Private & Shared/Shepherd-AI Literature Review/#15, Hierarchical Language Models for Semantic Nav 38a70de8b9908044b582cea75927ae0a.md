# #15, Hierarchical Language Models for Semantic Navigation and Manipulation in an Aerial-Ground Robotic System

[Complete Summary](#15,%20Hierarchical%20Language%20Models%20for%20Semantic%20Nav/Complete%20Summary%2038a70de8b9908004bbc3f37e2baec11a.md)

- **Journal:** Published in **Advanced Intelligent Systems**. The uploaded version identifies the Version of Record DOI as **10.1002/aisy.202500640** and also appears as arXiv:2506.05020v3.
- **Year:** 2025.
- **Authors:** Haokun Liu, Zhaoqi Ma, Yunong Li, Junichiro Sugihara, Yicheng Chen, Jinjie Li, and Moju Zhao.

**Problem they are solving:** The paper asks how two very different robots—a flying drone and a quadruped ground robot—can understand a high-level natural-language instruction and cooperate to navigate, find objects, carry them, and arrange them correctly. An example instruction is: **“Assemble the word OK, but do not move the K cube.”** The system must understand that the O cube should be moved beside the K cube, determine which robot can perform each part, visually locate the objects, construct a semantic map, plan a safe route, guide the ground robot, attach to the cube, transport it, and release it in the correct position. The paper addresses a more grounded problem than systems that assume every target coordinate is already known. It includes aerial vision, semantic mapping, navigation, manipulation, disturbances, and physical robots. However, it is not a robot swarm: the experimental team consists of **one drone and one Unitree Go1 robot dog**.

## Methodology

The proposed system has three hierarchical layers: an **LLM reasoning layer**, a **VLM perception layer**, and a **motion-execution layer**.

### LLM reasoning layer

The reasoning model is **Gemini 2.0 Pro**. It receives the user instruction and a description of what each robot can do.

The drone can construct the map. The robot dog can attach to and detach from magnetic objects. The drone and robot dog can cooperate to move to a location or carry an object.

The LLM decomposes the user’s request into ordered subtasks. For “Assemble OK, but do not move K,” it produces a plan similar to:

1. Drone constructs the semantic map.
2. Drone and robot dog move to the O cube.
3. Robot dog attaches to O.
4. Both robots carry O to the correct side of K.
5. Robot dog detaches O.

The LLM does not invent arbitrary motor commands. It maps the subtasks to an existing library of motion functions, including map construction, aerial planning, ground following, attachment, and detachment.

The reasoning layer is also responsible for combining several imperfect aerial observations into one **global semantic map**. It is prompted to cross-check objects between images, remove isolated suspicious detections, resolve conflicting labels through repeated evidence, and correct objects placed unrealistically close together.

### VLM perception layer

The perception model is a fine-tuned **Gemini 2.0 Flash**. It receives bird’s-eye images from the drone and outputs structured JSON containing:

- object names;
- object coordinates;
- robot position and orientation;
- task-specific semantic roles.

Each object can be labelled as:

- **main:** the robot or object currently performing the task;
- **target:** the immediate destination;
- **landmark:** a reference object indicating front, back, left, or right;
- **obstacle:** something that should not be crossed.

The ordinary VLM had difficulty estimating exact coordinates from an image. The authors therefore introduce **GridMask**, which overlays a visible Cartesian coordinate grid on the aerial image. Instead of requiring the model to estimate continuous positions from plain pixels, it can read the object’s approximate grid location.

The grid scale is adjusted according to image resolution, camera field of view, and drone altitude. In the experiments, grid cells are usually 80 × 80 pixels. The model is fine-tuned on images containing the same grid format used during inference.

### Execution layer

The LLM does not directly control either robot. It selects pre-programmed motion functions.

The most important functions are:

- `quad_construct_map()`: the drone visits viewpoints, captures images, and builds the global semantic map;
- `quad_planning_start()`: the drone plans and follows a global route;
- `go1_following_start()`: the ground robot follows the drone using aerial semantic observations;
- `go1_attach_start()`: activates the robot dog’s magnetic attachment;
- `go1_detach_start()`: releases the carried object.

This means the model provides **task decomposition and semantic reasoning**, while conventional planners and controllers perform actual movement.

## How the drone guides the ground robot

The drone acts as the leader. It generates a global route using the semantic map and flies along that route while continuously pointing its camera downward.

The center of the drone’s camera image corresponds roughly to the drone’s projected position on the ground. The ground robot treats this center as a moving local target. It therefore follows the drone’s route even when the final cube or destination is outside the current camera view.

This solves a real limitation of purely local object-following systems. The robot dog does not need to see the final target throughout the entire trip; it follows the aerial guide until it reaches the relevant region.

**Figure 1 on page 2** is the best overview of this leader–follower mechanism. It shows the global drone route, the ground robot route, the drone’s moving bird-view frame, and the local velocity directions produced for the ground robot.

## Semantic-map construction

The drone first follows predefined map-collection viewpoints. At each point, it takes an image. The VLM converts every image into a local semantic map containing object names and positions.

The LLM then combines the local maps into one global map. This process is designed to suppress recognition mistakes. If one image says a cube is “I” but several overlapping images say it is “L,” the LLM should use the repeated label. If an object appears only once despite supposedly lying inside several camera views, it may be removed as a hallucination.

After the initial map is created, it is updated approximately every **15 seconds** during task execution.

**Figure 4 on page 6** shows the complete process: predefined aerial viewpoints → VLM-generated local maps → LLM-integrated global map → periodic image updates → revised map.

## Global path planning

The drone’s route is represented by a smooth B-spline. The start point is the robot’s current position, while the final point is the target or requested landmark.

The route optimizer balances three objectives:

- keep the path short;
- keep the path smooth;
- maintain distance from obstacles.

Once the path is optimized in grid coordinates, the GridMask scale converts it into real-world coordinates. The drone then follows the path and guides the ground robot.

The appendix states that the cost calculation scales with the number of path samples and obstacles. The experiments use fewer than 50 path samples and no more than six obstacles, so one optimization iteration normally takes approximately **0.5–2 milliseconds** on a desktop CPU.

## Ground robot’s local planner

The robot dog uses a planner inspired by the Dynamic Window Approach.

The VLM reports the positions of:

- the ground robot;
- the target or moving aerial anchor;
- obstacles and landmarks;
- the robot dog’s head, body, and tail.

These body-part coordinates provide an estimate of its orientation.

The planner creates candidate movement directions covering 360 degrees and scores each direction according to:

- progress toward the target;
- alignment with the center of the aerial view;
- obstacle clearance;
- restrictions imposed by the visible navigation window.

It selects the direction with the lowest cost, turns toward it, and moves forward or backward. This process repeats until its position and orientation are sufficiently close to the goal.

## Manipulation

The Unitree Go1 carries a servo-controlled magnet. Lettered and coloured blocks contain magnetic material.

Once the robot reaches the correct cube, the system activates the magnet. The drone then guides the robot toward the destination. The magnet is turned off once the cube reaches the required position.

The system also monitors whether the cube remains attached. If perception indicates that the object has fallen or was removed, execution rolls back to the attachment stage and tries again.

## Practical recovery mechanisms

The authors add several engineering mechanisms beyond the central LLM–VLM concept.

The drone slows down or waits when the robot dog falls behind, keeping it near the center of the camera view.

The robot chooses clockwise or counter-clockwise rotation according to nearby obstacles rather than always turning in one fixed direction.

If the carried cube is lost, the system returns to the attachment step.

If a new obstacle appears, the semantic map is updated and the global path can be recomputed.

These mechanisms provide limited closed-loop recovery without asking the high-level LLM to continuously control the robots.

## Hardware and implementation

The system uses:

- a custom SLAM-capable quadrotor;
- a Unitree Go1 quadruped;
- a servo-driven magnetic gripper;
- two Vim4 Linux computers with 8 GB RAM;
- an ELP 1080p wide-angle downward camera with a 90-degree field of view;
- wireless ROS communication;
- a Linux notebook acting as the central host;
- Google Cloud API access for Gemini 2.0 Pro and Gemini 2.0 Flash.

The drone flies at a fixed altitude of **2 metres**. Both simulation and physical experiments use a workspace of approximately **5 × 5 × 3 metres**. The blocks have an edge length of **0.3 metres**.

The measured cloud-model latencies are substantial:

| Operation | Approximate latency |
| --- | --- |
| LLM task planning | 4 seconds |
| LLM semantic-map construction | 15 seconds |
| LLM motion-function selection | 1.5 seconds |
| VLM object labelling and localization | 3 seconds |

Low-level stabilization and robot control remain onboard while the system waits for the cloud response, so the robots can stop or maintain their state during these delays.

## Experiments

The paper performs four main forms of evaluation.

### 1. GridMask VLM experiment

The researchers compare ordinary coordinate fine-tuning with GridMask-based fine-tuning.

The groups include:

- an untuned Gemini model;
- fine-tuning on 200 ordinary images;
- fine-tuning on 200 GridMask images;
- fine-tuning on 400 GridMask images;
- testing GridMask-trained models without the grid;
- testing ordinary models with a grid added.

Spatial error is measured as the Euclidean distance between the model’s estimated object location and the ground-truth position, expressed in grid units.

The main finding is that even an untuned model becomes somewhat more spatially accurate when shown the visible grid. Fine-tuning on GridMask images improves it much further.

Compared with the equally sized 200-image coordinate baseline, the 200-image GridMask model reduces localization error by **78%**. The 400-image GridMask model achieves the best reported median deviation, approximately **0.15 grid units**. Ordinary coordinate-fine-tuned models remain around 1.5–2 grid units, which is adequate for rough navigation but too inaccurate for reliable block attachment and placement.

A larger model fine-tuned using **1,000 GridMask images** is used in the later simulation and physical experiments.

The trade-off is that a GridMask-trained model performs worse if the grid is removed. It learns to depend on the artificial overlay.

**Figure 5 on page 9** gives the full localization comparison.

### 2. Zero-shot simulation experiments

The complete system is tested in Gazebo without retraining for each scene.

The first scene contains familiar letter-labelled cubes. The instruction is to move the I cube behind the U cube.

The second contains coloured cubes that were not part of the task-specific fine-tuning. The instruction is to move the blue cube to the left of the red cube.

The third mixes coloured and lettered cubes in a clustered, partially overlapping layout. The instruction is simply to move to the U cube.

The paper reports successful execution in all three demonstrations. These tests show some transfer across object names, visual categories, spatial arrangements, and task formulations. However, the paper presents them primarily as demonstrations rather than a large repeated benchmark, so they do not establish a statistically strong universal zero-shot rate.

**Figure 6 on page 10** shows the letter-block, colour-block, and clustered mixed scenes.

### 3. Target-search comparison

The system is compared with representative deep reinforcement-learning approaches on a target-search subtask.

| Method | System | One target success | One target steps | Three targets success | Three targets steps | Decision latency |
| --- | --- | --- | --- | --- | --- | --- |
| POMA, one drone | Homogeneous | 43% | 958 | 10% | 1,435 | Much less than 1 s |
| POMA, three drones | Multi-homogeneous | 81% | 539 | 43% | 903 | Much less than 1 s |
| UAV–AGV baseline | Heterogeneous | 67.6% | Not reported | Not reported | Not reported | Much less than 1 s |
| **Proposed LLM–VLM system** | Heterogeneous | **90%** | **9.5** | **80%** | **28.1** | About 3 s |

The proposed method uses a global semantic map, so it requires dramatically fewer high-level planning steps. The DRL systems react locally and therefore take hundreds of small steps.

This is not a clean head-to-head comparison. The environments, sensors, action definitions, robot types, training conditions, and step sizes differ. The authors explicitly describe the table as illustrating two operating regimes, not proving that their system universally outperforms DRL.

DRL offers sub-second reactive action. The LLM–VLM system offers slower but more semantic, globally informed reasoning.

### 4. Real-world aerial–ground experiments

Three task categories are tested, with five trials each.

**Type A — direct task:** A simple explicit instruction, such as moving the O cube to the right of K.

**Type B — reasoning task:** An instruction such as “Assemble OK, but do not move K.” The system must infer that O should be moved and on which side it belongs.

**Type C — long-horizon task:** A more complicated arrangement such as assembling the word **LOVE**, requiring several pick–transport–place operations.

| Task type | Decomposition success | Semantic-map success | Complete-task success |
| --- | --- | --- | --- |
| Type A | 100% | 80% | 80% |
| Type B | 80% | 100% | 80% |
| Type C | 100% | 80% | 80% |
| **Overall** | — | — | **80% across 15 trials** |

The three failed trials had identifiable causes:

- two failures came from incorrect global semantic maps that produced bad aerial paths;
- one came from incorrect task decomposition;
- none came from the low-level execution controllers.

The global semantic map was correct in approximately **87%** of trials.

The visual-recognition accuracy was only **74%**, mainly because rotated letter cubes could look similar. However, when an object was recognized correctly, the model assigned its semantic role correctly in **100% of 378 evaluated cases**.

The system averaged **0.68 contacts per pick–transport–place operation**. This includes small touches that did not prevent task completion. The position-error plot marks approximately **0.133 metres**, while the orientation-error plot marks approximately **0.082 radians**.

The fact that the system still succeeds despite some recognition mistakes and minor contacts shows that the hierarchy and recovery logic help, but an average of 0.68 contacts is too high for genuinely safety-critical manipulation.

**Figure 9** shows the direct, reasoning, and LOVE-assembly tasks. **Figure 10** shows the physical position and orientation error distributions.

## Robustness experiments

The authors perform three physical disturbance demonstrations.

During navigation, a human suddenly places an obstacle in the robot’s path. The drone detects the change, updates the semantic map, and produces a different route.

During attachment, a human removes the target block. The system detects that the attachment failed, rolls back, and retries.

The lighting is changed to brighter and darker conditions, and the camera field of view is reduced. The system reportedly retains enough recognition performance to finish the tasks.

**Figure 8** is worth viewing because it demonstrates the strongest part of the paper: the robots respond to actual changes rather than replaying one static trajectory.

## Main findings

The paper demonstrates that a drone can act as both a mapper and a moving semantic guide for a ground manipulator. The LLM successfully turns broad language into robot-specific subtask sequences. The VLM provides object identity, position, orientation, and semantic roles. Conventional planners convert those outputs into smooth global and local motion.

GridMask strongly improves image-coordinate prediction under the paper’s controlled setup. The hierarchy also helps isolate failures: recognition and high-level map construction may fail, but stable motion functions can still execute correctly once they receive a valid plan.

The strongest experimental results are:

- 78% localization-error reduction from GridMask at equal training-set size;
- approximately 0.15-grid-unit median error for the strongest reported VLM setting;
- 90% one-target and 80% three-target simulation search success;
- 80% full real-world task success across 15 trials;
- 87% semantic-map construction accuracy;
- 100% semantic-role accuracy once object recognition is correct;
- successful recovery from introduced obstacles and failed attachment.

## What’s new—novelty

The main novelty is the full combination of:

- LLM-based task decomposition;
- VLM-based aerial semantic perception;
- language-model-based global semantic-map integration;
- aerial global path planning;
- ground local navigation;
- real manipulation;
- physical aerial–ground cooperation.

The drone does more than take pictures. It constructs the global semantic view, plans the route, physically flies along it, and becomes a moving navigation reference for the ground robot.

The second important novelty is GridMask. Instead of modifying the VLM architecture or adding depth sensors, the method adds visible coordinate information directly to the image and fine-tunes the model to read it.

The third novelty is long-horizon semantic manipulation. The system can understand a composed goal such as forming a word rather than only navigating to one named object.

## Limitations

The evaluation is small. Only five physical trials are performed for each task category, giving 15 complete-task trials. An 80% rate from this sample is promising but not enough to establish deployment reliability.

The system uses only one drone and one ground robot. It is a heterogeneous robot team, not a scalable multi-robot or swarm system.

The environment is a controlled 5 × 5 metre indoor workspace containing large, colour-coded or letter-labelled magnetic cubes. This is much easier than a natural outdoor environment containing people, cars, vegetation, debris, irregular objects, or unknown geometry.

The drone collects the initial map using predefined viewpoints. The LLM does not decide where the drone should explore to reduce uncertainty. It therefore performs semantic map integration but not truly autonomous active exploration.

The ground robot does not possess an independent global navigation system. It depends on remaining under the drone’s camera and treating the aerial image center as its moving anchor. This requires continuous aerial visibility and stable wireless communication.

The cloud latencies are large. Map generation may take 15 seconds and VLM perception about 3 seconds. This is acceptable for slow tabletop manipulation but unsuitable for fast targets, emergency response, or rapidly changing environments.

The VLM’s 74% recognition accuracy is a major weakness. Perfect semantic-role assignment does not help when the cube itself has been identified incorrectly.

GridMask improves coordinate prediction but introduces an artificial visual dependency. A model trained heavily on the grid performs worse when the grid is absent. This may limit transfer to raw camera streams or different camera settings.

The LLM only composes pre-programmed motion functions. The claimed zero-shot adaptability applies to new combinations of known capabilities, not to the invention of new manipulation or locomotion skills.

The path planner is optimization-based and can produce poor routes in dense clutter. The paper acknowledges that perception error and path optimization can combine to increase collisions.

There is no formal verification of task decomposition, map correctness, collision freedom, or manipulation safety.

The comparison with DRL is not directly controlled. The methods use different robot teams, environments, sensing assumptions, action scales, and latency definitions.

## Research gap

Traditional aerial–ground systems often assign fixed roles: the drone maps, and the ground robot follows a predefined objective. They generally lack semantic reasoning over open-ended language.

LLM-based robot systems can decompose instructions, but many assume that perception has already produced a correct world state. VLM-based systems can identify objects, but they often lack precise coordinate understanding and long-horizon reasoning.

End-to-end VLA models integrate perception and action but are generally designed around a single robot and struggle with heterogeneous coordination and exact spatial localization.

This paper attempts to fill the intersection of those gaps by combining language reasoning, aerial semantic perception, spatial grounding, global planning, local control, and manipulation in one physical heterogeneous system.

## Future scope

The authors propose improving object recognition through stronger perception and segmentation.

They want to extend the system from its current two-dimensional semantic representation to full **3D perception and planning**.

Cloud latency could be reduced by deploying lighter models locally.

The hierarchy could be combined with end-to-end Vision–Language–Action models, including diffusion-transformer planners. The LLM would retain high-level reasoning while the learned VLA model would provide more adaptive low-level behavior.

Other necessary extensions include active aerial exploration, uncertainty-aware maps, larger robot teams, non-magnetic objects, outdoor environments, independent ground sensing, formal safety validation, and recovery from wireless or robot failure.

## Keywords

Heterogeneous multi-robot systems, aerial–ground cooperation, large language models, vision-language models, semantic navigation, semantic mapping, GridMask, task decomposition, manipulation, long-horizon planning, quadruped robot, quadrotor.

## Tools and datasets used

The work uses Gemini 2.0 Pro, a fine-tuned Gemini 2.0 Flash, Google Cloud API, GridMask-augmented custom image datasets containing 200, 400, and 1,000 examples, Gazebo, ROS, a custom quadrotor, Unitree Go1, onboard SLAM, an ELP 1080p camera, B-spline global path optimization, a DWA-inspired local planner, a servo-controlled magnetic attachment device, wireless communication, and small indoor letter- and colour-block environments.

There is no standard external benchmark dataset for the complete task. Most data and trials are generated specifically for this experimental platform.

## Performance metrics

The paper measures VLM coordinate deviation, object-recognition accuracy, semantic-label accuracy, semantic-map construction accuracy, task-decomposition accuracy, complete-task success, target-search success rate, number of planning steps, model latency, robot position error, orientation error, and contact frequency.

## How it is better—or not—than previous work

Compared with **TACOS**, this system includes genuine visual perception, map construction, manipulation, and response to physical disturbances. TACOS mostly assumes that relevant world entities and positions are already available. However, TACOS coordinates larger UAV teams, while this paper uses only one drone and one ground robot.

Compared with **GenSwarm**, this system is more perception-grounded and performs semantic manipulation. GenSwarm generates new control policies for many swarm behaviours, whereas this paper composes a small fixed set of motion functions. GenSwarm is broader in collective control; this system is deeper in perception and manipulation.

Compared with the earlier **Air–Ground Collaboration for Language-Specified Missions** paper, this system performs actual object transport and placement and has tighter real-time leader–follower cooperation. The earlier paper is substantially stronger in outdoor realism, unknown environments, kilometre-scale navigation, open-vocabulary search, intermittent communication, and field deployment.

Compared with ordinary VLA approaches, the hierarchy is easier to interpret and debug. However, it requires more engineered components, custom prompts, hand-coded motion functions, and slow cloud calls.

## Possible real-world application

The system could support indoor logistics, warehouse object movement, construction-site assistance, laboratory automation, hazardous material handling, disaster cleanup, and mixed aerial–ground inspection.

For example, a user could say:

> Find the blue container, move it beside the emergency station, but do not disturb the red container.
> 

The drone could identify the objects, create a semantic map, plan a route, and guide a ground robot that physically carries the selected object.

For Shepherd-AI, the strongest idea is the hierarchy: let the LLM decompose the mission, let aerial perception build a semantic world model, and let deterministic planners and controllers execute the movement. The major caveat is that Shepherd-AI would need far stronger perception, lower latency, explicit uncertainty, larger teams, and safety verification before this design could support real UAV missions.