# Complete Summary

This research introduces an open-source framework that merges PX4-based flight control, Robot Operating System 2 (ROS2) middleware, and locally hosted models via Ollama to facilitate natural language control of drones. Evaluating performance on both simulation and a quadcopter, the study benchmarks different Large Language Model (LLM) and Vision Language Model (VLM) families, highlighting Gemma3, Qwen2.5, and Llama-3.2 as top-performing LLMs and Gemma3, Llama3.2-Vision, and Llava1.6 as effective VLMs for autonomous flight commands and scene understanding. The work emphasizes democratizing drone control and offers accessible resources for further research and development.

## **I. INTRODUCTION**

The introduction discusses the transition to Industry 5.0, emphasizing collaboration between humans and intelligent machines in manufacturing. Key points include:

- Industry 5.0 promotes collaborative automation for optimizing production processes.
- Advances in computing and machine learning enable robots to operate autonomously and interact more intuitively.
- The Open X-Embodiment project aims to enhance robot learning with diverse datasets from various robotic embodiments.
- Human-like language comprehension enabled by Large Language Models (LLMs) like Generative Pre-trained Transformers (GPTs) facilitates natural communication with robots.
- Vision-Language Models (VLMs) combine visual and linguistic understanding, excelling in tasks like image captioning.
- The effectiveness of LLMs and VLMs in autonomous navigation, especially for UAVs, remains a research question due to unique operational challenges.
- Proposed embodied agent framework for PX4-based UAVs focuses on natural language control, integrating NVIDIA Isaac Sim and preset environments for simulation.
- The framework employs ROS2 with Ollama for different LLMs and VLMs, including Gemma, DeepSeek, Qwen, and Llama families.
- Modular tasks in the framework involve nodes like visual question-answering, path planning, and map encoding nodes to support varied functionalities.
- Overall framework architecture is illustrated in a figure.
- Contributions of the paper include introducing a ROS-based agentic framework connecting PX4 flight control with the Ollama platform.

## **A Comparative Analysis of Open-source LLMs and VLMs on Ollama for Aerial Navigation**

The authors conduct a comparative analysis of open-source Large Language Models (LLMs) and Vision Language Models (VLMs) using the Ollama framework for aerial navigation. This evaluation is carried out through simulations in Isaac Sim and real-world experiments involving a customized quadcopter.

**Key points included:**

- **Focus**: Comparison of LLMs and VLMs for aerial navigation on the Ollama platform.
- **Evaluation**: Performance assessment in both simulated environments and real-world quadcopter experiments.
- **LLMs Evaluation**: Four LLM families were benchmarked for command generation, highlighting Gemma3, Qwen2.5, Llama-3.2 as highly effective, with DeepSeek-LLM showing lower performance at 38%.
- **VLMs Evaluation**: Three VLM families were assessed for scene understanding, with Gemma3, Llama3.2-Vision, and Llava1.6 detecting objects successfully with high validity rates from 97% to 100%.
- **Mission Success Rates**: The success rates varied based on the model pairings, with the Gemma3 LLM and VLM combination achieving the highest success rate of 40%.
- **Availability**: The source code, model configurations, and prompt templates are accessible publicly for further research at [**https://github.com/limshoonkit/ros2-agent-ws**](https://github.com/limshoonkit/ros2-agent-ws).

The paper is organized as follows:

- **Section II**: Provides an overview of related work in this area.
- **Section III**: Describes the experimental setup used for the evaluation.
- **Section IV**: Presents the evaluation results and relevant discussions on the drone's guidance in searching and approaching objects.
- **Section V**: Concludes the work, summarizing findings and suggesting potential future research directions.

## **II. RELATED WORK**

The section reviews prior research in robotics focusing on task breadth and generalization challenges, especially in integrating language conditioning into deep learning models. Key points include:

- **Research Approaches**:
    - RT-1 and RT-2 used Transformer architectures, imitation learning, and web-scale pre-training for Vision-Language-Action (VLA) modeling.
    - SayCan interpreted user instructions and planned feasible steps for mobile manipulators, ensuring real-world executability.
    - SayTap introduced a language-based quadruped control interface, building on previous methods.
- **Datasets and Benchmarks**:
    - Various studies developed datasets like AerialVLN, CityNav, and others tailored for Large Language Models (LLMs) and Vision Language Models (VLMs) in UAV applications.
    - These datasets aim to simulate diverse environments and dialogues, yet face criticism for lacking validation in real-world settings.
- **Challenges and Considerations**:
    - Addressing ambiguity and variability in natural language instructions remains a challenge.
    - Practical constraints such as limited battery life, operational range, cluttered environments, and noisy sensor data are often overlooked in datasets.
- **Innovations from OpenAI and ROSA**:
    - OpenAI's ChatGPT inspired natural language-driven UAV control developments.
    - Colosseum integrated ChatGPT with PX4 autopilot using Unreal Engine 5 for realistic simulations.
    - ROSA utilized Large Language Models (LLMs) for robotic control within the ROS ecosystem, providing reasoning-action-observation capabilities.
- **Divergence in Approach**:
    - The discussed work differs in utilizing Ollama for LLM and VLM services, avoiding dependency on closed-source models, thus enabling integration with a wider array of models.

## **III. METHODOLOGY**

The experimental setup for evaluating the proposed drone control interface involves both simulated and real-world environments:

- The quadcopter setup includes:
    - NVIDIA Jetson Orin Nano Dev Kit for onboard computation
    - ZED Mini camera for visual-inertial odometry (VIO)
    - Pixhawk 6c Mini flight controller for motor control
- The physical testing area:
    - Enclosed with nylon netting and cardboard boxes as static obstacles
    - Measures 7m × 4.5m × 2.2m
- Simulation setup:
    - SITL simulations in a virtual environment using Isaac Sim
    - Simulation workstation with an NVIDIA RTX 3080Ti GPU
- Ollama model hosting:
    - Utilizes a separate workstation with an RTX 3080Ti GPU as a remote server
    - Provides linguistic reasoning capabilities to physical and simulated systems

The methodology involves the following key aspects:

- The agent guides the quadcopter from initial state to a predefined goal:
    - Generating a discrete-time trajectory while considering operational constraints
- Action space of the agent:
    - Defined by two deterministic motion primitives with limited parameter ranges
    - Contextual queries, action history, and visual observations influence the agent's decisions
- Collaboration between LLM and VLM:
    - LLM generates action commands based on contextual inputs
    - VLM assesses visual input to identify mission-relevant objects
- Operational constraints for the quadcopter:
    - Spatial boundaries and mission duration restrictions in a bounded 3D space
    - Limits on maximum allowed time steps
- Experimental episodes include:
    - Random generation of target objects and obstacles within operational boundaries
    - Quadcopter starting in the same initial location for consistency
- Mission execution involves:
    - Takeoff to a 1m altitude and transition to OFFBOARD mode
    - Embodied agent assumes autonomous control after reaching the initial height
- Mission success criteria:
    - Quadcopter locates and approaches the target within a 0.5m radius
    - Mission failure conditions include collisions, boundary violations, and exceeding time limits
- Human operator presence:
    - Acts as a safety fallback mechanism during real-world experiments
    - Can switch flight mode to POSITION mode to regain manual control in potential crash situations

## **Results and Discussion**

The study evaluated open-source Large Language Models (LLMs) including Gemma3, Qwen2.5, Llama 3.2, and DeepSeek-LLM, omitting proprietary models like ChatGPT-4 and Claude. Due to hardware constraints, not all model configurations were assessed, and internal reasoning in models was suppressed to enhance deterministic outputs. Each trial had fixed history prompts and a 20-step limit for inference.

- Evaluation focused on LLMs generating valid navigation commands like "Turn" or "Move" within specified ranges.
- Object presence detection by Vision-Language Models (VLMs) was binary for predefined classes.
- Gemma LLM-VLM pairing showed the highest 40% mission success rate.
- Command validity strongly affected mission completion; DeepSeek's low validity rate led to mission failure.

The study identified issues with suboptimal command values leading to mission failures despite valid commands and correct object detection. Variability in success rates between LLMs may not be statistically significant due to limited evaluation episodes. Observations revealed quirks in model behavior, such as repeated commands from LLMs and erratic responses from DeepSeek.

- VLM performance correlated with unobstructed camera views of target objects.
- In real-world use, Gemma was selected for its high success rate and conservative motion outputs.
- Limitations included coordinate frame transformations, limited command types, and image data format discrepancies.

Further areas for study involve system metrics analysis, impact assessments of conversational history, and few-shot examples on mission success rates, and addressing sim-to-real gaps with imaging artifacts in simulation environments.

## **V. CONCLUSION**

The researchers introduced an agentic framework leveraging the Ollama serving platform to enhance UAV control using natural language and multimodal vision comprehension. Key points included:

- The framework facilitates flexible integration of open-source Large Language Models (LLMs) and Vision Language Models (VLMs) tailored to specific mission needs.
- Despite existing challenges for real-world deployment, leading open-source models demonstrated strong potential in scene interpretation and precise execution of natural language commands.
- Enhancing VLM detection capabilities by including dedicated object detection modules like YOLO or DINO could further improve scene understanding.
- The capabilities showcased hold promise for industrial applications like inventory tracking and equipment inspection, indicating potential for future research to focus on domain-specific dataset curation and advanced techniques like Reinforcement Learning from Human Feedback (RLHF) and knowledge distillation to boost task performance.
- Developing a streamlined end-to-end Vision-Language-AV model with less than one billion parameters offers a viable route towards efficient, edge-deployable systems with reduced latency and decreased reliance on cloud infrastructure.