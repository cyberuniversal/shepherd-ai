# Complete Summary

This paper presents SkySim, a simulation framework designed to enhance the control of UAV swarms utilizing Large Language Models (LLMs). By decoupling high-level planning from low-level safety enforcement, SkySim enables safe and efficient trajectory generation based on user commands translated into spatial waypoints. Through the integration of an Artificial Potential Field (APF) safety filter, SkySim ensures collision avoidance, kinematic limits adherence, and geo-fencing, ultimately validating its accuracy, real-time collision prevention, and scalability with experiments involving different swarm sizes. This research contributes to bridging AI cognition with robotic safety, making strides towards enabling non-experts to control drone swarms dynamically in complex environments.

## **Introduction**

Unmanned Aerial Vehicle (UAV) swarms have diverse applications, yet controlling them safely and feasibly remains challenging, often requiring expert knowledge. While traditional static methods restrict adaptability, Large Language Models (LLMs) provide a new opportunity for natural language control but may lack physical grounding, leading to unsafe trajectories.

- UAV systems historically used static control methods, limiting adaptability in dynamic environments.
- Large Language Models (LLMs) present a way to translate high-level human intentions into actionable commands using natural language.
- However, LLM-generated trajectories can be unsafe as they lack real-world grounding, risking immediate failure in drone swarms.
- To address this, SkySim is introduced, a ROS2-based framework separating high-level planning from real-time safety enforcement.
- SkySim bridges the gap by allowing LLMs to control drones while ensuring safety through an Artificial Potential Field (APF) safety filter.
- The system empowers non-experts to refine swarm behaviors iteratively using natural language, without the need to consider safety or feasibility constraints.

## **Related Work**

The integration of Large Language Models (LLMs) with UAV systems allows users to issue natural language commands that can be converted into executable trajectories, overcoming limitations of traditional frameworks.

- **SwarmGPT Framework**: Introduced LLMs for drone swarm choreography, addressing safety concerns by adding an optimization-based safety filter to correct trajectories and ensure collision-free operations.
- **Challenges with SwarmGPT**: Primarily optimized for choreography smoothness rather than zero-shot spatial reasoning, essential for translating abstract commands into valid, arbitrary static geometries.
- **Emerging Strategies**: Highlight the importance of real-time reachable set generation and spatial optimization for swift, goal-oriented reconfiguration.
- **Safety Filter Considerations**: The choice of collision avoidance algorithm affects filter efficacy, where computationally intensive techniques like CNNs and DRL may introduce control loop delays.
- **Advantages of APF**: Deterministic models like Artificial Potential Fields offer lightweight, reflexive collision avoidance with minimal computational cost, complementing LLM-based planners effectively.
- **SkySim Architecture**: Aims for a "sense-plan-act" structure, where the LLM focuses on cognitive reasoning while a fast APF layer enforces real-time safety constraints, ensuring safe and agile drone operations.

## **System Architecture and Methodology**

The authors present a modular and decoupled system architecture within the Robot Operating System (ROS2 Jazzy) to enhance system stability under changing network conditions.

- The framework separates high-latency cognitive planning from low-latency real-time execution.
- The multi-layered architecture includes the Planning Layer for LLM-driven goal generation and the Control Layer for 20Hz safety enforcement.
- Fig. in the paper illustrates the asynchronous data flow between these layers, showcasing how they interact to ensure efficient and safe drone operations.

## **Command Input and State Sensing**

The process in SkySim begins with a natural language command, such as "Form a circle around the center at a 2m height", which triggers the "sense" phase. Here's how it works:

- The SkySim interface responds to the command by subscribing to the spatial coordinates of all agents through the ROS2 (/odom) topic.
- The (/odom) topic directly connects the Gazebo Simulation to the control node to mirror real-world precision, akin to systems like OptiTrack, offering a clear, instant view of the swarm's current layout, devoid of noise.

## **State-Aware LLM-based Planning**

In the context of SkySim, the approach to LLM-based planning differs from conventional methods by not directly translating text commands into specific control actions like throttle or pitch. Instead, it serves as a high-level spatial planner with the Gemini 3.5 Pro LLM from google.generativeai API.

- Unlike traditional LLM pipelines, SkySim focuses on high-level spatial planning rather than direct control mapping.
- The LLM is configured with precise system instructions at the start, specifying parameters like swarm size, coordinate system (X=forward, Y=left, Z=up), and ground-collision constraints (Z ≥ 0.5 m).
- By integrating system instructions with real-time 3D positional data of all drones and natural language inputs, a dynamic state-aware prompt is generated.
- This prompt structure ensures deterministic and physically feasible outputs for the drone swarm controller, guiding them to generate target coordinates that adhere to specified constraints.
- An illustrative example instruction for a swarm of 3 drones is provided to guide the user on the format and constraints of the input required for generating valid target coordinates.

## **Current Context**

The section introduces the context of commanding a drone swarm to "Form a triangle around the center." It also discusses how the Large Language Model (LLM) is limited to producing a configuration matrix in a specific format, validated through an Abstract Syntax Tree from a raw Python list per Eq 1.

- The LLM output format is a serialized configuration matrix presented as a raw Python list.
- Validation of this matrix format is done using Abstract Syntax Tree parsing for verification.
- The system's response to API timeouts or incorrectly formatted outputs involves maintaining the prior command's position to avoid system instability.

## **The Safety Filter and Safe Execution**

The section discusses the role of the Safety Filter in managing the "act" phase, ensuring real-time feasibility of drone trajectories. Here are the key points included:

- The Safety Filter bridges the gap between high-level LLM commands and real-time drone execution by using a single-integrator kinematic model to control the drone's velocity.
- To address collision avoidance efficiently, SkySim employs an Artificial Potential Field controller, avoiding the computational complexity of nonlinear solvers like MPC.
- The Artificial Potential Field controller operates at 20 Hz, continuously computing the velocity needed to navigate by evaluating a composite potential function.
- The controller comprises components like the Attractive Velocity, which directs the drone towards its designated waypoint using a proportional controller with a specific gain value (Kp = 1.0).

## **Repulsive Velocity (Collision Avoidance)**

The section describes a method to enforce hard safety constraints for preventing collisions between agents in a swarm. Here's a breakdown of the key points:

- When the Euclidean distance between two agents falls below a configurable safety radius of 0.8 m, a linear repulsive vector is activated to avoid collisions.
- The repulsive vector points away from the neighboring agent and is controlled by a repulsion gain factor of 2.0.
- To ensure overall system safety, a two-stage constraint protocol is used before executing commands:
    - The LLM Planner Node imposes a strict virtual geo-fence to reject any waypoints generated by the LLM that fall outside defined spatial boundaries.
        - This helps in preventing the swarm from exiting the simulated range of a motion capture system.
    - Within valid workspace areas, the kinematic limits of nano-quadrotors are enforced, and the final velocity command is capped at 0.5 m/s.
- The architecture guarantees that the swarm remains within a safe operational volume and adheres to the physical motor limits continuously.

## **Experimental Evaluation and Results**

The experimental evaluation of the SkySim framework aimed to confirm its safety, scalability, and cognitive capabilities through simulation experiments in Gazebo Harmonic Environment and ROS2 Jazzy using simulated Crazyflie 2.1 Brushless drones.

- **Experimental Setup:**
    - Conducted simulation experiments in Gazebo Harmonic Environment and ROS2 Jazzy.
    - Swarm comprised simulated Crazyflie 2.1 Brushless drones.
    - Drone positions obtained from ground truth via the ROS2 (/odom) topic in Gazebo.
- **Evaluation Metrics:**
    - **LLM Spatial Reasoning Accuracy:**
        - Focused on the accuracy of high-level planning translating to spatial waypoints.
    - **Real-time Collision Avoidance:**
        - Evaluated the system's ability to prevent collisions in real-time.
    - **System Scalability:**
        - Tested scalability by varying swarm sizes (N = 3, 10, and 30 agents).
- **Key Findings:**
    - Spatial reasoning accuracy achieved 100% across tested geometric primitives.
    - Real-time collision prevention was successful.
    - System scalability was tested by increasing swarm density with swarm sizes of 3, 10, and 30 agents.

## **Test Scenarios and Swarm Scalability**

The researchers designed three specific experimental scenarios to assess different aspects of the framework's capabilities, focusing on LLM spatial reasoning, real-time safety measures, and boundary enforcement. Here's an overview of the test scenarios and swarm scalability:

- **Experimental Scenarios:**
    - Designed three distinct scenarios to evaluate:
        - LLM spatial reasoning
        - Real-time safety
        - Boundary enforcement
- **Swarm Scalability Testing:**
    - Dynamically scaled the system across swarm sizes of 3, 10, and 30 agents
    - Aimed to evaluate:
        - Computational limits of the APF controller
        - LLM context window effectiveness
        - Scalability aspect of the framework

By conducting these tests, the researchers were able to gain insights into how well the framework performed under different swarm sizes and operational scenarios, providing valuable information on the framework's computational capabilities and scalability potential.

## **Scenario A: Geometric Formation Control (Spatial Reasoning)**

The researchers commanded a drone swarm to execute various topological tasks such as forming shapes like circles, spheres, grids, cubes, and even a Christmas tree, demonstrating high-level spatial reasoning capabilities. Here's a summary of the key points:

- **Gemini 3.5 Pro Preview:** Successfully translated abstract commands into valid spatial coordinates, achieving a 100% success rate in defining geometric primitives across different swarm sizes (from 3 to 30 drones).
- **Scalability:** The system exhibited robust scalability, generating actionable plans within approximately 50 seconds for a swarm size of 30 drones, with the APF controller effectively guiding agents to their target formations without collisions.
- **Operational Limits Evaluation:** Tested the APF controller with a medium-sized swarm (10 drones) under two collision-avoidance scenarios:
    - **Static Hazard Test:** Conducted a stress-test where all drones converged on a single point, momentarily breaching the safety distance threshold but showcasing effective repulsion forces.
    - **Dynamic Hazard Test:** Commanded drones to dynamically swap positions, causing trajectories to intersect; however, the repulsive vector fields (with a defined minimum distance) facilitated real-time avoidance of collisions.

These tests demonstrate the effectiveness of the decoupled approach in ensuring safe and successful spatial reasoning and formation control within the drone swarm.

## **Safety and Feasibility Metrics**

The researchers focused on monitoring **Minimum Inter-Agent Distance (dmin)** and **Swarm Velocity Profile** to evaluate the safety filter's performance. Specifically:

- Monitored dmin for collision verification and Swarm Velocity Profile among agent pairs during the simulation.
- Analyzed metrics during intricate formations like N=10 "Christmas Tree," N=30 "Christmas Tree" (Complex 3D), and N=30 "Star" (dense planar).
- Snapshot formations and distance profiles were presented, with the APF activation threshold at 0.8m and rdrone collision limit at ≈55mm.
- dmin dipped below the buffer during dense formations but stayed above the physical collision limit, affirming real-time safety.
- Analyzed the velocity profile of the N=10 swarm during reconfiguration for smooth trajectories.
- Peak velocity (≈0.42 m/s) in line with the defined kinematic limit (vmax = 0.5 m/s), validating physically feasible control commands.

## **Latency Analysis**

The researchers assessed the computational performance of the framework by measuring End-to-End planning latency, which is the time from issuing a command to receiving the coordinate list. Key points include:

- **Sub-Linear Scalability**:
    - As the swarm size increased by a factor of 10 (from N = 3 to N = 10), mean planning latency rose by only about 45% (from 34s to 50s).
    - This demonstrates that processing drone state data scales efficiently, allowing the system to handle larger swarms without a significant increase in processing time.
- **Decoupled Safety**:
    - Variability in planning time, especially evident at N = 30, is influenced by cloud-based probabilistic models affected by server load and network conditions.
    - Notably, the Planning Latency (seconds) remains separate from the Control Loop Latency (milliseconds), ensuring that delays in planning do not compromise the swarm's safety or stability.
- The **local safety filter** operates continuously at 20Hz to prevent planning delays from impacting the physical safety and stability of the drone swarm during the planning phase.

## **Discussion and Limitations**

The experimental results confirm SkySim's effectiveness in translating natural language into safe swarm behaviors, showing 100% success in spatial reasoning and outperforming static control libraries in adaptability and usability.

**Key points included:**

- SkySim's decoupled safety filter integration was crucial for safe drone operations, preventing collisions effectively.
- Despite successful collision prevention, there were brief dips in inter-agent distances during high-density maneuvers due to the APF's reactive nature.
- By separating high-level planning from safety enforcement, SkySim reduces risks in safety-critical scenarios, enabling non-experts to utilize complex swarm behaviors without extensive programming knowledge.
- Limitations include reliance on cloud-based inference causing latency variability, unsuitability for time-critical missions requiring millisecond-level responses, and challenges in real-world deployment due to sensor noise, communication losses, and environmental disturbances affecting precision.
- The scalability of SkySim is limited by the context window of the LLM, constraining the maximum swarm size and prompting a cap at N = 30 for validation.
- The deterministic APF controller is fast but may get stuck in local minima, especially in cluttered environments, and struggles with time-bound trajectories beyond static formations.
- The system's optimization for zero-shot static formations restricts support for continuous, time-bound trajectories, such as dynamic reconfigurations like a spinning sphere.

## **Conclusion and Future Works**

The authors introduced SkySim, a ROS2-based simulation environment facilitating natural language control with safety in drone swarms. By separating LLM reasoning from a safety filter, the study proved that even novices can direct intricate swarm formations while ensuring safety.

**Key Future Areas:**

1. **Hardware Integration:**
    - Move to physical Crazyflie 2.1 Brushless drones with OptiTrack for real-world noise analysis.
2. **Advanced Control Solvers:**
    - Explore Model Predictive Control (MPC) to handle APF limitations and dynamic constraints effectively.
3. **Multi-Modal Inputs:**
    - Integrate visual inputs and dynamic environmental cues for more adaptive swarm behavior.
4. **Edge Deployment and Optimization:**
    - Transition from cloud-based LLMs to Small Language Models (SLMs) on local hardware to reduce latency.
    - Use frameworks like Unsloth for fine-tuning models, aiming for sub-second planning to support high-speed maneuvers.