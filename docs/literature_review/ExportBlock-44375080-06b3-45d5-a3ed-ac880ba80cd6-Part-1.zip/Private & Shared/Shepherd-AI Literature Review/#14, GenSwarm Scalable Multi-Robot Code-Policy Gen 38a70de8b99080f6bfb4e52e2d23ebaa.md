# #14, GenSwarm: Scalable Multi-Robot Code-Policy Generation and Deployment via Language Models

[Complete Summary](#14,%20GenSwarm%20Scalable%20Multi-Robot%20Code-Policy%20Gen/Complete%20Summary%2038a70de8b9908096a868ed0b10b278e7.md)

- **Journal:** *npj Robotics*, a peer-reviewed Nature Portfolio journal; Volume 4, Article 5. DOI: 10.1038/s44182-025-00065-w.
- **Year:** 2026.
- **Authors:** Wenkang Ji, Huaben Chen, Mingyang Chen, Guobin Zhu, Lufeng Xu, Roderich Groß, Rui Zhou, Ming Cao, and Shiyu Zhao.

**Problem they are solving:** Developing a new multi-robot behavior normally requires an expert to interpret the mission, choose a control architecture, design mathematical objectives or algorithms, write code, test it in simulation, correct failures, configure every robot, and deploy the software. When the task changes, much of that process must be repeated. GenSwarm attempts to automate the entire development pipeline. A user describes a desired collective behavior in natural language, and a group of LLM agents extracts the requirements, designs the control structure, generates Python control policies, checks and repairs the code, tests it in simulation, obtains feedback from a VLM or human, and automatically deploys the resulting policy and software environment onto physical robots. This is not primarily a conversational mission-management system like TACOS or Swarm-Steward. It is closer to an **AI software engineer that generates a new swarm controller from scratch and deploys it to the robots**.

**What the paper is actually doing:** GenSwarm does not keep an LLM onboard every robot making decisions continuously. The LLMs are used during the development stage to produce ordinary executable Python code. That code is then uploaded and runs in real time on the robots without repeatedly calling the LLM. This is called the **code-policy paradigm**. Its advantages are that the final behavior is inspectable, reproducible, computationally lightweight, and suitable for inexpensive robots. The disadvantage is that the deployed policy is largely fixed after generation; adapting it normally requires generating, correcting, and redeploying code again.

## Methodology

GenSwarm contains three main modules: **task analysis**, **code generation**, and **code deployment and improvement**.

### 1. Task-analysis module

The system begins with a natural-language description. For the encircling demonstration, the instruction says that predator robots should surround a moving prey, distribute themselves evenly on a circle with radius one metre, and continuously adjust their positions as the prey moves.

A first LLM agent extracts a **constraint pool**. Each constraint states something the controller must accomplish or avoid, such as:

- remain near the required circular position;
- maintain distance from other robots and obstacles;
- follow a moving target;
- respect velocity limits;
- update commands in real time.

A second LLM agent derives a set of **skills** from those constraints. Each skill will become a Python function. At this stage, only the function name, purpose, inputs, and description are generated—not the function body.

The system divides skills into two categories:

- **Global skills** use fleet-wide information and execute on the central control station. An example is assigning each robot a unique angular position around a target.
- **Local skills** execute independently onboard each robot using only locally available information. Examples include calculating a desired velocity, moving toward a target, checking whether the target has been reached, and avoiding nearby robots.

This means the LLM is not forced to use one coordination architecture for every mission. It decides whether a task should use purely distributed control or a hybrid of one-time centralized coordination followed by distributed execution. Aggregation and flocking are usually handled using local distributed rules. Shaping, crossing, coverage, and encircling may need a global assignment stage before local execution.

### 2. Code-generation module

The system creates a **skill graph** describing:

- which skills depend on which other skills;
- which skills are low-level or high-level;
- which constraints apply to each skill;
- the order in which functions should be generated.

Low-level functions are generated first. Higher-level functions then call those lower-level skills. This improves code reuse and means that an error in one primitive function can be corrected once rather than duplicated throughout the controller.

Several LLM agents participate in code creation:

1. A function-specification agent defines the function’s name, parameters, return value, and purpose.
2. A function-writing agent generates the Python body.
3. A reviewing agent checks whether the code satisfies the relevant constraints.
4. A static linter checks syntax and basic program errors.
5. A debugging LLM receives the linter’s error report and repairs the code.
6. The process repeats until the function passes the required checks.

For example, in the encircling task, the system initially generated a function call with a missing `repulsion_strength` argument. The linter detected the mismatch, and the debugging agent added the parameter. **Figure 4 on page 6** shows this complete process—from user instruction and constraints to the skill graph, generated functions, bug detection, simulation, VLM feedback, human feedback, and physical execution.

### 3. Deployment and improvement module

After passing the review and static checks, the generated policy is deployed in simulation. The simulator records the execution as a video. A VLM critic watches that video and judges whether the swarm satisfies the requested behavior and constraints.

The VLM can provide feedback such as:

- the robots failed to form the requested shape;
- separation was insufficient;
- the target was not surrounded;
- movement did not converge;
- an obstacle was hit.

The code-generation system can then modify the responsible function and rerun the simulation.

A human may also provide natural-language feedback. For example:

> The one-metre encircling radius appears too large; use 0.8 metres.
> 

The LLM modifies the relevant function parameter, and the updated controller is redeployed. This makes correction much faster than manually locating and editing the source code, although the complete adjustment still takes minutes rather than occurring inside the real-time control loop.

**Figure 1 on page 3** is the most important architecture diagram. It shows the constraint pool at the center, task analysis on the left, hierarchical code generation below, and simulation, VLM feedback, human feedback, and physical deployment on the right.

## Software deployment architecture

GenSwarm automates not only code delivery but also installation of the runtime environment.

A control station connects to every robot over Wi-Fi and SSH using **Ansible**. Predefined Ansible Playbooks instruct the robots to install and configure Docker. Each robot then pulls two Docker images:

- a ROS container containing the robot-operation environment;
- a Python container containing the generated controller.

After the environments are ready, the generated code is transmitted and executed onboard.

The authors report that installing the complete runtime environment across the robots takes approximately **two minutes**, while distributing generated code takes only several seconds. Because Ansible performs operations concurrently, the authors characterize deployment time as approximately constant rather than increasing linearly for every added robot. When the Docker environments are already installed, updated code can be sent in a few seconds.

**Figure 2 on page 4** shows this architecture and physical demonstrations of crossing, encircling, and bridging.

## Physical robot platform

The real platform consists of small omnidirectional ground robots using mecanum wheels. Each robot contains its own onboard computer, control board, motors, battery, communication hardware, and lighting system. The platform provides one-click startup, one-click sleep, and wireless experiment-data retrieval.

The robots do **not** have onboard cameras or independent environmental perception. An indoor motion-capture system measures the positions of the robots, target, and obstacles. Those measurements are sent through an **MQTT coordination server**. The server restricts the information delivered to each robot so that a local controller receives only itself and nearby entities rather than the complete world state.

The local sensing API has a fixed range of **one metre** in the experiments. The motion API clamps velocity commands to a specified maximum, with prompt examples stating a maximum speed of **0.5 m/s**. These API restrictions provide a basic physical safety boundary even if generated code requests excessive sensing or movement.

The authors introduce artificial measurement noise into the motion-capture state. Performance declines as noise increases but remains relatively stable under low and moderate noise. Exact robustness values appear in the supplementary material.

**Figure 3 on page 5** shows the robot’s hardware, assembled swarm, motion-capture environment, MQTT network, control station, global allocator, and onboard local controllers.

## End-to-end encircling example

The paper explains GenSwarm through a predator–prey mission. The prey moves unpredictably, while the predator robots must surround it evenly at the requested radius.

The system extracts six constraints, including target positioning, distance maintenance, collision avoidance, velocity control, position accuracy, and real-time adaptation. It creates six skills. One global skill allocates initial angles around the circle. The remaining skills run locally, including velocity updating, target navigation, target-position calculation, completion checking, and collision avoidance.

The system generates and reviews the functions, detects a missing function argument, repairs it, runs the controller in simulation, records the result, and receives a successful assessment from the VLM. The same controller is then automatically deployed on the physical swarm.

The reported approximate times for this complete workflow are:

- **six minutes** for policy generation;
- **two minutes** for physical deployment;
- **two minutes** for a human-feedback modification.

This is rapid compared with conventional manual development but is not real-time replanning.

## Experimental tasks

GenSwarm is tested on ten collective behaviors:

| Task | What the robots must do |
| --- | --- |
| **Aggregation** | Gather into one compact group while avoiding collisions. |
| **Flocking** | Move cohesively with aligned motion while maintaining separation. |
| **Shaping** | Form and maintain a specified geometric shape. |
| **Encircling** | Surround and follow a moving prey at a fixed radius. |
| **Crossing** | Swap or travel to distant target positions while avoiding robots and obstacles. |
| **Coverage** | Spread across the environment so the area is evenly covered. |
| **Exploration** | Divide and visit all unknown landmark regions. |
| **Pursuing** | Flock toward and follow an unpredictably moving leader or prey. |
| **Bridging** | Form an evenly spaced straight line across a specified region. |
| **Clustering** | Divide into groups based on initial location and move to corresponding regions. |

**Figure 5 on page 7** shows time sequences for all ten tasks. It is worth viewing because it demonstrates that the generated outputs are not merely XML or high-level plans: they create actual continuous collective motion in simulation.

## Task-specific evaluation metrics

A generated policy counts as successful only when every metric associated with the task crosses its predefined threshold.

**Aggregation:** The paper measures the largest distance between any robot and its nearest neighbor. Success requires every robot to be within one metre of another robot.

**Flocking:** It measures how spatially spread out the swarm is and how similar all robot trajectories are using Dynamic Time Warping. Success requires low positional variance and a mean trajectory-alignment score below the selected threshold.

**Shaping:** Procrustes distance compares final robot positions with the desired shape while allowing the best assignment between robots and target slots. Success requires a distance below 0.1.

**Encircling:** The mean absolute difference between every predator’s distance from the prey and the desired radius must be below 0.1 metres.

**Crossing:** Every robot must reach its assigned target within approximately 0.1 metres. The success ratio must equal 100%, while the instruction requires at least 15 centimetres of separation from robots and obstacles.

**Coverage:** The bounding area occupied by the robots must cover more than 80% of the environment, and the variance in nearest-neighbor distances must remain below 0.1 so robots are not concentrated in one portion of the space.

**Exploration:** Every designated unexplored landmark must be visited.

**Pursuing:** The swarm’s average position must remain within one metre of the prey, while the robots must also remain sufficiently cohesive.

**Bridging:** The final robot arrangement must match the requested straight line with a Procrustes distance below 0.1.

**Clustering:** Every robot must reach the region associated with its initial quadrant.

These metrics are used only after execution to score performance. They are **not provided to the policy-generating LLM as an optimization objective**, which reduces the chance that the model merely writes code targeted directly at the evaluator.

## Experimental procedure

For the ten-task evaluation, the authors use **o1-mini**. They perform 100 independent end-to-end trials per task, beginning with the natural-language instruction and ending with code execution in simulation. This gives:

- 10 tasks;
- 100 trials per task;
- **1,000 total trials**.

The average success rate is **81%**. This means that, in 81% of trials, the generated code successfully passed generation and execution and satisfied all task-specific thresholds.

## Baseline comparison

The authors compare GenSwarm against:

- **Code as Policies**, or CaP;
- **MetaGPT**, a general multi-agent software-development framework;
- **LLM2Swarm**, an earlier language-to-swarm-policy method;
- GenSwarm with the VLM feedback stage removed.

Six representative tasks are selected. Every method is run 100 times on every task, producing **2,400 trials**. GPT-4o is used for this comparison.

| Method | Average success rate |
| --- | --- |
| **GenSwarm** | **74%** |
| GenSwarm without VLM feedback | 71% |
| Code as Policies | 40% |
| LLM2Swarm | 40% |
| MetaGPT | 37% |

GenSwarm therefore exceeds CaP and LLM2Swarm by 34 percentage points and MetaGPT by 37 points.

The VLM feedback stage improves the average only from 71% to 74%. It contributes measurable value, but most of GenSwarm’s advantage comes from the full constraint–skill–code-generation architecture rather than video criticism alone.

**Figure 6 on page 8** shows the ten-task performance and the six-task baseline comparison.

## Comparison with expert controllers

The supplementary evaluation also compares GenSwarm with manually designed or fine-tuned expert controllers:

- **Boids** for distributed flocking and aggregation;
- **Hungarian assignment plus VR-ORCA** for shaping, crossing, coverage, and encircling.

These specialized controllers achieve better average task performance than GenSwarm. The best GenSwarm policies are competitive on some tasks, but the paper does **not** demonstrate that LLM-generated policies outperform mature controllers.

GenSwarm’s advantage is instead breadth and development speed. One framework can produce controllers for many tasks without a human separately implementing every algorithm. Expert controllers remain preferable when reliability, efficiency, or optimality on one known task is the primary concern.

## Different language models

The main experiments use o1-mini and GPT-4o. The authors additionally evaluate DeepSeek-V3 and Claude 3.7 Sonnet. All produce relatively high success rates, suggesting that the pipeline is not dependent on a single model.

The LLMs and VLMs are used out of the box without fine-tuning. Each agent is given a system prompt describing:

- its role;
- the two-dimensional environment;
- robot properties;
- available APIs;
- the distinction between local and global information;
- physical limits.

This is zero-shot in the sense that GenSwarm does not require demonstration examples of each new task. It still depends heavily on detailed system prompts, API documentation, and sometimes policy information supplied by the user.

## Prompt experiment

The authors test seven instruction styles:

1. coherent objective and policy;
2. directly concatenated objective and policy;
3. objective only;
4. policy only;
5. informal narrative;
6. structured objective;
7. structured objective plus policy.

Results show that **including the policy is more important than whether the language is formally structured**.

| Prompt type | Success |
| --- | --- |
| Coherent objective + policy | **78%** |
| Concatenated objective + policy | 74% |
| Policy only | 74% |
| Structured policy | 74% |
| Objective only | 56% |
| Informal narrative | 57% |
| Structured objective only | 57% |

This result is important when interpreting the paper’s natural-language claim. GenSwarm performs best when the user explains not only the desired outcome but also something about **how the controller should work**. For example, the flocking instruction explicitly tells the system to use cohesion, alignment, and separation. A vague request such as “make the robots flock” is more likely to fail.

## Main findings

GenSwarm demonstrates that a team of specialized LLM agents can automate much of the process of producing a multi-robot controller. Decomposing the process into constraint extraction, skill design, hierarchical function generation, code review, static checking, simulation, feedback, and deployment works substantially better than asking one model to generate a complete controller in one pass.

The system can generate both decentralized and hybrid centralized–distributed controllers. It can run generated policies onboard resource-constrained robots because the LLM is removed from the real-time execution loop. It also automates deployment of the supporting ROS and Python environments, which is a practical contribution often ignored by language-based robotics papers.

Its reported 81% average success across 1,000 end-to-end trials is strong for automated code generation. Nevertheless, almost one in five generations still fails, and specialized controllers outperform it on average.

## What’s new—novelty

The principal novelty is the combination of **policy generation and physical deployment**. Many earlier systems stop after producing code or validating it in simulation. GenSwarm installs the runtime environment, transfers the generated controller, and executes it onboard a physical multi-robot platform.

A second novelty is the hierarchical multi-agent code-generation process. Instead of one LLM writing one large script, GenSwarm constructs a constraint pool, skill library, local/global skill graph, individual function specifications, reviewed function bodies, and corrected executable code.

A third contribution is automatic selection between distributed and hybrid control. The system can recognize that flocking may use local neighbor rules while formation shaping requires initial global target assignment.

A fourth contribution is multimodal correction: execution can be reviewed through simulation video by a VLM and adjusted through human-language feedback.

## Limitations

The paper focuses on collective control, not perception-driven missions. The robots do not identify cars, people, suspects, fires, or unknown objects. They do not build a map from cameras or reason from uncertain visual evidence. The paper explicitly states that sensing and navigation are not included in the system’s present scope.

The physical robots have no onboard perception. Their states are measured by a motion-capture system and distributed through MQTT. Although each robot receives only local information, that information originates from accurate global infrastructure. A field swarm without motion capture would require onboard cameras, LiDAR, localization, tracking, and communication software that the paper does not implement.

The ten tasks are canonical swarm-control benchmarks rather than complete operational missions. Aggregation, flocking, encircling, crossing, and shaping test whether a controller produces the desired movement pattern. Even exploration uses predefined landmarks rather than semantic discovery in an unknown environment.

The system generates ordinary Python. LLM review and linting can detect syntax errors and some constraint violations, but they do not formally prove safety, convergence, stability, deadlock freedom, or correctness. A program can pass a linter and still produce dangerous motion.

The APIs enforce local perception range and velocity limits, but they do not guarantee collision avoidance or mission correctness. Safety largely depends on whether the generated controller correctly implements the extracted constraints.

Adaptation is not truly online. A VLM or human can identify a failure, but the controller must then be modified and redeployed. The reported correction process takes around two minutes. This is useful for rapid development but cannot replace millisecond-level failure recovery during an active mission.

The claim of zero-shot generality should be interpreted carefully. No task demonstrations are needed, but success improves strongly when the instruction includes explicit policy advice. The model is often being told concepts such as cohesion, alignment, separation, goal assignment, or the desired coverage strategy.

The physical evaluations validate deployment and selected behaviors but do not provide the same large-scale repeated success statistics as the simulation study. Communication loss, robot dropout, low battery, heterogeneous capabilities, outdoor operation, adversarial disturbances, and large physical swarms are not comprehensively tested.

The authors’ success thresholds are handcrafted for each task. Because the policies are evaluated against fixed benchmark definitions, performance may not transfer directly to missions with different geometry, scale, speed, or safety margins.

## Research gap

Previous automated swarm-design techniques generally require experts to manually create objective functions before evolutionary optimization or search can begin. Earlier LLM methods often generate policies only for one task, require demonstration examples, produce only high-level symbolic plans, or stop at simulation.

GenSwarm fills the gap between natural-language specification and actual physical deployment. It attempts to automate the complete software-development process rather than only translating language into one action or one plan.

However, the larger research gap remains: generating verified, perception-grounded, adaptive controllers for robots operating in unknown and dynamic physical environments.

## Future scope

The authors identify three principal directions.

First, GenSwarm should integrate real onboard sensing and navigation so the robots can perceive their surroundings without motion capture.

Second, generated controllers should become more sophisticated and closer to optimal. The authors suggest combining LLM code generation with multi-agent reinforcement learning, which may discover stronger policies than language models alone.

Third, GenSwarm currently generates every policy from scratch. A future system could maintain a reusable library of previously generated and validated behaviors, retrieving and adapting existing skills instead of rebuilding them for every request.

Additional important extensions would include formal safety verification, automatic tests, runtime monitors, robot-failure recovery, heterogeneous robot capabilities, communication-loss handling, battery-aware behavior, versioned policy rollback, and deployment on aerial robots.

## Keywords

Multi-robot systems, robotic swarms, large language models, code policies, automatic controller generation, multi-agent code generation, distributed control, centralized coordination, human-in-the-loop programming, simulation-to-real deployment, swarm robotics.

## Tools and platforms used

The system uses o1-mini, GPT-4o, DeepSeek-V3, Claude 3.7 Sonnet, a VLM critic, Python, ROS, Docker, Ansible, Ansible Playbooks, Wi-Fi, SSH, MQTT, an indoor motion-capture system, custom mecanum-wheel ground robots, a Python linter, and a custom simulation and deployment framework. Boids, Hungarian assignment, and VR-ORCA are used as expert-controller comparisons. No task-specific LLM fine-tuning or conventional training dataset is used.

The authors provide the framework, prompts, APIs, examples, and benchmark configurations through an open-source code repository.

## Performance metrics

The overall metric is task success: every task-specific score must cross its threshold. The individual metrics include nearest-neighbor distance, position variance, Dynamic Time Warping trajectory similarity, Procrustes shape distance, encircling-radius error, target reach ratio, occupied-area ratio, nearest-neighbor-spacing variance, landmark visit ratio, target-following distance, and clustering achievement ratio.

The major headline figures are:

- **81%** average success across 1,000 ten-task trials;
- **74%** average success in the six-task GPT-4o comparison;
- **71%** without VLM feedback;
- **40%** for CaP;
- **40%** for LLM2Swarm;
- **37%** for MetaGPT;
- approximately six minutes for code generation;
- approximately two minutes for deployment;
- approximately two minutes for feedback-based modification.

## How it is better—or not—than previous work

GenSwarm is more complete than PROGPROMPT and Code as Policies because it does not merely generate robot functions; it analyzes constraints, constructs a hierarchy of skills, reviews and debugs the code, evaluates it in simulation, and deploys it automatically onto multiple physical robots.

It is more general than formation-only systems because the same pipeline produces aggregation, flocking, coverage, exploration, pursuit, crossing, bridging, clustering, and formation controllers. It is more physically demonstrated than CommandSwarm, whose generated behavior trees remain in simulation.

Compared with TACOS and Swarm-Steward, however, GenSwarm solves a different problem. TACOS and Swarm-Steward maintain live mission state and issue trusted predefined actions. GenSwarm writes an entirely new low-level policy before execution. This gives it greater flexibility in creating novel collective behavior, but also introduces much greater verification risk.

It is less operationally realistic than the air–ground collaboration paper because it lacks onboard perception, unknown-world mapping, semantic object discovery, and field deployment. Its robots know nearby state through motion capture rather than their own sensors.

It does not outperform hand-designed expert controllers on average. Its advantage is reducing development effort and adapting to new task definitions, not achieving the strongest possible control performance.

## Possible real-world application

GenSwarm could accelerate development of robot fleets for warehouses, factories, crop monitoring, inventory movement, inspection, environmental sampling, transportation, and disaster-response research. An engineer could describe a new collective behavior and receive a tested initial controller within minutes rather than designing everything from scratch.

For Shepherd-AI, GenSwarm is useful as a potential **offline controller-generation layer**. Shepherd-AI could decide that a mission requires a new behavior—such as surrounding a moving target, forming a communication bridge, or spreading into a search pattern—and GenSwarm could generate and test that controller. It should not directly replace Shepherd-AI’s mission planner, safety layer, or real-time supervisor. Before use with UAVs, generated code would need formal validation, strong simulation testing, deterministic runtime safety constraints, operator approval, and a trusted fallback controller.