# #5, Leveraging Large Language Models for Real-Time UAV Control

[Complete Summary](#5,%20Leveraging%20Large%20Language%20Models%20for%20Real-Time/Complete%20Summary%2038570de8b990805f8da1d61f43ac4311.md)

- **Journal:** *Electronics*, an MDPI peer-reviewed journal.
- **Year:** 2025.
- **Authors:** Kheireddine Choutri, Samiha Fadloun, Ayoub Khettabi, Mohand Lagha, Souham Meshoul, and Raouf Fareh.

## **Problem they are solving:**

The paper tries to make drone control easier for non-specialists by replacing joysticks and rigid command menus with spoken English and Arabic. A user should be able to say something like “take off, rise one metre, then perform a left flip,” including Arabic–English code-switching, and have the system convert that speech into executable commands for a Parrot Mambo quadcopter. The main problems are recognizing speech quickly without requiring constant internet access, understanding variations or missing parameters in natural language, rejecting irrelevant speech, translating the command into working Python code, and preventing the LLM from generating unsafe flight behavior. This is a **single-drone voice-command paper**, not a swarm-coordination, search, tracking, perception, or high-level autonomous mission-planning paper.

## **Methodology:**

The proposed system is a five-stage pipeline: continuous audio capture, bilingual speech recognition, LLM-based intent extraction, LLM-generated Python code with safety validation, and execution on the drone. Audio is recorded at 16 kHz in mono, 16-bit format and divided into 100 ms frames. A queue separates recording from recognition so audio capture continues while earlier frames are being processed. The system filters silence using frame energy, suppresses noise, applies a 300–3400 Hz band-pass filter, and extracts MFCC speech features.

Two lightweight Vosk recognizers operate in parallel: one for English and one for Arabic. Each model is approximately 40–50 MB. Their outputs are compared using confidence scores and script detection. The Arabic recognizer uses morphological tokenization to handle clitics and inflected word forms, while the English recognizer uses a compact bigram language model. The paper reports more than 95% recognition accuracy for short drone-related utterances lasting under two seconds.

The selected transcript is sent through a two-pass LLM process. The first LLM determines the language, translates Arabic to English, removes duplicate recognizer outputs, extracts the intended actions, and infers omitted parameters. For example, “go higher” may become a default 0.5-metre ascent. A mixed command can be separated into several sequential actions. The second LLM turns the structured intent into Python code using the `pyparrot` interface. The generated code is executed inside a sandbox so malformed code does not crash the full system.

## **Safety architecture:**

Before execution, the system checks whether the generated action satisfies predefined operating limits. The accepted altitude is between 0.1 and 2.5 metres, vertical speed is limited to 0.5 metres per second, and normal execution requires at least 20% battery. If battery falls below 15%, the system overrides the user and initiates landing. Safety state is checked at 10 Hz. If a proposed action violates the limits, the framework may reduce the requested altitude, delay the command, or give a verbal warning.

However, the Parrot Mambo does not have a proper obstacle-avoidance system. The paper’s claim of “collision avoidance” is therefore limited mainly to detecting proximity to the ground using ultrasonic and inertial measurements. It cannot reliably see or avoid walls, people, trees, or other aerial objects. If telemetry indicates execution failure or loss of control, the drone enters hover and the system resets.

## **Execution hardware:**

The physical platform is a Parrot Mambo connected over its proprietary Wi-Fi link to a workstation with an Intel i7 processor, 16 GB RAM, and an NVIDIA GTX GPU. The drone uses an IMU, accelerometer, gyroscope, and ultrasonic altitude sensor. The paper states that inertial data are processed at 200 Hz and ultrasonic measurements at 10 Hz. The actual autonomous hardware demonstration uses Gemini because it offered free API access and relatively low latency.

## **Important cloud/offline clarification:**

The paper repeatedly describes the system as offline, including statements in the introduction and conclusion claiming fully offline operation. That is not accurate for the implemented system. Vosk speech recognition, audio handling, command validation, and drone execution are local, but the LLM reasoning and code-generation stages use remote Gemini, GPT, and DeepSeek APIs. The methodology correctly calls it an **edge–cloud hybrid architecture**. Therefore, the demonstrated system still requires cloud connectivity for its central semantic reasoning and code generation.

## **Experiments:**

The evaluation consists mainly of representative voice-command case studies and expert review of LLM-generated Python scripts. The four command categories are: valid English or Arabic instructions; invalid conversational inputs such as “Hello, how are you today?”; fully Arabic flight commands; and mixed Arabic–English commands. The system successfully decomposes valid multi-action requests, ignores irrelevant speech, and keeps the drone grounded when no valid command is found.

One demonstrated command is “Take off, go up one metre, do a left flip, then sleep.” Gemini turns this into a sequence of Python calls, and the Parrot Mambo performs the actions. Other examples change the altitude, replace the final action, use Arabic wording, or combine Arabic and English. The paper presents videos and image sequences of these demonstrations.

Three LLM families are compared: GPT, Gemini, and DeepSeek. The paper refers to them rather loosely as GPT 3, Gemini 4, and DeepSeek 3 in one section, without providing consistently precise model versions. Gemini is used for the actual flight demonstration, while much of the three-model comparison is based on generated code reviewed by experts rather than every model independently flying the drone.

## **Expert evaluation procedure:**

Three reviewers—two aeronautical-engineering specialists and one computer scientist—score the generated code. The rubric weights code structure at 20%, safety at 25%, error handling at 15%, movement precision at 15%, connection reliability at 15%, and documentation clarity at 10%. The paper reports Cohen’s kappa of 0.82, indicating strong agreement among reviewers.

## **Main findings:**

The complete speech-to-action pipeline reportedly reaches approximately 95% speech-recognition accuracy and 300–500 ms end-to-end latency. The system can understand short English, Arabic, and code-switched commands, reject obvious noncommands, infer simple missing values, generate Python, and control a real Parrot Mambo.

The model comparison produces a clear trade-off:

| Model | Main strength | Main weakness |
| --- | --- | --- |
| GPT | Best safety structure, connection checks, exception handling, emergency-stop logic | Conservative movement; some parameter-count errors |
| Gemini | Most precise distance-based movement through `move_relative()` | Incorrect import/API usage can prevent execution |
| DeepSeek | Clear documentation, multilingual and educational presentation | Invents nonexistent methods and lacks essential safety handling |

GPT generates the most production-oriented code. It uses a structured main function, checks connection and takeoff success, exits if connection fails, catches interruptions, and includes emergency behavior. Gemini generates more precise metre-based movement but makes a basic import error, showing that precise-looking code can still be unusable. DeepSeek writes readable and multilingual demonstrations but sometimes invents API functions and includes no meaningful emergency procedures.

## **Failure-tolerance results:**

GPT has the lowest reported unsafe-code rate at 3%, a critical-error rate of 2%, average recovery time of 0.7 seconds, and one emergency landing. Gemini records 8% unsafe code, 5% critical errors, 1.2-second recovery, and two emergency landings. DeepSeek performs worst, with 15% unsafe code, 9% critical errors, 1.8-second recovery, and four emergency landings. The paper combines unsafe generations and critical errors into a failure-tolerance score, where a higher score means fewer failures.

## **Novelty:**

The main novelty is the combination of English–Arabic offline speech recognition with an LLM-based two-pass interpretation and code-generation pipeline for a real quadcopter. Earlier voice-control systems were often English-only, used predefined keywords, or depended fully on cloud speech recognition. This system processes audio locally, supports code-switching, rejects irrelevant conversational input, validates generated actions against drone-specific operating limits, and runs the accepted code in a sandbox. The paper also compares the safety and coding behavior of several LLMs rather than only showing that one model can generate a command.

## **Limitations:**

This paper has several major limitations. It controls one toy-sized indoor quadcopter and evaluates only short, predefined flight primitives such as takeoff, ascent, forward motion, flipping, landing, and sleeping. It does not perform autonomous navigation, object detection, mapping, path planning, target search, moving-target tracking, or swarm coordination. The user remains responsible for deciding what action should happen; the LLM mainly translates speech into API code.

The system generates and executes Python at runtime, which creates a larger safety risk than selecting from a fixed set of trusted actions. The safety layer catches some numerical violations, but it does not formally verify arbitrary generated programs. The drone lacks obstacle-perception hardware, so the paper’s safety system cannot provide real environmental collision avoidance.

The empirical evaluation is limited. The authors explicitly state that the goal is feasibility rather than large-scale statistical benchmarking. The paper does not clearly report how many spoken commands, speakers, accents, noise conditions, or repeated physical trials were used to calculate the 95% recognition figure and the failure rates. It also does not provide a conventional confusion matrix, word-error rate broken down by language, confidence intervals, or statistical significance.

The comparison of GPT, Gemini, and DeepSeek is partly subjective because experts review code quality. Different model versions are not always specified clearly, and API models can change over time. Gemini’s demonstrated import error raises questions about how generated code was corrected before physical execution. The paper also claims “fully offline” operation even though it acknowledges using cloud LLM APIs.

The claimed 300–500 ms total latency is surprisingly low for two sequential cloud LLM calls plus speech recognition, code generation, safety checking, and execution. The paper does not provide a stage-by-stage latency breakdown, network conditions, sample count, or latency distribution, so the number is difficult to assess independently.

## **Research gap:**

Previous voice-driven UAV systems often rely on rigid command grammars, English-only inputs, or online speech services. Other LLM–UAV systems focus on visual navigation, high-level planning, or direct language-to-action mapping without carefully addressing bilingual speech, code-switching, or safety checks on generated code. This paper attempts to fill the narrow gap of a bilingual spoken interface that works with a physical drone and combines local speech recognition with more flexible semantic interpretation.

The remaining gap is much larger: creating a genuinely autonomous system that can understand goals rather than merely commands, perceive the environment, plan safe trajectories, reason under uncertainty, and execute through verified control primitives rather than arbitrary generated code.

## **Future scope:**

The authors propose expanding support for Arabic dialects and phonetic variation, reducing latency below 200 ms, and creating stronger benchmarks for linguistic coverage and system responsiveness. They also propose visual feedback so the UAV can combine speech with camera observations, eventually using multimodal LLMs for perception-driven control. Other suggested directions include richer sensory inputs, better embedded inference, and more adaptive interaction.

A stronger future architecture would replace runtime Python generation with a deterministic API or intermediate representation, run the reasoning model locally, evaluate real word-error rates across speakers and dialects, add obstacle perception, compare against a rule-based baseline, and test commands that depend on state and environmental feedback.

## **Keywords:**

Multilingual control, English–Arabic speech recognition, speech-to-text, large language models, human–drone interaction, natural-language processing, code-switching, voice-controlled UAV, safety validation, Parrot Mambo.

## **Tools/dataset used:**

Vosk English and Arabic speech models, Gemini, GPT, DeepSeek, Python 3.13, `sounddevice`, `queue.Queue`, MFCC feature extraction, `pyparrot` version 1.6.2, Parrot Mambo firmware 2.1.0, Wi-Fi communication, sandboxed Python execution, IMU and ultrasonic telemetry. The paper does not release a clearly defined evaluation dataset; it says data are available from the authors on request.

## **Performance metrics:**

Speech-recognition accuracy, end-to-end latency, expert-scored code structure, safety mechanisms, error handling, movement precision, connection reliability, documentation quality, unsafe-code rate, critical-error rate, recovery time, emergency-landing count, and the combined failure-tolerance metric. The headline figures are approximately 95% speech recognition and 300–500 ms latency, while GPT achieves the best reported safety metrics.

## **How it is better—or not—than previous work:**

It improves on rule-based voice systems by accepting more natural phrasing, Arabic, and mixed-language commands. It offers greater privacy and resilience than cloud speech recognition because Vosk runs locally. It is more safety-aware than systems that directly execute unrestricted language-model output, and it demonstrates physical control instead of simulation alone.

However, it is much less capable than the swarm and agent papers you read earlier. It does not plan missions, maintain a world model, interpret camera observations, coordinate multiple UAVs, adapt tasks after failures, or perform meaningful closed-loop autonomy. Compared with TACOS or Swarm-Steward, this is essentially a **bilingual voice-to-Python-command translator for one Parrot Mambo**. Its main research value is accessibility and multilingual human–drone interaction, not intelligent autonomous planning.

## **Possible real-world application:**

The intended applications are simple hands-free drone control in indoor inspection, education, training, basic photography, and situations where an operator needs to issue short commands without using a joystick. Arabic-speaking users could operate a drone using familiar language or code-switching. In its current form, it is not suitable for search and rescue, surveillance, industrial autonomy, or safety-critical operations because it lacks perception, robust obstacle avoidance, verified planning, and dependable offline reasoning.