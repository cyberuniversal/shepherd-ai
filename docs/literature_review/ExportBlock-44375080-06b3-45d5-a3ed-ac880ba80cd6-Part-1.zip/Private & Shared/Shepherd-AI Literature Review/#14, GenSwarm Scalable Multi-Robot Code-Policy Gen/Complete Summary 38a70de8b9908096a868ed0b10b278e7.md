# Complete Summary

GenSwarm introduces an innovative approach using large language models to automatically generate and implement control policies for multi-robot systems based on user instructions in natural language. This system enables zero-shot learning, rapid task adaptation, and strong reproducibility. By offering an instruction-to-execution functionality, GenSwarm paves the way for transforming the development process of multi-robot systems, addressing the limitations of manual crafting and enhancing scalability for both simulated and real-world applications. This advancement holds significant promise for various industries, potentially revolutionizing multi-robot system development paradigms.

## **Overview of GenSwarm**

The pipeline of GenSwarm comprises three key modules:

- **Task analysis**
    - Involves user input in natural language detailing the desired multi-robot task.
    - Constraints are extracted from the user instructions to form a constraint pool, guiding subsequent steps.
    - Constraints dictate robot actions like reaching a location or avoiding collisions.
- **Code generation**
    - Skills library is generated based on constraints, where each skill corresponds to a Python function.
    - Skills are classified as global (for coordination) or local (executed onboard each robot).
    - Code is generated hierarchically, ensuring lower-level skills are defined before higher-level skills for code reusability.
- **Code deployment and improvement**
    - Automatic deployment on simulated and real-world robotic platforms.
    - Utilizes feedback mechanisms to adjust policies based on execution results, including automatic video-based feedback assessment.
    - Incorporates human feedback interface for efficient policy modifications.

The GenSwarm system also:

- **Structural Decision**
    - Automatically determines if global or local skills are needed based on task requirements.
    - Guides code generation and deployment structure accordingly.
- **Global-Local Control**
    - Enables automatic determination and implementation of global-local control structures.
    - Decides whether centralized global coordination or local distributed execution is needed for task completion.
    - Guides the deployment model based on the task's requirements, ensuring efficient execution on both global and local levels.

## **Software and Hardware Platform**

The automatic deployment of control policies in multi-robot systems faces challenges due to the complex runtime environments. Manually configuring these environments on each robot is inefficient, especially for large-scale systems.

- GenSwarm introduces a software framework capable of deploying code and runtime environments across all robots rapidly, taking only seconds for code deployment and about two minutes for runtime environment deployment.
- The framework's control station generates code based on a specified pipeline and connects with robots using Ansible via WiFi and SSH.
- Predefined Playbook scripts automate tasks like Docker environment setup on each robot, followed by pulling ROS and Python environment Docker images for execution.
- The framework relies on Ansible and Docker integration to simplify and speed up code deployment, ensuring repeatability and efficiency.
- The software architecture is designed to be portable across various hardware platforms, leveraging a modular design for flexibility.
- The hardware framework includes a new multi-robot platform with computational, control, and communication resources on each ground robot for autonomous deployment and execution.
- Novel features like one-click operations and wireless data retrieval reduce experimental costs and optimize multi-robot operations.
- Emulated robot perception collects motion information via an indoor positioning system, distributing relevant data through an MQTT server for individual robot awareness.
- The control policies access necessary information through APIs with hardcoded physical limitations, like fixed perception radius and limited velocity commands.
- Future advancements may include onboard vision systems for sensing APIs, with real-world experiments showcasing the system's robustness to varying levels of measurement noise.
- Despite performance degradation with increased noise, the system remains stable for low to moderate noise levels, as demonstrated in supplementary figures.

## **Demonstration of GenSwarm**

The demonstration showcases the workflow of GenSwarm in generating control policies for multi-robot tasks, using the example of "predator-prey encircling":

- **Constraints Generation**: Six constraints are generated from user instructions by an LLM agent, like "Collision Avoidance" ensuring safe distances.
- **Skills Generation**: Six skills, both global and local, are created based on constraints, with the global skill handling initial goal assignments.
- **Control Structures**: GenSwarm selects control structures ranging from distributed to hybrid centralized coordination based on task requirements.
- **Code Generation**: LLM agents create and review main-body code for each skill function, correcting errors before deployment.
- **Feedback Loop**: VLM agents review simulation executions, providing feedback for code improvement.
- **Human-in-the-loop Adjustment**: Human feedback can be integrated for adjusting policies to adapt to new situations.
- **Deployment on Real Robots**: Generated code is deployed on real robots with onboard resources for autonomous execution.
- **Efficiency and Cost-Effectiveness**: GenSwarm offers efficient deployment with cost-saving features like one-click functions and wireless data retrieval.
- **Simulation Environment**: Perception emulation is used as robots lack onboard vision; information is shared via a coordination server.
- **Performance Evaluation**: GenSwarm is evaluated on ten multi-robot tasks, achieving an average success rate of 81% over 1,000 trials.

The performance of GenSwarm is compared with state-of-the-art methods, showcasing its superior success rates and adaptability across tasks:

- GenSwarm achieves an average success rate of 74%, outperforming other methods significantly.
- Different LLMs and prompts influence outcomes, with structured prompts containing policy instructions yielding the highest success rates.
- The ability of GenSwarm to handle various prompt types and generate effective control policies demonstrates its versatility and efficacy in automating control policy generation for multi-robot systems.

## **Discussion**

The work introduces GenSwarm, an innovative system that automates the creation and implementation of code policies for diverse multi-robot tasks. This approach marks a significant advancement towards entirely automated policy generation, potentially revolutionizing the current multi-robot system development processes.

### **Key Points:**

- GenSwarm's focus on decision-making and control overlooks crucial aspects like sensing and navigation, vital for practical applications.
- Future research directions could involve integrating onboard sensing to enhance the system's capabilities.
- The current emphasis on system generality and automation leaves room for enhancing the sophistication and optimality of the generated policies and collective behaviors.
- Future research may explore more advanced or optimal policy generation methods, which might require augmenting language models with techniques like multi-agent reinforcement learning.
- Utilizing reinforcement learning alongside language models could enhance GenSwarm's ability to generate complex policies effectively.
- While GenSwarm currently creates policies from scratch for zero-shot learning, reusing pre-existing solutions could be explored as an avenue for further research.

## **Methods**

The researchers considered ten multi-robot tasks in their work, including aggregation, flocking, shaping, encircling, crossing, coverage, exploration, pursuing, bridging, and clustering. Each task comes with user instructions and specific evaluation metrics. Here are some key points about the methods:

- **Task Success Evaluation:** The success of a task is determined based on predefined thresholds set for its evaluation metrics. A task is deemed successful only if all its corresponding metrics surpass these predefined thresholds.
- **Simulation Trial Termination:** A simulation trial ends either when the execution time exceeds set limits or when the task is completed, such as when all robots reach their designated positions.

### **Aggregation Task**

- **User Instruction:** The instruction for this task is for the robots to aggregate quickly while avoiding collisions with one another.
- **Evaluation Metric:** The success of the aggregation task is measured using the metric "Maximum of minimum distances" (denoted as d maxmin), which calculates the largest minimum distance between each robot and its closest neighbor. The task succeeds if this metric's value is less than 1.

### **Flocking Task**

- **User Instruction:** In the flocking task, robots are required to form a cohesive flock by exhibiting behaviors like cohesion, alignment, and separation to avoid collisions and maintain connectivity.
- **Evaluation Metrics:** The flocking task's success is evaluated based on two metrics:
    1. **Spatial Variance (Var spat):** quantifies the spread of robots. Success is achieved when this metric is less than 1.
    2. **Mean Dynamic Time Warping (DTW) Distance (d DTW):** measures the similarity between robot trajectories. Success requires surpassing a predefined threshold for this metric.

## **DTW (Dynamic Time Warping)**

Dynamic Time Warping (DTW) involves aligning two sequences, T i and T j, ensuring a valid alignment with constraints like boundary, continuity, and monotonicity, where the Euclidean distance function d( ⋅ , ⋅ ) is applied.

- Success criterion: DTW metric < 500 for 1,000-point trajectories indicates an average distance < 0.5 between corresponding points.

### **Shaping Task**

- User instruction: Robots form a specific shape with unique assigned points and maintain positions.
- Evaluation: Procrustes Distance (d proc) measures similarity between robot positions and target shape.
- Success criterion: d proc < 0.1 signifies successful task completion.

### **Encircling Task**

- User instruction: Robots encircle a target prey on a 1-radius circle, adjusting positions based on prey movement.
- Evaluation: Mean distance error (d error) measures average deviation from desired radius.
- Success criterion: d error < 0.1 indicates task success.

### **Crossing Task**

- User instruction: Robots maintain a safe distance while moving to the farthest robot's initial position.
- Evaluation: Target Reach Ratio (ρ reach) assesses the proportion of robots reaching targets within a tolerance distance.
- Success criterion: ρ reach = 1 denotes successful task accomplishment.

### **Coverage Task**

- User instruction: Robots divide the environment into sections and move to assigned centers.
- Evaluation metrics: Area Ratio (ρ area) and Variance of Nearest Neighbor Distances (Var NND).
- Success criteria: ρ area > 0.8 and Var NND < 0.1 for task success.

### **Exploration Task**

- User instruction: Robots explore all unknown areas with an optimal sequence of exploration.
- Evaluation metric: Landmark Visit Ratio (ρ visit) calculates the proportion of visited landmarks.
- Success criterion: ρ visit = 1 indicates successful task completion.

### **Pursuing Task**

- User instruction: Robots flock towards a lead robot with cohesion, alignment, separation, and obstacle avoidance.
- Evaluation metrics: Average distance to prey and Maximum of minimum distances.
- Success criteria: d avg-prey < 1 and d maxmin < 1 signify task success.

### **Bridging Task**

- User instruction: Robots form a straight line bridge at y=0 within the range of y [-2, 2].
- Evaluation: Procrustes distance (d proc) measuring similarity with the target line.
- Success criterion: d proc < 0.1 indicates successful task completion.

### **Clustering Task**

- User instruction: Robots in the same quadrant cluster in designated areas.
- Evaluation: Achievement Ratio (r achieve) assessing the proportion of robots reaching target regions.
- Success criterion: r achieve = 1 signifies successful completion for all robots.

## **Details of Software Architecture**

The software architecture comprises seven core modules, each with multiple classes, designed for flexibility and modularity:

- **Core Module:** Defines interfaces for seamless integration of modules, utilizing classes like BaseActionNode, ActionNode, and CompositeActionNode to simplify system complexity.
- **Skill Module:** Manages skill library operations, representing skills as a skill graph and enabling construction, modification, and extension of the graph.
- **Action Module:** Contains action nodes for tasks like code analysis, function design, syntax checks, and debugging guided by interactions with the Large Language Model (LLM).
- **Environment Module:** Covers simulation environments or real-world scenarios; Constraint Module handles related tasks; File Module manages file storage; and Feedback Module processes feedback.
- The architecture's core functionality is in the Core Module, providing shared interfaces and core functionality to other modules.
- Interfaces like Feedback, BaseFile, and BaseEnvironment ensure standardized handling of HumanFeedback, file types, and simulation environments respectively.
- The architecture uses the Composite Pattern, unifying individual and composite skills handling, making it easier to build complex skill structures.
- It supports both simulation and real-world platforms, offering a unified access point across different environments.
- Key Features:
    - **Scalability:** Generic interfaces and base classes enable easy introduction or replacement of functional modules, maintaining system stability.
    - **Composite Pattern:** Organizes skills into tree-like structures for unified handling of individual and composite skills.
    - **Platform Support:** Accommodates both simulation and real-world platforms with a unified access point.

## **Details of Automatic Deployment**

The automatic deployment framework integrates Ansible and Docker to streamline the process of deploying control policies on multi-robot systems:

- **Ansible**:
    - Open-source automation tool for consistent task execution across multiple devices.
    - Establishes secure wireless connections with robots via SSH and executes predefined playbooks-scripts for deployment.
    - Ensures uniform tasks like directory creation, source code copying, dependency installation, and permission setting on all robots simultaneously.
- **Docker Environment**:
    - Contains components essential for seamless robot operation and code execution.
    - Includes ROS for managing robotic systems and a preconfigured Python runtime with all necessary dependencies for executing LLM-generated code.
- **Deployment Process**:
    - Ansible transfers essential files (Python scripts, ROS configuration files, Dockerfiles) to each robot.
    - Uses Docker to build Docker image packaging the runtime environment and dependencies, reducing setup time with prebuilt images.
    - Launches containers, initializes robot-specific workspace, compiles code for ROS compatibility, and executes LLM-generated code via ROS launch files for automatic operation.

**Copyright Information**:

- The article is under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
- Allows non-commercial use, sharing, distribution, and reproduction with appropriate credit to the original authors and source.
- Prohibits sharing adapted material or parts of the article without permission.
- Images or third-party material follow the same license, unless specified otherwise.