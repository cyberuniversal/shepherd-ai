# Complete Summary

This paper focuses on utilizing large language models (LLMs) to enhance task planning by scoring potential actions and generating action sequences solely from natural language instructions without additional domain knowledge, aiming to overcome the traditional challenge of defining extensive domain information. The authors introduce a programmatic LLM prompt structure that facilitates plan generation across varied environments, robot capabilities, and tasks by providing action and object specifications along with example programs for execution. Through ablation experiments, the study offers insights into prompt structuring and generation constraints, achieving state-of-the-art success rates in VirtualHome household tasks and successfully deploying the method on a physical robot arm for tabletop tasks, showcasing its practical significance in robotic task planning.

## **I. INTRODUCTION**

Everyday household tasks involve a mix of common-sense knowledge about the world and specific details about the current environment.

- Task planning for activities like "Make dinner" requires an understanding of logical sequences of actions, object affordances (like using a stove for heating), and the relevance of actions to the task.
- Autoregressive large language models (LLMs) have been used to generate action plans for robotic task planning by either scoring or generating new steps directly.
- LLMs can evaluate possible actions from a predefined space, for example, for a task like "Make dinner," actions could include "pick up the chicken", "pick up the soda", etc.
- A challenge in LLM-based task planning is the lack of real-time feedback from the environment, as high-level instructions like "Make dinner" do not provide specific world state information.
- The introduction of PROGPROMPT improves LLM-based robot task planning by incorporating programming language structures, leveraging the LLMs' training on diverse web content, including programming tutorials.
- PROGPROMPT presents a Pythonic program header to import actions and their parameters, list environment objects, and define sequences of actions within functions.
- Situational state feedback is integrated by specifying preconditions in plans (like proximity to the fridge before opening it) and handling failed conditions with recovery actions.
- Including natural language comments in PROGPROMPT programs improves the success of generated plans by explaining the goals of upcoming actions.
- PROGPROMPT structures include import statements, object lists, example tasks, actions as function calls with objects as arguments, assertions with recovery steps, and execution demonstrations.

## **II. BACKGROUND AND RELATED WORK**

Task planning in robotics often involves utilizing search within a predefined domain, where unconditional search can be challenging in environments with numerous feasible actions and objects due to high branching factors. To address this, heuristics are commonly employed to guide the search process.

### **Task Planning Formulation:**

- Task planning can be structured as the tuple O, P, A, T, I, G, t:
    - O represents all objects in the environment.
    - P denotes object properties informing object affordances.
    - A consists of executable actions that change based on the current environment state.
    - T signifies the transition model, I and G are initial and goal states, and t is a high-level task description provided to the agent.

### **Planning with Large Language Models (LLMs):**

- Large Language Models (LLMs) are neural networks with numerous parameters trained on unsupervised objectives like next-token prediction or masked language modeling.
- Autoregressive LLMs are trained to predict token sequences conditioned on input sequences.
- These models, when prompted appropriately, can generate text useful for robot task planning, showcasing multitask generalization capabilities.

### **Prompt Design Challenges:**

- Designing prompts for LLMs in task planning is intricate due to the lack of paired instructions with executable plans or robot action sequences.
- The prompting process involves a function to transform input states into textual prompts and an answer search strategy wherein the LLM generates text outputs or scores predefined options.
- Existing works have explored generating open-domain plans using LLMs but face issues with ensuring generated actions are executable in the current environment.

### **Advances in Prompt Generation:**

- The presented method employs a programming language-inspired prompt generator that informs LLMs about the situated environment state and available robot actions, ensuring compatibility with robot actions.
- Compared to other approaches like SAYCAN and INNERMONOLOGUE, this method leverages programming language features in prompts to generate entire, executable plan programs directly.

## **III. OUR METHOD: PROGPROMPT**

The authors represent robot plans as pythonic programs within their method called Progprompt. By structuring prompts as pythonic code and utilizing a Large Language Model (LLM), they facilitate the completion of the code for generating robot task plans.

**Key points:**

- Robot plans are represented as pythonic programs in the Progprompt method.
- The prompts are structured as pythonic code to guide the LLM in completing the code.
- Features available in Python are used to construct prompts that prompt the LLM to generate robot task plans based on natural language instructions.

## **A. Representing Robot Plans as Pythonic Functions**

The authors describe representing robot plans as Pythonic functions, which include API calls to action primitives, comments summarizing actions, and assertions to track execution. Here are the key points from this section:

- **Plan Function Structure**:
    - Plan functions involve API calls to action primitives with object arguments, creating structured tasks like "put salmon in the microwave."
    - Comments within the code provide natural language summaries for sequences of actions, breaking down tasks into logical subtasks.
    - Comments like "# grab salmon" and "# put salmon in microwave" help in partitioning tasks for better understanding and planning.
- **Benefits of Comments**:
    - Comments help the large language model (LLM) express knowledge about tasks and sub-tasks in natural language, facilitating planning.
    - They inform the LLM about immediate goals, reducing the chances of incoherent or repetitive outputs.
    - Previous studies have shown the effectiveness of intermediate summaries (like comments) in enhancing LLM performance across various tasks.
    - Empirical verification confirms the usefulness of comments in aiding plan generation.
- **Use of Assertions**:
    - Assertions act as an environment feedback mechanism to ensure preconditions are met and facilitate error recovery.
    - For instance, assertions check if the agent is close to the salmon before the "grab(salmon)" action, leading to executing "find(salmon)" if needed.
    - Experimental results demonstrate the benefits of assert statements in plan generation.

This section emphasizes structuring robot plans in a way that leverages comments and assertions to guide the LLM in generating coherent and effective action sequences.

## **B. Constructing Programming Language Prompts**

The authors inform the large language model (LLM) about the environment and primitive actions using prompt construction, including examples of sample tasks and plans, similar to few-shot LLM prompting techniques.

- The prompt function **`f_prompt`** outlined in Fig. generates a Pythonic prompt by incorporating observations, action primitives, and examples for the LLM to complete, enabling the prediction of the next executable task as a function.
- In the example task of "microwave salmon," the LLM may suggest actions like "take out(salmon, grocery bag)," but the executing agent may lack the corresponding primitive action.
- To guide the LLM about the agent's action primitives available, Pythonic import statements are provided, restricting the LLM's output to feasible functions within the current context.
- By listing the set of functions and objects accessible to the model, the prompting scheme ensures that generated plans involve actions achievable by the agent and objects present in the environment.
- Objects available in the environment are also presented as a list of strings to address scenarios where certain objects like a "grocery bag" may not exist, aiding the LLM in generating contextually appropriate plans.
- PROGPROMPT includes example tasks that serve as fully executable program plans, illustrating how to accomplish tasks using available actions and objects in the environment.
- These examples highlight the correlation between task names, actions to be taken, and the constraints on actions and objects to be utilized, assisting the LLM in understanding task specifications effectively.

## **Task Plan Generation and Execution**

In the task plan generation and execution process, the large language model (LLM) infers the task based on the PROGPROMPT prompt provided. Here's how this is accomplished:

- **Plan Generation**:
    - The LLM generates plans for the task.
    - Plans can be executed either on a virtual agent or a physical robot system.
- **Execution**:
    - An interpreter is used to execute each action command from the generated plan in the environment.
    - Assertion checking is carried out in a closed-loop manner during execution.
    - This checking provides feedback on the current state of the environment to ensure successful plan execution.

This section highlights how the LLM-driven task planning is seamlessly translated into actions that are executed in either a virtual or physical environment, with real-time feedback mechanisms in place for ensuring plan coherence and effectiveness.

## **IV. EXPERIMENTS**

The authors evaluate their method through experiments conducted in two settings:

- The first setting involves a virtual household environment.
- The second setting includes experiments carried out on a physical robot manipulator.

These experiments aim to assess the performance and applicability of the proposed method in both simulated and real-world scenarios.

## **A. Simulation Experiments**

The experimental setup involves evaluating the method in the Virtual Home (VH) Environment, a simulation platform mimicking household activities. Key points included:

- VH states consist of objects (O) and properties (P) with encoded information like object locations and agent interactions.
- The action space comprises essential actions like grab, putin, putback, walk, find, open, close, switchon, switchoff, sit, and standup.
- Three VH environments were tested, each housing 115 unique object instances with varied properties and semantic states.
- Tasks are framed with instructions such as "microwave salmon," leading to the creation of a dataset with task sequences and symbolic goal conditions.
- Environment state feedback is integrated during program execution, with VH providing observations through state graphs.
- Object information from the state graph is used to prompt the LLM to verify assertions about object-state relationships and actions.

## **B. Real-Robot Experiments**

The real-robot experiments section details the utilization of a Franka-Emika Panda robot with a parallel-jaw gripper for the study. Some key points include:

- The experiments involve leveraging a pick-and-place policy that operates based on pointcloud inputs of a target object and container, executing pick-and-place actions accordingly.
- Implementation of the policy utilizes a specific system and tools like MPPI for motion generation, SceneCollisionNet for collision avoidance, and Contact-GraspNet for generating grasp poses.
- Importantly, the PROGPROMPT system incorporates an import statement for actions like grab and putin(obj1, obj2), utilizing ViLD for object detection to create a list of available objects.
- In the real environment, each plan function has a local object list, unlike the global variable used in virtual environments, enhancing adaptability to new objects.
- The plan generated by the LLM consists of function calls like grab and putin(obj1, obj2), with obj1 and obj2 represented as text strings mapped to pointclouds using ViLD segmentation masks and depth images.
- Real-world uncertainties lead to the exclusion of assert-based closed loop options in the tabletop plans to account for unpredictability.

## **Evaluation Metrics**

The evaluation of system performance in this study is based on three key metrics:

- **Success Rate (SR)**:
    - SR is determined as the fraction of executions that successfully achieve all task-relevant goal-conditions.
- **Goal Conditions Recall (GCR)**:
    - GCR evaluates how well the system recalls the goal conditions.
        - It involves comparing the ground truth final state conditions with the final state achieved through the generated plan.
        - Calculated as the set difference between the two final states divided by the number of task-specific goal-conditions.
        - SR is equal to 1 only if GCR is also equal to 1.
- **Executability (Exec)**:
    - Exec calculates the fraction of actions in the plan that are executable in the environment, irrespective of their relevance to the task.

These metrics provide insights into the system's success in achieving task-specific goals, recalling goal conditions accurately, and ensuring the executability of planned actions.

## **Results**

PROGPROMPT effectively utilizes Large Language Models (LLMs) to guide task planners in virtual and physical agent tasks.

- The approach efficiently prompts LLM-based task planners for both virtual environment and physical robot arm tasks.
- By employing programmatic LLM prompt structures, PROGPROMPT demonstrates successful integration with different environments, robot capabilities, and task requirements.
- The method showcases high success rates in executing household tasks in the VirtualHome environment, highlighting its effectiveness in practical applications.
- PROGPROMPT extends its application to physical robot arm tasks, emphasizing its versatility and real-world implementation capabilities.

## **A. Virtual Experiment Results**

In the Virtual Experiment Results section, the researchers summarize the performance of their task planning and execution system in the VirtualHome environment using a GPT3-based language model. Here are the key findings and insights from the experiments:

- The system outperforms prior work significantly across all metrics in the VirtualHome environment, showcasing the effectiveness of using PROGPROMPT with large language model backbones.
- Variability in performance across runs is attributed to sampling the output of the language model, with 3 Pythonic task plan examples provided per prompt.
- The experiment compares the performance of different models, showing that CODEX, a GPT3 variant trained on programming language data, surpasses GPT3 but has limitations in query speed.
- DAVINCI, another GPT3 variant with shorter prompt length constraints, underperforms compared to the base GPT3, possibly due to fewer task examples available for training.
- The benefits of using a program-like prompt structure for LLM-based task planning are highlighted, with the suggestion that further fine-tuning on programming language data can enhance performance.
- Ablation experiments on PROGPROMPT reveal the importance of feedback mechanisms and comments in the prompt code to improve performance metrics significantly.
- Comparison with an alternative prompt generation method called LANGPROMPT, which uses natural language descriptions instead of program-like structures, shows the value of programming language structure for task planning and execution.
- Evaluation in new VirtualHome environments demonstrates PROGPROMPT's ability to adapt to different scenarios by inferring object references based on context, showcasing its flexibility and generalizability.

Additionally, the research team fine-tunes GPT2 to create a policy mapping generated action sequences to executable actions, achieving reasonable partial success but not matching the performance of program executability metrics. Task-specific performance details are presented in tables for detailed analysis.

## **Qualitative Analysis and Limitations**

The section delves into a qualitative analysis of PROGPROMPT, highlighting common failure modes and limitations observed during manual inspection of generated programs and execution traces. Key points included:

- **Environment Artifacts:**
    - Failures often arise due to PROGPROMPT's agnosticism towards specific environments, leading to difficulties in finding or interacting with nearby objects, and missing common-sense actions like opening cabinets in VirtualHome (VH).
    - The prompt structure used does not guide the LLM to consider all relevant objects and actions in the environment.
- **Environment Complexities:**
    - Issues arise when objects are inaccessible, resulting in inadequacy in generated assertions. For instance, the agent may not plan to open a cabinet to retrieve an object inside.
- **Action Success Feedback and Plan Generation:**
    - Lack of feedback on action success hinders subsequent actions' success. While assertion recovery modules can assist, they do not cover all possible scenarios.
    - Some plans get prematurely truncated due to limitations imposed by the LLM API caps.
- **Final State Checking and Ambiguity:**
    - Strict final state checking can lead to false inference of failure, as the agent's completion of a task may not align with the precomputed ground truth final goal state.
    - Ambiguous task descriptions can result in multiple correct program solutions, causing challenges in plan generation and evaluation.
- **Task Variability and Evaluation:**
    - PROGPROMPT's capability to generate diverse plans for complex tasks (like cooking) using available scene objects is noted.
    - However, automating the evaluation of such tasks requires meticulous validation of all possible outcomes, potentially necessitating human verification.

## **C. Physical Robot Results**

The physical robot results evaluate PROGPROMPT on 4 tasks of increasing difficulty, with and without distractor objects. Here are the key points:

- Evaluation conducted on 4 tasks with varying complexities.
- Each task tested in two scenarios: one with necessary objects only and the other with added distractors.
- Results demonstrated using PROGPROMPT without feedback due to limitations in tracking system state and checking assertions.
- Random failures, like grasps slipping, are common in the physical robot setup, making quantitative system comparison challenging.
- Physical results serve qualitatively to showcase how PROGPROMPT constrains and grounds LLM-generated plans for physical robots.
- Additional metric "Plan SR" indicates the likelihood of plan success post pick-and-place execution without gripper failures.
- The system succeeded consistently across tasks, except for the sort task.
- Failures were attributed to random gripper failure and model confusion (e.g., categorizing a soup can as a bottle).
- Executability of generated plans consistently rated as Exec=1.

## **VI. CONCLUSIONS AND FUTURE WORK**

The researchers introduce an innovative LLM prompting approach for robot task planning, leveraging the strengths of LLMs in commonsense reasoning and code comprehension. This prompting scheme involves creating prompts that encompass a contextual understanding of the environment and robot capabilities. By doing so, LLMs can directly produce executable plans in the form of programs.

### **Key points included:**

- The experiments demonstrate that the PROGPROMPT programming language characteristics enhance task performance significantly across various evaluation metrics.
- The method is described as intuitive, adaptable, and capable of generalizing effectively to novel scenarios, agents, and tasks, culminating in successful deployment on a physical robot.
- The research community's exploration of task planning, particularly in robot plan generation and execution, is noted to be in nascent stages, with the intent to delve into broader application of programming language attributes like incorporating real-valued numbers to denote measurements, employing nested dictionaries for scene graph representation, and integrating more intricate control flow mechanisms.
- While LLMs have displayed competence in arithmetic operations and numerical comprehension according to various NLP studies, their potential for complex robot behavior synthesis remains relatively unexplored.