# Complete Summary

This research introduces a novel hierarchical multimodal framework that combines a Large Language Model (LLM) with a Vision-Language Model (VLM) to enable semantic navigation and manipulation in heterogeneous multi-robot systems operating in dynamic environments. By leveraging the LLM for task decomposition and semantic mapping at a global level, and enhancing the VLM using GridMask for precise object localization, the system facilitates robust coordination between aerial and ground robots. This approach demonstrates zero-shot adaptability, reliable semantic navigation, and manipulation, showcasing the first integration of VLM-based perception and LLM-driven reasoning for high-level task planning and execution in such systems.

## **I. Introduction**

Heterogeneous Multi-Robot Systems (HMRS) offer enhanced flexibility and efficiency in dynamic environments due to diverse agent capabilities like aerial, ground, or underwater robots.

- HMRS are well-suited for complex tasks involving manipulation, navigation, and observation.
- Cross-modal coordination complexity presents a significant challenge in fully utilizing the potential of HMRS.
- Traditional approaches relying on pre-programming and explicit communication struggle to adapt to unforeseen situations, especially in heterogeneous systems.
- Static models and pre-defined behaviors often lead to suboptimal decisions in dynamic environments.
- Recent advancements in large-scale multimodal models have enabled Multi-Agent Language Model (MA-LLM) systems combining high-level reasoning with visual perception.
- MA-LLM frameworks leverage the reasoning capabilities of Large Language Models (LLMs) and the perceptual grounding of Vision-Language Models (VLMs) for processing linguistic and visual information.

The proposed hierarchical MA-LLM framework addresses the limitations of tight coupling in integrating reasoning and perception, facilitating flexible task allocation, semantic-aware motion planning, and robust manipulation in dynamic, heterogeneous robotic systems.

- The framework modularly separates reasoning, perception, and execution layers to enhance adaptability and long-horizon task maintenance.
- Task execution is structured into three layers: reasoning, perceptual, and execution, enabling scalable and adaptive task performance.
- The ground robot uses aerial images to navigate by anchoring to the aerial robot's projected ground position, ensuring coordination even when the target object is temporarily out of view.

### **Main Contributions**

1. Proposal of a hierarchical multimodal MA-LLM framework bridging LLM-based task reasoning and VLM-based semantic perception for heterogeneous aerial-ground robot systems.
2. Introduction of a GridMask-based fine-tuning method for VLMs improving semantic labeling and object localization significantly.
3. Extensive evaluations demonstrating zero-shot generalization, comparisons with Deep Reinforcement Learning baselines, and robust long-horizon aerial-ground collaboration in real-world experiments.

## **A. Heterogeneous Multi-Robot Systems**

Heterogeneous Multi-Robot Systems (HMRS) utilize diverse agent capabilities to tackle complex tasks. Early works like Parker's ALLIANCE architecture focused on fault-tolerant behavior-based coordination. Subsequent research delved into distributed task allocation and coordination strategies.

- Deep Multi-Agent Reinforcement Learning (MARL) has emerged as a recent approach to enhance scalability and adaptability in decentralized settings, especially for navigation and search tasks.
- While MARL methods enhance local policy levels for navigation and search tasks, they often lack in semantic reasoning and compositional planning capabilities.
- The proposed framework, however, stands out by integrating Large Language Models (LLMs) and Vision-Language Models (VLMs) to connect global semantic reasoning with lower-level execution, effectively bridging the gap between high-level reasoning and low-level task execution.

## **Task Planning with Large Language Models**

The integration of Large Language Models (LLMs) in task planning offers a novel approach compared to classical symbolic planners like STRIPS and PDDL. While symbolic planners require manual domain knowledge modeling, LLMs utilize natural language as a direct interface for translating user intent into robot actions. This method reduces engineering costs and enhances scalability in dynamic scenarios.

**Key points included:**

- LLM frameworks like SayCan, ProgPrompt, and Tidybot have shown success in translating high-level user instructions into executable skills within confined environments.
- Recent studies, such as COHERENT, have extended the application of LLMs to task allocation and coordination in multi-robot systems.
- The authors' approach builds upon these advancements by not only using LLMs for hierarchical task decomposition but also for creating a global semantic map through aggregating aerial observations. This integration allows for long-term planning and collaboration between aerial and ground robots in dynamic settings.

## **C. Vision-Language Models for Robotic Perception**

Vision plays a crucial role in robotic perception, allowing robots to understand scenes by detecting objects, recognizing them, and reasoning about spatial relationships. While vision-based learning has improved robots' perception, especially in aerial platforms, challenges still exist in semantic generalization.

- Vision has traditionally been a key tool for robotic perception, facilitating tasks like object detection, recognition, and spatial analysis.
- Advancements in vision-based learning have boosted aerial robots' perception capabilities, enhancing their agility and autonomy beyond traditional methods.
- Despite these advancements, challenges persist in achieving semantic generalization for robotic perception tasks.

In this section, the researchers introduce a Vision-Language Model (VLM) within the robotic system, aimed at enhancing perception capabilities through a fusion of vision and language processing.

- The VLM is integrated to improve perception tasks by leveraging both visual and linguistic information in the robotic system.
- By combining vision and language modalities, the VLM enhances the system's ability to understand and interact with its environment more effectively.

This approach is particularly important for the proposed robotic system, as it aims to enable the robots to perceive and interpret their surroundings accurately, essential for tasks like object localization and manipulation.

- The VLM's integration empowers the robots to not only perceive objects but also understand their semantic context, aiding in tasks like object manipulation and spatial reasoning.
- By incorporating the VLM, the robotic system gains a more comprehensive perception mechanism that blends visual data with linguistic cues for improved understanding of the environment.

## **Section Summary: Object Configuration in the Robotic System**

The section presents how the robotic system's objects are configured spatially, crucial for the system's functioning in semantic navigation and manipulation tasks.

- The objects include a "Robot_Dog" and a target "Block_O."
- The "Robot_Dog" is composed of parts like the head and tail, each positioned at specific coordinates.
- The "Block_O" serves as a target with its own set of coordinates.
- Spatial coordinates for each part and object are defined to enable precise localization within the system.
- These configurations are essential for the successful execution of tasks and coordination between the aerial and ground robots.

This detailed object configuration enables the robotic system to execute tasks efficiently by understanding the spatial arrangement of key components and targets, contributing to the system's overall effectiveness in semantic navigation and manipulation.

## **Task-Specified Semantic Environment Information**

The section presents task-specified semantic environment information crucial for the operation of the hierarchical multimodal framework in the robotic system:

- **Robot Dog Description:**
    - The main robot in the system is referred to as "Robot Dog".
    - It is specified by its core characteristics such as type and parts with their respective coordinates.
    - For instance, the "head" part of Robot Dog is located at coordinates (-0.8, 1.9).
- **Detailed Particulars:**
    - The section includes detailed descriptions of various parts of Robot Dog beyond just the head, each with specific coordinates.
    - This data is essential for the system to understand the robot's structure and spatial orientation within the environment.
- **Semantic Environment Mapping:**
    - By integrating this task-specified semantic environment data, the system can create a comprehensive semantic map.
    - This map aids in hierarchical task decomposition and global high-level planning, contributing to effective coordination between the aerial and ground robots.
    - It enables the system to navigate, perceive objects, and conduct manipulation tasks with accuracy and reliability.

This detailed semantic environment information about Robot Dog serves as the foundation for the system's reasoning and execution capabilities, facilitating efficient task planning and execution in dynamic and diverse environments.

## **Workflow for Long-Horizon Task Using Hierarchical MA-LLM Framework**

The workflow for a long-horizon task utilizing the hierarchical MA-LLM framework is described as follows:

- The task commences with an instruction to "Assemble the word OK, but do not move K."
- The Large Language Model (LLM) is responsible for decomposing the command and assigning sub-tasks to motion functions for both aerial and ground robots.
- The aerial robot collects local maps from multiple viewpoints, integrated by the LLM into a global semantic map.
- Once the global map is constructed, the robots coordinate to reach the "O" cube.
- The aerial robot follows a specific global path while utilizing GridMask-enhanced bird-view images processed by the Vision-Language Model (VLM).

**Key points included:**

- Current advancements in Vision-Language Models (VLMs), such as CLIP and Vision Transformers, enhance the connection between visual inputs and semantic concepts, offering a more comprehensive understanding of relevant entities for tasks.
- Despite the progress, general-purpose VLMs still lack precise spatial reasoning crucial for robotic navigation and manipulation.
- Specific Vision-Language-Action (VLA) models like the RT-series integrate perception with action grounding for holistic robot control but encounter challenges in fine-grained localization.

## **III. METHODS**

The methodology employed in the study focuses on implementing a hierarchical MA-LLM framework to facilitate reliable task execution within the aerial-ground robotic system. This framework is structured into three key functional layers, each serving distinct purposes:

- **Reasoning Layer:**
    - Responsible for hierarchical task decomposition, allocation, and global map generation.
    - Carries out high-level reasoning processes to plan tasks effectively.
- **Perceptual Layer:**
    - Extracts semantic information from aerial imagery to enhance the system's understanding of its surroundings.
    - Essential for tasks like object localization and overall semantic perception.
- **Execution Layer:**
    - Executes robot actions based on the outputs from the reasoning and perception layers.
    - Grounded in the reasoning and perception outputs to guide physical robot movements.

The framework incorporates various components that work together dynamically to ensure seamless interaction with the perceptual layer, enabling the retrieval of task-specific semantic data. For instance:

- **Global Map Construction:**
    - Collects local semantic maps to create a comprehensive global semantic map for effective decision-making by the reasoning layer.
- **Local Navigation and Manipulation:**
    - Extracts real-time local semantic information from the perceptual layer to steer ground robot actions during navigation and manipulation tasks.

Additionally, this methodology emphasizes the significance of the perceptual layer as a crucial link between high-level plans and practical actions. It plays a vital role in coordinating behaviors between aerial and ground robots, harmonizing perception and reasoning processes for enhanced system performance.

## **A. LLM-based Reasoning Layer Design**

The LLM-based reasoning layer in the aerial-ground robotic system is enhanced through task-specific prompts designed to tailor its functional responsibilities. These prompts play a crucial role in improving the system's reasoning capability. The summarized prompts include:

- Hierarchical task decomposition and global semantic mapping.
- Semantic perception and object localization with the assistance of GridMask for enhanced spatial accuracy.
- Generation of semantic paths for guiding ground robot navigation and manipulation based on the global map.

## **Duty Clarification**

The task involves decomposing complex tasks for a heterogeneous multi-robot system based on the abilities of each robot. Key points include:

- For the Drone:
    - **Main Task:** Construct the map as the initial step before other sub-tasks.
- For the Robot Dog:
    - **Main Task:** Attach/Detach to an object.
- **Cooperation between Drone and Robot Dog:**
    - Move to a specified location.
    - Carry an object to a specified location.
- Responsible for selecting the motion functions needed to complete the task.
- Specific motion functions for each robot are defined as follows:
    - **Drone:** quad construct map()
    - **Robot Dog:**
        - go1 attach start("name of target object")
        - go1 detach start("name of target object")
- **Global Semantic Map Integration:**
    - Chain-of-thought prompts improve the model's ability to analyze and construct maps for high-level reasoning.
- The LLM-based reasoning framework is adaptable and can be extended to various heterogeneous robot teams by defining capabilities and actions within the prompt.
- **Transferability and Extensibility:**
    - New robot types or tasks only require defining capabilities and actions in the prompt, ensuring adaptability across different robot platforms and tasks.
- Facilitates rapid extension to unseen tasks by providing required action definitions in the prompt or API library, aligning with modular prompt engineering advances.

## **VLM-based Perceptual Layer Design**

The VLM-based perceptual layer design focuses on enhancing the VLM's perceptual capabilities through prompt engineering and fine-tuning on a GridMask-augmented dataset to achieve precise object detection. Here's a breakdown of the design specifications:

- **Role-specific Prompts:**
    - Prompts are designed to guide the VLM in outputting clear and accurate structured environmental information.
    - Environment Describer and Classifier task involves identifying objects, providing names, coordinates in a structured JSON format, and classifying them as main, target, landmark, or obstacle based on task requirements.
- **Instructions for Object Classification:**
    - Objects are classified based on the task into main, target, landmark, or obstacle categories.
    - For local navigation, relative movements guided by the aerial robot are used instead of direct global coordinates.
    - Map construction does not require labeling classification.
- **Spatial Localization Challenges:**
    - Despite prompts guiding response format and logic, accurate spatial localization remains a challenge.
    - Introducing GridMask, a structured visual cue overlaying a dense coordinate grid on aerial images for spatial accuracy.
- **Grid Structure and Adaptability:**
    - Grid parameters are dynamically determined by camera resolution, field of view (FOV), and flight altitude for generalization across different configurations.
    - Real-world size of each grid cell is defined based on camera settings.
- **Fine-tuning and Object Classification:**
    - VLM is fine-tuned using paired textual and visual information, object coordinates, enabling robust identification of object positions and roles in a zero-shot manner.
    - Objects are classified as obstacles, which obstruct motion paths and provide foundational semantic observations for planning at all levels.

## **Execution Layer Design - Motion Functions Pre-Programming**

The execution layer in the robotic system bridges reasoning and perception to ensure low-level motion functions are carried out effectively. Here's how this layer is designed and implemented:

- **Environment Description Task**:
    - The environment is described by listing object coordinates and roles obtained from image coordinate points.
    - Specifically, the task involves describing the robot dog's head, body, and tail coordinates in JSON format.
- **Pre-Programmed Motion Functions**:
    - These functions enable task-level behaviors in the aerial-ground robotic system.
    - The functions are essential for executing various actions within the system.
- **Aerial Robot - Global Semantic Map Construction**:
    - The quad construct map() function facilitates high-level spatial understanding by combining perception, motion context, and language reasoning.
    - It creates a global map from aerial image observations, serving as a foundation for downstream planning.
- **Steps for Map Construction**:
    - Local Map Generation: The aerial robot collects bird-view images along a predefined path, creating local semantic maps using the VLM.
    - Global Map Integration: The LLM processes all local semantic maps to construct a consistent global map through cross-map validation and label disambiguation.
- **Aerial Robot - Global Path Planning**:
    - The aerial robot plans an optimal path to guide itself and the ground robot effectively.
    - The aerial robot's global path planner generates collision-free paths based on the semantic map, guiding the ground robot using dynamically updated spatial targets.
- **Path Optimization**:
    - The system optimizes the path based on the semantic map, object classifications, coordinates, and obstacle information.
    - A task-specific cost function is constructed to ensure smoothness and collision avoidance through mathematical optimization techniques and spline interpolation.

## **S(u: Curve Optimization and Waypoint Generation**

The optimization involves minimizing a cost function over control points and obstacles, balancing path length, smoothness, and obstacle avoidance.

- The optimization uses B-spline basis functions to establish a parametric curve along which waypoints are sampled.
- The cost function J global ensures optimized path characteristics and obstacle avoidance.

In the final step, real-world waypoints are generated by sampling the optimized B-spline curve and projecting them into real-world coordinates using a spatial scaling factor.

- These waypoints provide the basis for semantic guidance, aiding in aerial-to-ground robot coordination.

## **Ground Robot -Local Semantic Navigation and Manipulation**

The ground robot, following the aerial robot's lead, engages in iterative local navigation within a dynamic workspace.

- Inspired by the DWA, the ground robot navigates using local semantic cues and the aerial robot's projected path.
- Semantic input for local planning is derived from the VLM, enabling task-specific navigation aided by semantic annotations.

Local motion planning involves balancing target deviation, obstacle avoidance, and orientation maintenance to optimize movement.

- Candidate velocity directions are generated and the optimal direction is selected based on a task-specific cost function.
- The robot adjusts its orientation and moves towards the target, terminating the iterative process upon alignment criteria fulfillment.

## **Ground Robot -Attach and Detach**

Equipped with a magnetic attachment device, the ground robot can interact with objects by attaching or detaching as needed.

- Through control functions, the system toggles the ground robot's magnet switch to attach or detach objects during execution.

## **Aerial Robot and Ground Robot -Engineering Supplement**

Practical engineering enhancements ensure robust system operation, including adaptive trajectory execution and stability mechanisms for both robots.

- The aerial robot dynamically adjusts its movement based on real-time feedback, ensuring continuous visual coverage and stable guidance.
- Ground robot stability mechanisms include adaptive in-place rotations and continuous monitoring to maintain proper object attachment.
- If object detachment is detected, the system initiates a rollback procedure to ensure successful task completion.

## **IV. Experiments and Discussions**

The experiments and discussions in this section revolve around evaluating the improvements in semantic perception using GridMask-based Vision-Language Model (VLM) fine-tuning and testing various aspects of the system's performance in both simulation and real-world scenarios:

- **Semantic Perception Improvements:**
    - Evaluation of enhancements in semantic perception achieved through VLM fine-tuning with GridMask.
- **Zero-Shot Transferability and Generalizability:**
    - Testing the system's ability to transfer knowledge and generalize to diverse environments and objects without prior training.
    - Comparison with baseline methods to showcase the system's low-level target search capabilities.
- **Simulation Experiments:**
    - Assessing how well the system performs in simulated environments with varying conditions and objects.
- **Real-World Task Performance:**
    - Evaluation of the system's performance in executing tasks in a real-world setting involving an aerial-ground heterogeneous robotic system.

The researchers focus on demonstrating the system's adaptability, robust semantic navigation, and manipulation capabilities across different scenarios.

## **System and Environment Implementation**

The experimental setup involves a heterogeneous aerial-ground system with a Unitree Go1 quadruped and a custom quadrotor. Key points included:

- The quadrotor features onboard SLAM and a downward-facing camera for bird's-eye-view perception.
- The Large Language Model (LLM) for reasoning and Vision-Language Model (VLM) for perception are accessed via the Google Cloud API from a Linux host through a wireless network.
- Details on deployment choices and measured request latencies are outlined in a summary table.
- Environment configurations for both simulation and real-world experiments are detailed in a separate table.

## **B. Experiment for the GridMask-enhanced VLM-based Perception**

The experiment aims to compare the GridMask-based fine-tuning approach with coordinate-supervision baselines for VLM-driven spatial localization, particularly in low-rank and small-sample fine-tuning scenarios crucial for robotics. Here's a summary of the experiment:

- **Model Fine-Tuning:**
    - The Gemini-2.0-flash model is fine-tuned using the GridMask approach, enhancing spatial accuracy.
    - Model architecture details and merits are available in the official paper.
- **Experimental Groups:**
    - Different experimental groups and their comparisons are provided, with details outlined in a table.
- **Evaluation and Comparison:**
    - Mainstream VLM grounding strategies like region-based annotation and coordinate-based input modulation are discussed.
    - Evaluation metrics include the Euclidean deviation between detected and ground truth object positions.
- **Key Findings:**
    - Models show improved performance with GridMask annotations, indicating enhanced spatial perception even in zero-shot scenarios.
    - GridMask-based fine-tuning prioritizes scenarios needing accurate 2D spatial localization and semantic reasoning.
- **Performance Results:**
    - Standard model without fine-tuning or GridMask annotations is sufficient for tasks not requiring high spatial precision (average deviation of 1.89 units).
    - Fine-tuned models reduce errors to below 0.2 units, enabling precise operations and stable aerial-ground collaboration.
- **Future Steps:**
    - To enhance robustness, a larger model (1000G-FT | Grid-Mask) is employed in subsequent simulations and real-world experiments.

## **C. Experiment in Simulation**

The researchers assessed the zero-shot generalizability of their hierarchical MA-LLM framework across various novel categories and layouts in simulation-based experiments. Here are the key points included:

- **Color Block Scene Evaluation**:
    - The environment featured colored blocks with new visual categories not encountered during fine-tuning.
    - The system successfully executed instructions like "Move the blue cube to the left side of the red cube" by identifying the target object and avoiding collisions with nearby objects.
    - The system showcased zero-shot generalization to new categories, layouts, and compositions without specific simulation tuning, remaining consistent across all scenes.
- **Comparative Evaluation of Planning**:
    - The system was compared against representative Deep Reinforcement Learning (DRL) baselines on target search tasks to highlight planning abilities.
    - The framework utilized LLM-VLM modules for global, semantic-map-based planning, contrasting with DRL methods focusing on local control policies for homogeneous agents.
    - The comparison with recent VLA approaches and DRL baselines emphasized the expansion of robotic task planning dimensionality and scope.
- **Performance Metrics and Trade-offs**:
    - The system demonstrated efficient trajectory steps and high task success rates in locating one or three targets, adjusting well to increasing task complexity.
    - Evaluation included factors like sensing modality, agent heterogeneity, task formulation, and environment geometry, impacting decision latency and task success rates.
    - The system achieved fewer steps and higher task success with a decision latency of around 3.0 seconds per step, differing from DRL methods focusing on sub-second responsiveness.

## **Experiment in Real World**

The authors validated the robustness of their hierarchical MA-LLM framework in real-world conditions, conducting experiments with dynamic disturbances, manipulation interference, and perceptual variations. Key points included:

- **Robustness Validation**:
    - Tested the framework under challenging conditions like dynamic disturbances.
    - Demonstrated adaptability to sudden obstacles introduced during block arrangement.
    - Showed the system's capacity to adjust paths for dynamic avoidance and successful block attachment.
- **Manipulation Interference**:
    - Showed how the system responded when the target block was manually removed during attachment by the ground robot.
    - Detected failures, rolled back, and retried until successful, highlighting robustness against interference.
- **Validation of Hierarchical MA-LLM**:
    - Confirmed system's ability to handle disturbances and uncertainty crucial for real-world deployment.
    - Tested the framework in assembly tasks of varying reasoning complexity: direct commands, reasoning with constraints, and long-horizon compositional reasoning.
- **Real-World Application Validation**:
    - Categorized tasks based on reasoning complexity.
    - Showcased tasks like moving blocks to specific positions and assembling words.
    - Validated VLM-based localization accuracy through position and orientation error analysis.

## **Method**

The method employed in the study included various evaluations and metrics to assess the performance of the proposed hierarchical multimodal framework for robotic systems:

- **Agent Type Obstacles and Time Efficiency:** The system was tested with different agents (POMA - 1 Drone) in various scenarios, demonstrating the system's capability for reliable pick-and-place operations and cooperative manipulation even with noticeable spatial estimation errors and lens distortions.
- **Task Decomposition Accuracy:** The framework displayed strong capabilities in accurately translating user instructions into executable sub-tasks, except for certain scenarios involving negation of spatial constraints which led to misinterpretations.
- **Semantic Map Construction:** The system effectively merged local semantic maps into a global map with an accuracy of 87%, correcting misclassifications and errors through redundancy; however, struggles were observed in cases where individual local maps contained unique errors without cross-validation.
- **Task Completion and Failure Analysis:** Achieving an 80% overall success rate across different task types, failures were mainly attributed to errors in global semantic map construction and initial task decomposition rather than execution errors, highlighting the system's robustness in achieving task completion.
- **Collisions and Error Analysis:** The system encountered an average of 0.68 collisions per operation, primarily caused by deviations in estimated object poses and motion control precision limits. Despite these collisions, task completion was never compromised, emphasizing the system's robust performance in navigation and manipulation tasks.
- **Recognition and Labeling Accuracy:** Visual recognition accuracy reached 74%, with errors often related to rotational ambiguity among visually similar objects. However, once recognized correctly, semantic labeling accuracy was consistently high across all trials, ensuring reliable assignment of roles to objects.

The comprehensive evaluation of the system through real-world experiments highlighted its robust integration of perception, reasoning, and execution, showcasing the potential for practical deployment in complex robotics tasks.

## **V. CONCLUSION**

The paper introduces a hierarchical MA-LLM framework for aerial-ground robotic systems, merging LLM-based task reasoning and VLM-based semantic perception with motion-level execution. The system architecture comprises three layers for interpreting commands, creating semantic maps, and executing manipulation tasks through coordinated behaviors.

- Unlike previous frameworks lacking integrated perception or struggling with multi-stage reasoning, this approach combines fine-tuned VLM perception with LLM-based hierarchical reasoning, facilitating closed-loop collaboration and advanced task decomposition.
- Experimental validation showcases the framework's generalizability and robustness across diverse tasks in simulation and real-world settings. Ablation studies confirm GridMask's efficacy in enhancing spatial precision crucial for reliable manipulation.
- Challenges in cluttered environments include perception inaccuracies and optimization-induced planning issues leading to suboptimal trajectories or more collisions. Additionally, inference latency of large models poses a limitation, with a delay of around 3s per decision step in the current API-based setup.
- Despite the inference delay affecting top-level decision-making, low-level control and stabilization onboard enable the robot to maintain its state safely during waiting periods without disrupting task execution.
- Future work suggestions encompass refining perception by integrating segmentation-enhanced recognition, extending to 3D perception for aerial robots and 3D motion planning, reducing inference latency through local deployment, and incorporating end-to-end VLA models for hierarchical pipeline enhancement.
- By combining LLM-guided reasoning with GridMask-enhanced VLM perception, the framework paves the way for heterogeneous multi-robot cooperation by linking high-level semantic reasoning with precise low-level execution, advancing towards more adaptable and robust robotic intelligence for practical deployment.