# #7, Translating Natural Language to Planning Goals  with Large-Language Models

[Complete Summary](#7,%20Translating%20Natural%20Language%20to%20Planning%20Goals/Complete%20Summary%2038770de8b9908070a244e2424ee18444.md)

- **Journal:** The uploaded version is an **arXiv preprint**
- **Year:** 2023.
- **Authors:** Yaqi Xie, Chen Yu, Tongyao Zhu, Jinbin Bai, Ze Gong, and Harold Soh

## **Problem they are solving:**

The paper starts from the observation that LLMs are generally poor at solving formal planning problems directly. Instead of asking an LLM to create the complete action sequence, the authors ask a narrower question: can an LLM translate a human’s natural-language objective into a formal **PDDL goal**, after which a reliable classical planner generates the actual plan? For example, the human might say “put the laptop in the drawer” or “set the table for two.” The LLM must identify the relevant objects, interpret the intended final state, fill in details omitted by the user, and output a syntactically valid PDDL goal that agrees with the domain and current world state. The proposed division is therefore: **LLM handles language and commonsense; classical planner handles formal reasoning and action sequencing.** This is not a UAV paper and contains no physical robot experiment. It is a study of the language-to-formal-goal layer that could sit inside a larger robotics system.

## **Methodology:**

The model receives a prompt containing three components: the PDDL domain, which defines object types, predicates, and possible actions; the PDDL problem, which lists the specific objects and initial state; and the user’s natural-language instruction. In most experiments, the prompt also includes one worked example showing a correct natural-language-to-PDDL translation. The LLM then outputs only the desired goal state, not the sequence of actions needed to reach it. Conceptually, the paper treats the generated goal ggg as being sampled from a distribution conditioned on a prompt qqq, where qqq contains the domain description, demonstration examples, and natural-language request. The authors separate successful translation into three abilities: **domain understanding**, meaning correctly understanding the PDDL objects and predicates; **goal inference**, meaning identifying what final state the user actually wants; and **PDDL goal specification**, meaning expressing that inferred state in valid PDDL syntax.

## **What PDDL means here:**

A PDDL domain contains the reusable rules of the world: available object types, predicates, actions, preconditions, and effects. A PDDL problem contains the current objects and initial state. The goal is a collection of logical predicates that must become true. A classical planner such as Fast Downward can then search for an action sequence that transforms the initial state into the requested goal. For example, the user says “put an apple in the fridge,” the LLM outputs a goal equivalent to `inReceptacle Apple1 Fridge1`, and the classical planner works out how the robot should pick up the apple, move, open the fridge if required, and place it inside. **Figure 1 on page 2** shows this pipeline and a one-shot prompt containing a PDDL domain, one solved example, a new problem, and the model’s generated goal.

**Experimental domains:**

The authors use two environments. **Blocksworld** is the classic planning problem where colored blocks must be arranged into vertical stacks. It appears simple but tests object identity, ordering, counting, spatial relationships, and formal predicate use. **ALFRED-L** is a reduced symbolic version of the ALFRED household benchmark. It includes kitchens, living rooms, and bedrooms containing movable objects, receptacles, and an agent. Example objects include apples, potatoes, knives, forks, laptops, books, drawers, sofas, beds, plates, sinks, and refrigerators. The original ALFRED representation was simplified so it would fit within the context window of the GPT-3.5 models.

**Models and prompting:**

The authors use `code-davinci-002` for Blocksworld and `text-davinci-003` for ALFRED-L, both GPT-3.5-era models. These were selected because they performed best in the authors’ preliminary translation tests. Almost all experiments use **one-shot prompting**, meaning the model receives one correct example before the test problem. Zero-shot prompts were also tested but generally performed worse. The authors deliberately vary the size and wording of the demonstration to measure prompt sensitivity.

**Task design:** The tasks collectively test five abilities: linguistic competence, object association, numerical reasoning, physical or spatial reasoning, and world knowledge. In Blocksworld, tasks include reproducing explicitly described stacks; interpreting stack descriptions stated from top-to-bottom versus bottom-to-top; resolving several blocks with the same color; creating a stack with a specified number of blocks; dividing all blocks into equally sized stacks; producing a stack containing a prime number of blocks; and grouping blocks into same-colored stacks. In ALFRED-L, tasks include following fully specified instructions; resolving synonyms such as couch versus sofa; positioning one object next to another; finding a box containing exactly two or three books; selecting the receptacle containing more objects; reasoning through one- or two-level nested containment; cutting fruits; preparing a meal; storing ice cream where it belongs; setting a table for two; and cleaning a kitchen.

**Dataset size:** Blocksworld tasks generally use configurations containing 4, 8, or 12 blocks, with 100 randomly varied instances for each size. `ExplicitStacks` contains 300 instances, `ExplicitStacks-II` 600, `BlockAmbiguity` 200, `NBlocks` and `KStacks` 300 each, and `PrimeStack` and `KStacksColor` 200 each. Most ALFRED-L task types contain 100 instances. The broad commonsense tasks—CutFruits, PrepareMeal, IceCream, SetTable2, and CleanKitchen—contain 20 instances each.

**Evaluation:** The primary metric is translation success rate under **loose** and **strict** criteria. In Blocksworld, loose success means the blocks are ordered correctly. Strict success additionally requires the bottom block to be marked as being on the table and the top block to be marked clear. In ALFRED-L, loose success checks that the required predicates are present; strict success also checks that the model has not added unnecessary or undesirable predicates. The authors additionally record PDDL syntax/domain errors and physically impossible goals, such as placing two blocks directly on the same block or representing one block as both above and below another. They also separately test domain understanding and goal inference to determine whether failures come from misreading the PDDL, misunderstanding the intended goal, or merely outputting the wrong syntax.

**Main results:** The strongest overall finding is that GPT-3.5 is **far better at translating goals than generating plans**. Preliminary direct-planning tests achieved approximately 0% success on most tasks, while goal translation often performed extremely well. Translation was strongest when the user’s desired final state was explicit and unambiguous, but performance became unstable when counting, nesting, ordering, ambiguity, or genuine physical reasoning was required.

| Domain and task | Loose success | Strict success |
| --- | --- | --- |
| Blocksworld—ExplicitStacks | 99.67% | 98.67% |
| ExplicitStacks-II | 58.00% | 52.17% |
| BlockAmbiguity | 18.00% | 14.50% |
| NBlocks | 62.00% | 57.33% |
| KStacks | 55.00% | 55.00% |
| PrimeStack | 87.00% | 87.00% |
| KStacksColor | 19.00% | 19.00% |
| ALFRED-L—ExplicitInstruct | 100% | 100% |
| MoveSynonym | 100% | 100% |
| MoveNextTo | 99% | 99% |
| MoveToCount2 | 96% | 96% |
| MoveToCount3 | 74% | 74% |
| MoveToMore | 86% | 86% |
| MoveNested | 59% | 59% |
| MoveNested2 | 53% | 53% |
| CutFruits | 100% | 100% |
| PrepareMeal | 90% | 60% |
| IceCream | 80% | 75% |
| SetTable2 | 100% | 100% |
| CleanKitchen | 90% | 35% |

**Explicit instructions:** GPT-3.5 performs almost perfectly when the exact desired configuration is clearly stated. It reaches 98.67% strict success for explicitly described Blocksworld stacks and 100% for fully specified household instructions. This supports the central claim that LLMs can function as effective natural-language interfaces to formal planners when little reasoning is required.

**Commonsense reasoning:** The model often fills in missing information impressively. “Set the table for two” is translated into a goal containing two sets of plates, cups, and utensils even though the user does not enumerate them. It understands that ice cream normally belongs in a refrigerator, that apples and similar items are fruits, and that couch may refer to a sofa. It achieves 100% strict success on setting a table for two, cutting fruits, and resolving synonyms. This suggests that knowledge absorbed from ordinary text can be valuable when translating familiar household instructions.

**Numerical reasoning:** Performance decreases as soon as the request requires reliable counting. Moving an object into a box containing two books succeeds 96% of the time, but changing the requirement to three books reduces performance to 74%. Blocksworld tasks requiring a particular number of blocks or equally sized stacks achieve only around 55–62%. The model often copies the numerical structure of the worked example instead of following the new instruction. For instance, when the demonstration contains two stacks, the model may output two stacks even when the test request asks for four.

**Physical and hierarchical reasoning:** One-level nested-object reasoning reaches 59%, while two-level nesting reaches 53%. The model may identify that Book2 is inside Box3, which is inside Box4, which sits on Sofa2, but fail to infer that Sofa2 is the sofa associated with Book2. The failure is not always PDDL syntax; the model often simply chooses the wrong physical object.

**Ordering sensitivity:** `ExplicitStacks-II` describes an otherwise unambiguous stack using phrases such as “from top to bottom” or “from bottom to top.” Merely changing this wording lowers strict success from almost 99% to roughly 52%. The model has a strong ordering bias and frequently reverses stacks described top-to-bottom. This shows that excellent results under one phrasing do not guarantee equivalent results under a semantically identical phrasing.

**Object ambiguity:** Tasks involving multiple blocks with the same color perform extremely poorly. `BlockAmbiguity` reaches only 14.5% strict success, while grouping blocks into same-colored stacks reaches 19%. The model often uses the correct objects but arranges them incorrectly, chooses the wrong indexed block, creates a mixed-color stack, or builds the wrong number of stacks.

**Prompt-example sensitivity:** Larger and more representative examples greatly improve performance. With a four-block demonstration, success is only 67% on four-block test goals, 52% on eight-block goals, and 32% on twelve-block goals. With an eight-block demonstration, those results rise to 75%, 77%, and 80%. With a twelve-block example, they become 100%, 100%, and 99%. The model is therefore not merely learning the abstract translation rule; it is heavily influenced by the scale and structure of the demonstration.

**Subtask analysis:** In Blocksworld, the model can usually extract object names but performs only around 40–60% on questions about what predicates such as `on`, `clear`, and `ontable` actually imply. The authors conclude that it often does **not genuinely understand the physical semantics of the PDDL predicates**. It can still produce correct goals by imitating linguistic patterns from the demonstration. This explains why prompt-example structure matters so much and why performance collapses when the task differs from the example.

In ALFRED-L, failures are often caused by **goal inference rather than parsing**. For example, the model may correctly identify which box contains more books but still fail to conclude that the target keychain should be placed inside that box. On the harder three-object and two-level nesting tasks, both domain understanding and goal inference deteriorate.

**Invalid-instruction behavior:** The model tends to assume every user instruction is achievable. If asked to “put two oranges on the table” when no oranges exist, it may invent `Orange1` and `Orange2`. If asked to “put a sliced plate on the table,” it may generate a predicate saying that the plate is sliced. Interestingly, when directly asked whether a plate can be sliced, it correctly says no. Its commonsense knowledge exists, but it does not consistently apply that knowledge while translating. Adding “ask a question if the goal is not achievable” helps in some cases, such as noticing missing oranges, but does not reliably detect physically impossible requests.

**What’s new—novelty:** The paper’s central novelty is its argument that LLMs should be used as **translators rather than planners**. Instead of trusting a language model to reason through an entire action sequence, it uses the LLM only to convert human intent into a transparent symbolic goal and leaves planning to a classical algorithm. The paper also offers one of the earlier systematic evaluations of natural-language-to-PDDL goal translation across explicit, ambiguous, numerical, spatial, nested, and commonsense tasks. Its three-part failure analysis—domain understanding, goal inference, and PDDL specification—goes beyond reporting only final accuracy.

**Limitations:** The study uses only old GPT-3.5 models, so its numerical results do not represent modern frontier or open-weight models. It evaluates only Blocksworld and a simplified symbolic household domain. There is no perception, robot hardware, noisy world state, dynamic environment, speech input, multi-agent coordination, or real-time replanning. The complete PDDL domain, object list, and initial state are already provided to the LLM, meaning the difficult problem of constructing the symbolic world model has been solved in advance.

Most prompts use one carefully selected example, and performance is extremely sensitive to that example. The study could not exhaustively evaluate all possible prompts. The subtask analysis is indirect because the models are closed black boxes; asking the model to answer separate questions cannot perfectly reveal what internal representation caused the original translation failure. ALFRED-L success is evaluated using manually written rules. The system also lacks a mandatory validation-and-repair loop, clarification dialogue, confidence estimation, constrained decoding, or automatic check that the translated goal faithfully represents the user’s intention.

**Research gap:** Earlier work often asked LLMs to generate complete plans, despite evidence that they perform poorly at formal planning. Traditional natural-language systems could translate limited instructions but depended on fixed rules and lacked broad commonsense knowledge. Other work translated language into temporal logic or generated entire PDDL domains, but the reliability of LLMs specifically as **goal translators** remained unclear. This paper fills that gap by isolating the translation stage and measuring when it succeeds or fails.

**Future scope:** The authors call for better models and stronger analysis of the representations underlying translation errors. Practical extensions would include modern LLM comparisons, more diverse domains, constrained PDDL generation, automatic syntax and feasibility checking, planner-in-the-loop repair, clarification questions for ambiguous or impossible requests, uncertainty estimates, and grounding against live perception. A safer system would have the LLM propose several candidate goals, use deterministic validators to reject invalid ones, ask the human to confirm the interpreted objective, and only then invoke the classical planner.

**Keywords:** Large language models, natural-language grounding, PDDL, symbolic planning, classical planning, goal translation, Blocksworld, ALFRED, commonsense reasoning, numerical reasoning, physical reasoning, prompt sensitivity, human–robot interaction.

**Tools/dataset used:** GPT-3.5 `code-davinci-002` and `text-davinci-003`; PDDL; Blocksworld; a simplified symbolic variant of ALFRED called ALFRED-L; randomly generated block arrangements and household scenes; one-shot and zero-shot prompts; PDDL parsing and planner-compatibility checks. No physical robot, simulator, sensor dataset, or UAV platform is used.

**Performance metrics:** Loose translation success, strict translation success, PDDL domain/syntax error rate, physical-validity errors, domain-understanding score, and goal-inference score. The most important results are near-100% performance on explicit and familiar household goals, approximately 50–60% on several numerical and spatial tasks, 14.5–19% on ambiguous or color-grouping Blocksworld tasks, and approximately 0% direct-planning success on most preliminary planning tests.

**How it is better—or not—than previous work:** It is better than direct LLM planning because it assigns formal search and action sequencing to classical planners, which are substantially more reliable. PDDL goals are interpretable, can be inspected by humans, and can be checked for syntax, constraints, and feasibility before execution. It is more flexible than rule-based translators because it understands synonyms, broad household requests, and omitted commonsense details.

However, it is not an end-to-end robotics system. It assumes a perfect symbolic state and does not test whether the resulting plan works on a real robot. The model can still mistranslate intent, invent nonexistent objects, accept impossible requests, and produce goals that are syntactically valid but semantically wrong. A classical planner guarantees that its plan reaches the supplied goal—not that the LLM supplied the **right** goal.

**Possible real-world application:** The architecture is useful for household robots, warehouse systems, industrial automation, assistive robotics, mission planning, and autonomous vehicles. A person could describe the desired outcome naturally, an LLM could translate that outcome into PDDL or another intermediate representation, and a deterministic planner could produce the executable actions. For Shepherd-AI, the key lesson is highly relevant: the LLM should translate operator language into a bounded, inspectable mission specification, while deterministic software handles allocation, planning, safety, and execution. The paper also shows why that translation must be validated—especially for numbers, spatial relations, nested references, impossible requests, and ambiguous targets.