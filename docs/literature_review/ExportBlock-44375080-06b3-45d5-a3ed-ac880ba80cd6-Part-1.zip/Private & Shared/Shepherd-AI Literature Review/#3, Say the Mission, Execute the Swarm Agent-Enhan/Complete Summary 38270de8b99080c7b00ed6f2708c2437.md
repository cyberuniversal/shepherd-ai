# Complete Summary

This research introduces an innovative framework that leverages Large Language Models (LLMs) enhanced by agents to manage UAV swarm operations in real-time. By enabling users to express mission objectives in natural language, the system autonomously executes these tasks through grounded interactions. The framework integrates an LLM-based Agent Core, a Model Context Protocol (MCP) gateway, and a Web-of-Drones abstraction based on W3C Web of Things (WoT) standards. Evaluation through simulations demonstrates the challenges faced by current LLMs in achieving reliable execution for swarm tasks, emphasizing the importance of agent-enhanced execution and standardized device abstractions in ensuring dependable swarm behavior.

## **Introduction**

UAV swarms find diverse applications, yet managing them in dynamic settings poses challenges, needing real-time adaptation of platform capabilities and mission demands. Current approaches require intricate, inflexible integrations. Large Language Models (LLMs) offer potent reasoning capabilities, interpreting natural language, and orchestrating complex workflows. Their use in cyber-physical systems is promising but largely unexplored in practicality. This study delves into leveraging LLMs for real-time UAV swarm control from natural language mission objectives, addressing the readiness of LLM-based agents for critical drone tasks.

- UAV swarms are used in varied applications like agriculture, monitoring, and rescue operations.
- Coordinating drones in dynamic scenarios involves intricate reasoning and adaptation.
- Existing swarm management methods are rigid and demand substantial engineering effort.
- LLMs can interpret natural language instructions and manage complex tasks effectively.
- They facilitate bridging the gap between high-level human intent and low-level drone actions.
- This paper aims to explore the practicality of LLMs in managing UAV swarms for critical missions.

## **Research Challenges**

When applying Large Language Models (LLMs) to real-time robotic control, several challenges emerge as highlighted by the researchers:

- The heterogeneity of drone platforms, sensors, and communication protocols leads to fragmented control surfaces, making it challenging for LLMs to access drone state information without ad hoc prompt frameworks.
- Standalone LLM prompting struggles with long-running tasks that require persistent state tracking and closed-loop real-time interactions, often leading to errors in generated drone behaviors, which can result in mission failure and safety risks like collision hazards.
- The non-deterministic nature of LLM execution complicates evaluation, as identical inputs may yield different control outputs and swarm behaviors, necessitating a focus on metrics like convergence properties and mission success rates in repeated experiments to analyze performance and reliability.

## **Contributions**

The paper explores AI agents for real-time UAV swarm management without human intervention during execution, focusing on mission-agnostic coordination by users through natural language commands and autonomous UAV actions. The key contributions of the study include:

- Proposing an agentic LLM-based architecture for long-running drone missions supporting real-time state retrieval, adaptive decision-making, and contextual reasoning.
- Introducing innovations to coordinate UAV actions without code generation at mission initialization, using LLM reasoning and function-calling mechanisms.
- Enabling continuous swarm control and adaptation to real-time feedback through a closed-loop reason-execute-monitor cycle.
- Utilizing the Model Context Protocol (MCP) and the W3C WoT standard to interact between the LLM agent and the physical world, modeling drones as WoT Things for standardized interaction and decoupling mission logic from platform-specific APIs.
- Extending the architecture with an execution-controller agent for monitoring runtime conditions and ensuring safe mission execution.
- Conducting an extensive experimental evaluation in a hybrid real-simulated environment, interfacing the platform with ArduPilot for flight control, and evaluating six LLMs across various swarm missions.
- Providing insights into LLM performance for swarm management tasks, highlighting the impact of integrating external knowledge, differences in performance among LLM models, and the absence of a clear correlation between token consumption and mission success rate.

The contributions can be summarized as:

- Mission-agnostic agent-enhanced LLM architecture for UAV swarm management.
- WoT-based framework for real-time bidirectional communication between AI agents and physical systems.
- Comprehensive empirical evaluation of six LLMs across three swarm-management tasks.

The paper structure includes a review of related work, system architecture, implementation details, experimental setup, results, and a brief overview of future work.

## **Related Works**

The research paper discusses various works related to integrating Large Language Models (LLMs) in UAV swarm management. Here are the key points outlined in the related works section:

- LLMs are expected to revolutionize mission-critical communication and robotic swarm management, leading to significant research growth in this area over the past couple of years.
- A survey on LLM-UAV integration emphasizes the advantages and challenges in navigation, perception, and planning tasks.
- Main applications of LLMs in UAV swarm management include bandwidth and positioning optimization, as well as task code generation.
- Examples include using LLMs for drone delivery services, choreographing UAV swarms with collision-free trajectories, and generating geometric formations for drone swarms.
- Projects like SwarmChain focus on collaborative LLM systems for distributed computation among resource-constrained UAVs.
- Comparisons between classical swarm algorithms and LLM-generated implementations highlight the importance of design prompts to enhance reasoning reliability in LLM-driven swarm control.
- Existing frameworks propose closed-loop code generation and mission validation, but lack real-time feedback and incorporation of standards like W3C WoT for interoperability.
- Unified LLM-driven frameworks demonstrate multi-robot task planning from natural-language instructions, emphasizing modular planning stages for consistent performance.

These related works collectively underscore the significance of thoughtful design prompts, real-time feedback, and interoperability standards in enhancing the reliability and performance of LLMs in the context of UAV swarm management.

## **System Architecture**

The paper introduces a unique software framework designed to facilitate autonomous management of diverse UAV swarms in complex and changing environments using Large Language Models (LLMs).

The framework's key features and objectives include:

- Allowing users to express high-level mission objectives in natural language.
- Coordinating sensing, actuation, and mobility across multiple drones to accomplish the specified mission.
- Incorporating an LLM-based Agent Core with persistent prompts and guardrails to interact with a Web-of-Things (WoT) ecosystem through a Model Context Protocol (MCP).

Notable aspects of the proposed architecture compared to existing approaches include:

- Support for interoperability among different drone types through a common interaction model.
- Real-time retrieval of system states, encompassing swarm drones and external data sources.
- Autonomous closed-loop reasoning that integrates state information into subsequent reasoning steps without human intervention.

The implementation involves leveraging the W3C Web of Things (WoT) standard and the Model Context Protocol (MCP) to:

- Provide a standardized abstraction layer for devices to expose their functionalities as machine-readable Thing Descriptions (TDs).
- Expose all system capabilities, including drones, sensors, mission state, and services, as WoT Things for seamless integration without altering the core swarm-management logic.
- Enable the LLM to access real-time system state information via the MCP protocol, facilitating AI-driven decision-making during mission execution without the need for code generation.

To support autonomous closed-loop reasoning:

- An Agent Core module is introduced to connect the LLM's reasoning to physical-world actions by guiding decision-making based on available WoT affordances.
- The Agent Core mediates execution through structured tool interactions and incorporates execution feedback into subsequent reasoning steps to enhance reliability and coherence.

The architecture's sub-systems are detailed, leading to an illustration of the end-to-end execution flow in Section 3.4.

## **W3C WoT Ecosystem**

The W3C WoT ecosystem, shown in a figure, consists of three main components facilitating interactions with physical entities like drones and tools:

- **Thing Descriptions (TDs):**
    - Describe how a Thing can be discovered and interacted with.
    - Include properties, actions, events (affordances), data schemas, and protocol bindings.
    - Model functions like arming, takeoff, navigation, sensor operations like sampling, and reporting measurements as actions.
- **Thing Directory:**
    - Manages a registry of available TDs.
    - Supports discovery operations for late binding and adaptability during runtime.
- **WoT Things:**
    - Execution entities exposing capabilities through TDs.
    - Translate WoT-based interactions into device-specific or service-specific operations independently from LLM-driven reasoning.

In the presented framework, three classes of WoT Things are supported:

- **Physical Things:**
    - Include drones and sensors.
- **Virtual Things:**
    - Represent abstract or derived entities such as mission state or contextual information.
- **Service Things:**
    - Represent computational or informational services like planners, optimizers, or external APIs.

## **MCP-based WoT Gateway**

The MCP-based WoT Gateway serves as the key link connecting the agent-enhanced LLM system with the Web of Things (WoT) environment:

- It functions as the exclusive interface between the agent and the WoT ecosystem, ensuring a focused WoT-centric execution approach.
- The gateway offers essential functionalities through a set of core tools within the Model Context Protocol (MCP):
    - Facilitates resource discovery by querying the Thing Directory to locate suitable WoT Things based on specified criteria.
    - Supports interaction by mediating access to WoT Things using the features defined in their Thing Descriptions (TDs).
- Any outcomes of execution, state changes, and event alerts are communicated back to the Agent through the MCP channel.

This setup strengthens the system's ability to leverage standardized interactions and maintain seamless communication between the agent and external resources within the UAV swarm control framework.

## **The Agent**

The architecture includes the Agent, which is crucial for interpreting user intents and managing interactions with the external system:

- The Agent comprises the LLM, an Agent Core, and an MCP client.
- The LLM facilitates high-level reasoning for understanding user-defined natural-language missions like area coverage or coordinated data collection.
- Instead of generating low-level commands, the LLM operates at a semantic level, reasoning over concepts like capabilities and execution intent.

The role of different components within the Agent:

- The Agent Core serves as the execution controller and runtime context for the LLM, managing a persistent execution context and core prompt.
- The core prompt sets semantic boundaries and interaction principles to guide the LLM's behavior, aiding as a drone swarm coordinator following W3C WoT standards.
- Guardrail prompts are conditionally activated to ensure execution correctness by constraining or redirecting the LLM's reasoning based on runtime conditions.
- The MCP client acts as the interface between the Agent and the external system, facilitating communication.

Additionally, the Agent Core includes auxiliary tools to enhance the LLM-driven execution loop, addressing specific limitations related to reasoning efficiency, numerical processing, and execution semantics of different LLM configurations.

## **End-to-End Operational Flow**

The end-to-end operational flow of a UAV swarm mission execution involves an iterative reasoning-execution loop managed by the Agent Core. Here's an overview:

- At initialization, the Agent Core loads essential components like the core prompt for swarm management context, interaction models directed by Web of Things (WoT), available Model Context Protocol (MCP) tools, and LLM behavior constraints.
- Constraints, such as maintaining minimum safety distances between drones to prevent collisions, are crucial elements defined before mission execution.
- Users begin a mission by providing a natural language high-level objective, like instructing all drones to reach a designated area to gather data from IoT sensors on the ground.
- The LLM processes the user prompt, generating an initial reasoning state with inferred objectives, constraints, and planned interactions with the environment.
- During mission execution, the LLM requests tool invocations (e.g., WoT Thing affordances) through the Agent Core and WoT Gateway. Continuous evaluation of guardrails ensures safe interactions by limiting or stopping invalid requests or unsafe conditions.
- Execution feedback such as telemetry updates, sensor data, and event alerts enriches the interaction context for future reasoning steps. Primitive per-entity interactions build up over time, fostering coordinated behavior among multiple drones for successful swarm missions.
- The execution loop continues until mission objectives are met, deemed unattainable under current circumstances, or purposely terminated.

## **Implementation**

The implementation of the architecture from Section 3 comprises three main layers:

- **Web-of-Things (WoT) Layer**:
    - UAVs and auxiliary devices are exposed as W3C-compliant Things.
- **MCP-based WoT Gateway**:
    - Provides typed access to WoT discovery and interaction.
- **LLM-based Agent**:
    - Executes the iterative reasoning-action loop described in Section 3.4.

This setup allows for structured interactions, observation of continuous states, and safe actuation without the need for code generation, enhancing the reliability and usability of the system.

## **Web-of-Things Layer**

The Web-of-Things (WoT) layer in the framework exposes all resources, both physical and virtual, required for mission execution as Web Things described through Thing Descriptions (TDs). Here's what this layer entails:

- **Resource Exposure:**
    - All physical and virtual resources involved in mission execution are exposed.
    - Each resource is represented as a Web Thing, defined through Thing Descriptions (TDs).
- **Uniform Access and Discovery:**
    - Each Web Thing specifies its properties, actions, and events.
    - This specification enables uniform access to resources and facilitates runtime discovery within the system.
- **Key Functionality:**
    - Allows structured interactions with drones, sensors, and services through standardized abstractions.
    - Facilitates continuous observation of system state and ensures safe actuation without the need for code generation.

The WoT layer plays a crucial role in enabling seamless interactions, standardized access, and dynamic discovery of resources essential for the successful execution of missions within the UAV swarm control framework.

## **WoT UAV Things**

The UAVs in the system are represented as individual WoT Things through dedicated Servients. Here is how this representation works:

- Each UAV has a dedicated Servient that exposes a standardized WoT mobility/telemetry interface.
- Commands are forwarded through MAVProxy, which then communicates with the ArduPilot simulator via MAVLink for actual execution.
- MAVLink is chosen for its broad availability, vendor-neutrality, and clear semantics, ensuring interoperability across various UAV platforms while abstracting low-level flight-control details from the Agent.

Key points regarding the representation of UAVs as WoT Things:

- The Thing Description (TD) of each UAV Thing includes Actions for basic controls (e.g., takeoff, go-to, land) and Properties that report telemetry and system state information (e.g., position, mode, energy).
- At the Servient boundary, action inputs and state transitions are validated to maintain basic execution constraints and prevent unsafe interactions.
- For example, the takeoff action necessitates a positive altitude field, and the drone's mode is set to GUIDED before executing a takeoff command to ensure safety and well-defined behavior.

## **Thing Description Directory**

The Thing Description Directory, essential in the framework, is powered by Zion, an open-source, W3C-compliant directory known for its scalability and performance. This system supports scalable storage of Thing Descriptions (TDs) and metadata-driven discovery efficiently.

**Key points included:**

- **Technology Choice:** The directory relies on Zion due to its scalability and performance advantages over other W3C-compliant directories.
- **Registration Process:** Servients register and update their TDs in Zion using standard CRUDL operations, ensuring that the directory is constantly updated with the latest information about each element.
- **Dynamic Discovery:** Discovery queries use TD metadata and JSONPath expressions, allowing the Agent to dynamically find relevant entities without relying on fixed identifiers. This dynamic approach enhances flexibility and adaptability in locating Things in the system.

## **MCP Tool Gateway**

The MCP-based WoT Gateway serves as the crucial link between the Agent and the WoT layer in the system:

- Implementation: It functions as a dedicated NestJS server, providing the sole integration point between the Agent and the WoT layer.
- Core Functionality: The gateway exposes a range of core MCP tools for discovery and interaction, with each tool specified by explicit input and output schemas. These tools are dynamically validated during runtime using Zod.
- Handling Operations: To manage asynchronous and long-lasting operations effectively, the gateway separates action invocation from execution completion processes.
- Process Flow:
    - Action Invocation: When actions are called, the gateway either returns acknowledgements or references in TD form.
    - Execution Verification: The Agent can confirm completion by monitoring subsequent property reads or receiving event notifications.

## **LLM Mission Agent**

The **LLM Mission Agent** developed in Python within the LangChain framework is a concrete implementation of the Agent architecture described earlier. It incorporates several key features:

- **Prompt Realization**: The Agent Core maintains three prompt artifacts, including a persistent core prompt loaded at startup, and a user prompt injected per run to specify the mission objective. These prompts, which are static templates, play crucial roles in ensuring reliable operation by encoding execution invariants essential for safe and effective operation.
- **Guardrails for Execution Failures**: Runtime guardrails, distinct from core prompts, are dynamically injected by the Agent Core based on observed failure patterns during early deployments and simulations. These guardrails are triggered in scenarios like inferred task completion without verification, stalled execution, or attempted termination with drones still in operation.
- **Dynamic Behavior Correction**: Activated guardrails prompt the LLM to re-evaluate the system state and complete missing execution steps, enhancing system robustness without the need for embedding task-specific control logic in the code.
- **Helper Tools for Execution**: Agent helper tools serve as optional wrappers around existing MCP tools, simplifying execution by encapsulating common patterns like synchronization, completion verification, and multi-drone commands. These tools leverage validated MCP tools internally without deviating from the WoT-directed execution model, offering efficiency without compromising standardized interactions.

## **Validation and Evaluation**

The authors validated and evaluated their proposed framework in a controlled simulation setting by assessing multiple Large Language Models (LLMs) on typical swarm-management tasks. The evaluation concentrated on various metrics:

- **Correctness:** The accuracy and correctness of the system's execution in interpreting and fulfilling mission objectives expressed in natural language.
- **Robustness under tool constraints:** How well the framework performed when faced with limitations or constraints in tool availability or functionality.
- **Operational efficiency:** The effectiveness and efficiency of the system in carrying out swarm tasks without unnecessary delays or errors.
- **Cost:** Measured as token consumption, which served as an indicator of the resources utilized by different LLMs across various mission setups.

The evaluation outcomes revealed insights into the performance of general-purpose LLMs in real-time UAV swarm control scenarios. Key findings included:

- While LLMs exhibited strong reasoning capabilities, they faced difficulties in reliably executing even basic swarm tasks without proper grounding and execution support.
- Task-specific planning tools and real-time guardrails significantly enhanced the robustness of swarm control systems.
- Merely monitoring token consumption was not sufficient to gauge the quality or reliability of task execution.

The study underscored the importance of agent-enhanced execution and standardized device abstractions to ensure that natural-language mission intents can be effectively translated into dependable swarm behaviors.

## **Experimental Setup**

The experimental configuration features:

- Fully containerized deployment of the system described in Sections 3 and 4 for reproducibility and consistent execution conditions.
- Emulation of UAV behavior using ArduPilot Software-In-The-Loop (SITL), with one multirotor instance per drone with unique SYSID.
- Exposing standard MAVLink telemetry, state transitions, and collision detection for each drone.
- The Agent having access to core interaction tools, mission planning tools, and agent helper tools during evaluation.
- Explicit control over the availability of planning and helper tools to support ablation studies and analyze model capabilities.
- Implementation of a list of tools, detailed in a table within the setup.
- Non-inclusion of prompt contents inline due to space constraints.

## **Models and Experiments**

The researchers assess various Large Language Models (LLMs) with different scales, architectures, and deployment features, listing them in a table. These models are chosen based on their inherent support for structured function calling, a requirement for MCP-mediated execution.

- The selected LLMs are frequently prominent in the Berkeley Function Calling Leaderboard (BFCL), indicating their proficiency in calling functions within agentic environments.

The study involves four distinct swarm missions, each emphasizing different planning, execution, and reasoning aspects:

1. **Area coverage with a task-specific planning tool**
2. **Area coverage without the planning tool (ablation)**
3. **Formation control considering collision-aware motion**
4. **Smart irrigation dependent on sensor-driven decision-making**
- The initial two missions constitute an ablation study to explore the influence of explicit planning support on mission outcomes.

## **Area Coverage**

In the area coverage task scenario, the Agent is directed to cover a specific rectangular region using the UAVs available, while adhering to altitude constraints and camera field-of-view limitations.

- Evaluation of coverage involves a footprint model where each drone covers a circular area on the ground, determined by the radius formula.
- The coverage ratio is calculated based on certain parameters related to the flight altitude of each drone.
- With the plan_area_coverage tool activated, the Agent can ask for optimal vantage points to maximize coverage within the target area by dividing it into a grid of cells.
- Grid cell dimensions are defined by width (w) and height (h), where the half-diagonal of a cell is computed to ensure complete coverage by a drone at the cell center.
- Altitude for optimal coverage is selected by the planner to match the required camera footprint radius within the cell.
- Altitude selection is constrained by predefined minimum and maximum mission limits for safe execution of the mission, ending with the swarm landing and disarmament.

In the absence of the planning tool, the LLM must devise a coverage plan directly from the region's geometry and related constraints without the assistance of the planning tool, relying solely on the exposed WoT properties for guidance.

## **Formation Experiment**

In the formation experiment, the Agent is tasked with creating a star formation using the available drones. The process involves utilizing the **`plan_drone_formation`** tool to generate target slot coordinates for multiple geometric formations around a specified center point and orientation. Key points included:

- The assignment of drones to slots is treated as a constrained assignment problem based on a distance matrix to ensure collision-avoidance and execution robustness.
- The assignment strategy aims to maximize the total displacement between drones' initial positions and their designated formation slots.
- Drones are intentionally directed towards distant targets, leading to longer paths and a higher chance of trajectory intersections.
- A fixed inter-drone spacing of 5 meters is maintained within the formation, increasing the likelihood of close encounters.
- This experimental setup tests the Agent's capability to handle coordinated motion and collision avoidance in challenging, real-world scenarios.

## **Experiment**

The experiment aimed to assess the success of the proposed framework in controlling UAV swarms by defining specific success criteria and evaluating the coverage of the missions conducted using the system. Here are the key points from this section:

- **Success Criteria**:
    - The success of each mission was determined based on specific pass/fail criteria, including:
        - All planned coverage slots being reached within defined distance and altitude tolerances.
        - All drones having armed=false and being in mode ∈{LAND, RTL} in the final snapshot.
        - Ensuring zero collisions occurred during the missions.
- **Coverage Evaluation**:
    - Using a structured tool-based approach, the researchers evaluated the coverage achieved during the missions to ensure that all planned areas were adequately covered.
    - The coverage assessment considered factors such as distance, altitude, drone states, and mission completion without any collisions.

By setting clear success criteria and evaluating the coverage of missions based on these criteria, the experiment provided insights into the performance and reliability of the agent-enhanced LLM framework in managing UAV swarms effectively.

## **Coverage (no tool)**

The section describes an ablation condition where a drone must take off and land within a target rectangle without any tools, simulating an exploratory scenario. Here are the key points included:

- The requirement is for one drone to complete both takeoff and landing within the specified target area.
- This condition emphasizes the drone's independent exploration and execution capabilities.
- The goal is to achieve successful takeoff, navigation within the target rectangle, and safe landing without any external tools or support.
- The scenario aims to test the drone's ability to autonomously perform essential flight tasks accurately.
- The evaluation metric includes ensuring zero collisions during the drone's operation.

## **Formation**

The section discusses the formation analysis based on the final positions of drones in a UAV swarm management scenario. Here are the key points included:

- Star formation is observed in the final drone positions, indicating a specific spatial arrangement resembling a star pattern.
- All drones that participated in the operation meet the criteria of armed=false and end up in modes such as LAND or RTL in the final snapshot.
- There were no collisions detected among the drones during the entire operation.
- This analysis provides insights into the successful execution of the swarm mission based on the specific spatial distribution and behaviors of the drones at the end of the operation.

## **Irrigation**

In the context of irrigation management within the UAV swarm control framework, the authors collect sensor data from multiple sources, including three humidity sensors and one temperature sensor. The decision to trigger irrigation is based on specific conditions: irrigation is deemed necessary if humidity levels are less than or equal to 57% OR if the temperature exceeds 30 degrees Celsius.

Key points included:

- Success in the irrigation task is defined by triggering the irrigation action precisely when it is required and ensuring that all drones involved have their armed status set to false and end in one of the modes: LAND or RTL.

### **Binary Success Criteria Table**

The researchers utilize binary success criteria to evaluate the performance of irrigation runs, providing clear guidelines for scoring the irrigation task within the framework.

## **Smart Irrigation Experiment**

The smart irrigation experiment involves several key components and decision-making processes:

- **Sensors and Setup:**
    - Three ground humidity sensors and one temperature sensor are utilized.
    - Each sensor is represented as a WoT Thing with specific metadata such as position and communication range.
    - Proximity of the drone to a sensor determines whether a sensor reading can be obtained.
- **Decision Rule for Irrigation:**
    - The Agent's decision to trigger irrigation is based on a specific rule involving mean humidity (H) and temperature (T) values.
    - The decision-making process hinges on these values to determine the irrigation action.
- **Modeling and Scope:**
    - While more sophisticated agronomic models could enhance decision-making, the experiment's focus is on coordinated swarm data collection.
    - The experiment intentionally excludes complex agronomic models to streamline the testing of coordinated data collection.
- **Synthetic Sensor Readings:**
    - Sensor readings are artificially generated to ensure comparable probability between meeting and violating the specified condition across multiple experiment runs.

This experiment highlights the practical implementation of sensor-driven decision-making within a swarm system for smart irrigation control, emphasizing the coordination and efficiency of data collection processes.

## **Evaluation Metrics**

The evaluation of system performance in the context of UAV swarm control involves several key quantitative metrics:

- **Success rate:** Indicates the fraction of runs that meet task-specific completion criteria.
- **Execution time (successful runs only):** Represents the wall-clock time from the start of the mission to verified completion.
- **Energy consumption (successful runs only):** Quantifies total battery usage in mAh, serving as a measure of resource efficiency.
- **Collision count:** Reflects the number of collisions between UAVs during mission execution.
- **Token usage:** Denotes the total consumption of LLM tokens, offering insights into reasoning costs.

Safety and efficiency objectives, like collision avoidance and prompt mission completion, are emphasized in the core prompt. Still, the LLM does not directly access quantitative metrics or aggregation formulas. Instead, optimization behavior emerges from feedback during execution, promoting adaptive learning without predetermined scoring functions.

Specific success criteria tailored to each experiment are outlined in a summarized format for easy reference.

## **Token accounting**

Token consumption in the LLM framework is tracked by analyzing the usage metadata provided by the LLM API at each agent iteration. Here are the key points from the section:

- An agent iteration involves a complete reasoning-execution cycle, comprising prompt creation, model inference, and tool-call generation.
- The total token consumption in a run is calculated as the sum of:
    - **Prompt**: All input tokens sent to the model at iteration i, including system instructions, user-defined mission, dialogue history, and tool outputs reintroduced as observations.
    - **Completion**: All output tokens produced by the model, encompassing natural-language reasoning and structured tool-call payloads like JSON arguments.
- Tool execution itself does not consume tokens directly, but the outputs contribute to the prompt length in subsequent iterations through T (i) toolout.
- This accounting method accounts for the cost of long-horizon reasoning, repetitive state checks, and tool-based interactions, facilitating a fair assessment of token efficiency across different models and experimental setups.

## **Results**

The results section presents findings from three experiments, where figures abbreviate model names (e.g., GPT) due to space limitations, while detailed versions are available in a referenced table.

- Experiment outcomes are summarized with model names for brevity.
- Detailed version specifics are accessible in a provided table.
- The section encapsulates results obtained from the experiments conducted by the researchers.

By abbreviating model names in figures, the detailed versions of the models are made available in a referenced table for further information and clarity.

## **Area Coverage Experiment**

The section presents an experiment evaluating the impact of an area-coverage planner tool on the success of different models in completing swarm missions:

- Task success in the experiment is heavily influenced by the availability of the area-coverage planner tool.
- In conditions with the planner tool, GLM achieves a 100% success rate, followed by Grok (70%) and DS (60%).
- However, GPT struggles to meet final requirements, resulting in a lower success rate (20%).
- When the planner tool is not available (no-tool condition), GPT achieves a 100% success rate, while Grok and QWEN fail to complete any run successfully.
- Token usage varies among models depending on the presence of the planner tool, affecting the amount of model-generated planning text.
- Models spend different amounts of time reasoning when the planner tool is present, with successful executions generally faster in the with-tool condition.
- Removing the planner tool leads to decreases in success rates for some models, while GPT performs better without the tool.
- The QWEN model struggles without the planner tool, showcasing a need for explicit planning support.
- Most models benefit from planning tools, with GLM demonstrating robust behavior across conditions.
- Grok matches GLM's success rate when the planner is available but fails to operate without it, indicating the tool's essential role in mission completion.

## **Formation Experiment**

The formation experiment challenges multi-drone motion planning with collision avoidance, where GPT demonstrates the highest success rate (60%), followed by GLM (50%), while DS and QWEN complete the mission in 20% of runs, with Grok and Claude not successful in any run.

- GPT and GLM stand out in success rates, with GPT achieving a slightly higher success rate but recording more collisions than GLM (three vs. two) in the experimental runs.
- QWEN shows a higher collision rate, attributed to its struggle in managing close-encounter trajectories under strict spacing and slot assignment guidelines, possibly due to its smaller model size.
- Grok and Claude have minimal collisions, suggesting failures are more related to incomplete mission tasks or planning/execution errors rather than safety issues.

Comparing GPT and GLM:

- Both models achieve similar success rates, but GLM uses fewer tokens in successful runs and records fewer collisions overall, highlighting its optimized reasoning cost and enhanced safety features.

## **Irrigation Experiment**

The irrigation experiment assesses longer missions in UAV swarm management, focusing on distributed sensor data collection under communication constraints and deterministic actuation decisions. Here are the key points included:

- Evaluation of missions involving collecting sensor data and triggering actions within communication range limitations.
- Results show GLM achieves the highest success rate (90%) for full success criteria, followed by Grok (50%).
- GPT and DS succeed in 40% and 30% of runs, respectively, while Claude and QWEN do not achieve full success.
- Breakdown of failures: GLM excels in decision correctness and data collection but faces premature termination issues.
- Grok mainly fails in the sensor data collection stage due to not reaching sensor geofences in time.
- GPT tends to over-trigger irrigation (false positives), while DS tends to under-trigger (false negatives) despite successful data collection.
- Claude demonstrates inconsistent decision-making behavior despite having access to all data.
- QWEN struggles with reliable data collection due to limitations in sustaining long, multi-step missions, leading to high token consumption.
- GPT exhibits higher token usage and more iterations on successful runs compared to other models, while GLM achieves superior success with lower token overhead.

## **Conclusions**

The authors explored the potential of agent-enhanced Large Language Models (LLMs) in managing real-time UAV swarms based on natural language mission objectives. Here are the key points:

- The proposed mission-agnostic architecture utilizes LLMs for reasoning and orchestration, with physical device interactions grounded through standardized W3C Web of Things (WoT) affordances and a Model Context Protocol (MCP) gateway.
- The framework allows continuous closed-loop reasoning and execution through structured tool calls, real-time state observation, and runtime guardrails, differing from code-generation-based methods.
- Evaluation across six LLMs and four swarm missions revealed that grounding LLM reasoning with typed tools and WoT abstractions is crucial for reliable long-running execution, especially in multi-drone and safety-critical scenarios.
- Task-specific planning tools notably enhance performance across LLM models, although their impact varies. Smaller or latency-optimized models may struggle without additional execution support for long-horizon missions.
- Token consumption does not reliably predict mission success, indicating that execution robustness relies more on reasoning structure and feedback integration than model complexity.
- Implementing runtime guardrails boosts robustness without hard-coding mission logic, while reducing verbosity and errors in constrained models through helper tools, enabling safe operation in cyber-physical systems.
- The study suggests a shift towards operating robotic swarms by stating intent rather than programming behaviors, enabling agents to translate intent into verifiable interactions with the physical world through machine-readable affordances.
- This approach transforms drone swarms into executable interfaces that listen, reason, and act based on shared affordances, facilitating a future where expressing the mission suffices to activate swarm movement.