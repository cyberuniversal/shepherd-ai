# Complete Summary

## **Academic Editors: Emanuele Luigi**

This research introduces an LLM-based framework facilitating natural language control of multi-UAV systems, enhancing scalability and robustness by separating reasoning and execution in UAV swarms. The proposed TACOS system enables a smooth transition from direct drone-level commands to high-level swarm behaviors, leveraging structured API execution to bridge semantic reasoning and low-latency UAV control. The Coordinator-Supervisor architecture demonstrates superior success rates and parallelization, providing continuous interaction and adaptability to dynamic environmental changes within the swarm context.

## **Introduction**

The coordination of multiple Unmanned Aerial Vehicles (UAVs) is a significant challenge in robotics, particularly as swarm sizes increase due to the limitations of assigning individual pilots to each UAV. This traditional approach is expensive, inefficient, hard to coordinate, and prone to errors.

- Effective systems need to support various levels of shared autonomy as swarm sizes grow, from direct control of individual UAVs to fully autonomous swarm behaviors guided by mission objectives.
- Past approaches have explored different interaction modalities, such as using fusion modules for voice and gesture recognition or tablet-based interfaces for manual control.
- These methods enhance usability but often focus on structured command inputs rather than high-level semantic task specifications, posing a challenge in designing interfaces for high-level task specification by a single operator.
- Recent advancements in large language models (LLMs) suggest that natural language can be an intuitive interface for high-level reasoning and task decomposition.
- The authors introduce TACOS (Task-Agnostic COordinator of a multi-drone System), an LLM-based framework for multi-drone coordination that connects natural language instructions with low-level swarm control through language-to-tools orchestration.
- TACOS utilizes a language model to interpret user intent and create structured task plans, while safety, trajectory generation, and control are managed by established planning and control modules.
- The framework offers three main features:
    - **One-to-many natural language interface:** Users can give commands at the UAV-specific or swarm level using natural language.
    - **Intelligent coordination:** High-level instructions get translated into structured task plans to facilitate seamless coordination.

## **Task Management with Closed-Loop Execution**

The system ensures correct temporal sequencing and execution by monitoring swarm state, facilitating effective task management.

## **Evaluation of TACOS**

- TACOS is assessed through simulation and real-world experiments involving quadrotor platforms.
- Ablation studies are conducted to analyze the impact of different architectural components of TACOS.

## **Paper Organization**

The paper is structured as follows:

- Section 2 gives an overview of related literature.
- Section 3 introduces the problem setup.
- Section 4 details the TACOS framework.
- Section 5 discusses the ablation study on framework components.
- Sections 6 and 7 present simulation results and real-world experiments with quadrotor platforms.
- Section 8 contains conclusions and future work discussions.

## **Related Work**

Multi-UAV systems have a history of addressing coordination challenges through various algorithmic solutions:

- **Distributed Task Assignment:** Methods like market-based and consensus-based approaches have been utilized to achieve scalable task allocation in these systems.
- **Formal Task Specification and Planning:** Previous research has explored using Linear Temporal Logic (LTL) and Signal Temporal Logic (STL) to specify temporally extended missions for multi-robot motion planning and coordination, offering strong correctness guarantees.
- **Motion Coordination Techniques:** The field has investigated motion coordination extensively, including through formation control methods and decentralized trajectory optimization.
- **Advances in LLMs:** Recent developments in Language Model-based Learning (LLMs) have introduced novel avenues for robot control, task planning, and multi-agent coordination:
    - Research in this domain has focused on LLM-driven multi-robot coordination frameworks, language interfaces for UAV swarm systems, and LLM-based robot control systems.
    - These approaches signify a shift in the paradigm of control and coordination strategies, with potential implications for enhancing the performance and flexibility of multi-UAV systems.

## **LLM-Based Robot Control**

The use of Large Language Models (LLMs) in robot control has been explored in various studies, aiming to convert natural language instructions into executable robot actions. One approach involves generating executable programs from natural language commands by instructing an LLM to create robot control code that combines perception and control APIs.

### **Key Points:**

- This method showcases significant task generalization capabilities as the LLM can create reusable functions and control elements for various tasks.
- The focus of this framework is on single-robot systems and policy generation, rather than coordinating multiple robots.

Another study delves into LLM-guided planning and control modules specifically designed for a single robot, emphasizing the utilization of LLMs for generating plans and controlling a singular robot efficiently.

### **Key Points:**

- In contrast, another study illustrates how a swarm of robots can utilize an LLM in real-time to autonomously generate executable code and perform new behaviors collectively.
- The utilization of LLMs in generating executable code is demonstrated in both synchronous and asynchronous patterns by the TPML framework.

## **LLM-Based Multi-Robot Coordination**

Research in the field explores the use of LLMs for high-level multi-agent reasoning and task allocation, where each robot is represented by an LLM agent that collaborates with others to coordinate tasks. Key points included:

- **Roco Framework**: In the Roco framework, robots, represented by LLM agents, engage in dialectic collaboration to coordinate tasks through iterative dialogue.
- **Task Planning and Execution**: Agents generate subtask plans and waypoint goals through communication, validated using environmental feedback like collision checks, and executed via a centralized motion planner.
- **LLaMAR**: This addresses long-horizon planning in partially observable multi-agent environments using a structured plan-act-correct-verify loop, enhancing robustness to uncertainties and planning errors.
- **Architectural Trade-offs**: Studies compare communication structures for LLM-driven robot teams like centralized, decentralized, and hybrid frameworks to optimize planning performance and reduce token usage.
- **LLM Application**: LLM2SWARM focuses on synthesizing and validating robot controllers directly in swarm scenarios using LLMs, while CoELA efficiently enables communication between agents in multi-agent cooperation settings.

## **LLM Interfaces for UAV Swarm Systems**

Recent research has explored utilizing Large Language Models (LLMs) in the context of aerial robotics and swarm systems, enabling natural language-based control of multiple UAVs. Here's a summary of the key points discussed in this section:

- **Flock-GPT**: This framework proposes controlling UAV formations through natural language instructions translated into geometric shapes. The translations are executed via flocking control algorithms, emphasizing formation generation over general mission coordination.
- **LEVIOSA**: Introduces a system that generates UAV trajectories based on natural language commands by employing hierarchical prompting and multi-critic evaluation. While enhancing reliability, the focus remains on trajectory generation rather than comprehensive swarm-level task management.
- **SwarmGPT**: This system allows users to create drone swarm choreographies using natural language commands. It incorporates a safety filtering mechanism to adjust generated trajectories for compliance with safety constraints, tailored more towards structured swarm performances than broader drone coordination needs.
- **LAN2CB**: Differs by generating executable code from natural language instructions using expert behavior libraries and predefined mission templates. These templates guide the LLM in defining trigger and finish conditions for each mission, emphasizing structured mission descriptions for improved mission execution.

## **Contribution**

The table summarizes the characteristics of existing LLM-based multi-robot and UAV swarm systems, highlighting their potential and limitations. Key points include:

- Existing approaches focus on static code generation, simulation-based planning, or specific applications like manipulation and drone formation control.
- Many frameworks use decentralized LLM agents or single-pass planning pipelines, leading to scalability issues and limited adaptability.
- TACOS overcomes these limitations with a hierarchical LLM-based architecture for real-time multi-drone coordination.
- The framework divides high-level reasoning and execution monitoring into a Coordinator and a Supervisor module, facilitating user command interpretation, task plan generation, and swarm state monitoring.
- This separation allows TACOS to support continuous interaction between humans and the swarm, enabling replanning and dynamic response to changes.

## **Problem Setup**

The problem addressed involves centralized, high-level task planning for a multi-UAV system through an intelligent coordinator that interprets user commands in natural language and translates them into executable plans for the UAV swarm. Here's what the section covers:

- The UAV swarm operates in a bounded 3D environment with obstacles and task-relevant entities.
- Environment specifics:
    - Environment is defined in a 3D space with ellipsoidal obstacles.
    - Free space is the environment excluding the obstacles.
    - Task-relevant entities like targets or landmarks are present.
- State of the world is represented by the obstacles and task-relevant entities.
- Quadrotor UAVs:
    - Each UAV has distinct operational modes.
    - Swarm state includes position and velocity vectors of each drone.
    - UAVs have a predefined set of low-level control actions like takeoff, land, tracking, etc.
- Implementation details of action set:
    - Dedicated control algorithms execute the actions reducing computational load.
    - Actions like 'goto' and 'start tracking' are elaborated with their functionalities.
- Delegation to low-level control:
    - The coordinator delegates actions to low-level control algorithms.
    - Allows heterogeneous UAV platforms that adhere to the action interface.
- Extensibility and assumptions:
    - Framework easily extended with additional action primitives.
    - Simplifying assumptions made regarding state estimation and world-state knowledge to support simulation and real-world experiments.

## **Explicit Perception Modeling Absence**

The section highlights the absence of explicit perception modeling in the research methodology:

- Perception is not explicitly modeled or simulated in the study.
- Target detection and task completion rely on positional conditions (such as reaching a specific location) or operator acknowledgment.
- The research does not involve a detailed simulation of how the drones perceive their environment or objects within it.

## **TACOS**

The TACOS framework comprises two key language models structured hierarchically:

- The Coordinator LLM processes high-level natural language commands, forming a task plan.
- The Supervisor LLM then arranges and executes this plan based on real-time swarm and environmental conditions.

Inspired by aerospace control architectures and Kahneman's two-system theory, this hierarchy mirrors a slow, reasoning layer (Coordinator) handling planning and intent comprehension, and a fast execution layer (Supervisor).

Advantages of this approach include:

- Simplified context management across the LLMs
- Independent customization and fine-tuning options for each model
- Initialization of each LLM with a specific configuration prompt outlining objectives, constraints, and output structures

The modular architecture of TACOS, illustrated in a figure, showcases the interaction flow between user input, the Coordinator, and the Supervisor.

## **Coordinator**

The Coordinator in the LLM framework translates user instructions from natural language into a task plan for the UAV swarm's control interface. Here are the key points:

- **Responsibility**: The Coordinator processes the current system state, including swarm state, world state, user instruction, and a partial task plan from previous executions.
- **Model Configuration**: It encodes the swarm's action set into the model's configuration prompt to guide the task planning process.
- **Output Components**:
    - **Reasoning (R)**: Provides a natural language explanation of the generated task plan, enhancing interpretability and quality of the output by utilizing Chain of Thought (COT) mechanisms.

## **Coordinator Role in Multi-Drone Systems**

In a multidrone system, the coordinator plays a crucial role in facilitating seamless communication and task execution. Here's what the section highlights:

- The coordinator's primary function involves translating user instructions, often in natural language, into a structured task plan compatible with the system's API.
- The structured task plan includes commands like sending drones to specific coordinates, arming and taking off drones, landing and disarming drones, initiating tracking of targets, and ceasing target tracking.
- By converting high-level user commands into API-compatible tasks, the coordinator ensures efficient and accurate execution of commands across the drone swarm.
- This process enhances the system's scalability and robustness by separating the user's reasoning from the actual execution, thus streamlining the coordination of multiple UAVs effectively.

## **Guidelines**

When summarizing the guidelines for controlling multi-UAV systems, several key points emerge:

- The importance of adapting to changes in drone statuses during missions to ensure effective replanning.
- Emphasizing safety by avoiding risky behaviors like sending multiple drones to the same location or towards obstacles.
- Calculating approximate coordinates before instructing drones on shapes or formations requested by the user.
- Providing specific instructions on how to position drones when asked to "surround" an object or point.
- Highlighting the prerequisite for drones to take off before they can receive setpoints for navigation.

## **Output: A Reasoning Block**

The researchers developed an LLM-based framework that facilitates natural language control of multi-UAV systems, enhancing scalability and robustness in UAV swarms. The framework, called TACOS, enables a single operator to seamlessly transition from direct drone-level commands to high-level swarm behaviors. This approach bridges semantic reasoning and low-latency UAV control through structured API execution, ensuring higher success rates and improved parallelization compared to other baselines.

**Key points included:**

- The framework implements a Coordinator-Supervisor architecture for enhanced task accomplishment.
- TACOS supports continuous interaction and swift adaptation to dynamic events affecting the swarm or environment.
- Reasoning and execution separation within the framework contributes to its scalability and robustness in managing UAV swarms effectively.

## **Examples**

The system enables a user to issue commands for a multi-UAV system using natural language, showcasing the flexibility and ease of use in controlling UAV swarms.

- **Reasoning and Execution**: A key feature is the separation of reasoning and execution, enhancing scalability and robustness in UAV swarm operations.
- **Transitioning Control Levels**: TACOS facilitates a seamless transition for an operator from direct drone-level commands to high-level swarm behaviors, bridging semantic reasoning and low-latency UAV control through structured API execution.
- **Coordinator-Supervisor Architecture**: The proposed architecture achieves higher success rates and improved parallelization compared to other baselines, ensuring efficient and reliable swarm management.
- **Continuous Interaction**: The system supports continuous interaction and dynamic event responses, adapting to changes affecting the swarm or environment.

### **Coordinator's Planning Capabilities**

To enhance the Coordinator's planning capacity, two engineering strategies are employed: In-Context Learning (ICL) and COT.

- **In-Context Learning**: ICL enables the model to deduce task structures from a few annotated demonstrations, improving planning accuracy based on exemplary reasoning and task plans.
- **COT Prompting**: This strategy guides the model to reason through decisions before generating a task plan, enhancing coherence and interpretability.

### **Reacting to Dynamic Events**

The Coordinator can respond to dynamic events triggering the need for new task plans, such as drone availability changes or swarm additions.

- **Automatic Trigger**: Upon detecting relevant events, the Coordinator automatically generates new task plans to maintain operational efficiency.
- **User Interaction**: Users can directly query the Coordinator to prompt new task plan generation, ensuring adaptability to unforeseen circumstances.

### **Safety and Control**

Safety measures are paramount in task plan generation and management, ensuring smooth and secure swarm operations.

- **Safety Guidelines**: Detailed safety constraints are provided to the Coordinator, preventing unsafe assignments like multiple drones targeting the same point.
- **Validation Mechanism**: Verification of API call structures is a primary safety check, with invalid calls prompting the Coordinator to re-generate a valid plan.
- **Delegated Safety**: Each executable action is backed by dedicated safe control algorithms detailed in Section 3, establishing an ultimate safety layer for operations.

## **Supervisor**

The Supervisor in the LLM framework is crucial for translating high-level task plans from the Coordinator into a sequence of executable actions, considering swarm and world states. Here are the key points included:

- Responsible for converting the Coordinator's task plan into actionable steps based on current swarm and world states.
- Encodes a set of available low-level actions directly into the model's configuration prompt.
- Operates in a closed-loop execution, continuously evaluating and issuing actions based on updated telemetry.
- Employs a feedback loop with a cycle duration (e.g., 0.1 Hz in the experiments) for sequencing API calls and assigning actions to UAVs.
- Outputs structured information specifying each drone's current task and the next action to take.
- Maintains a list of remaining subtasks for coordination with the Coordinator during replanning events triggered by system failures or new drones availability.

## **History Management**

During a mission, the system stores the complete interaction history with the user to assist the Coordinator in understanding context and monitoring environmental changes. This historical data comprises past user commands, associated reasoning, task plans, and updates to the swarm or environment.

**Key points included:**

- The stored history enables the Coordinator to interpret references to earlier commands and generate plans consistent with past instructions.
- In contrast, the Supervisor LLM has limited memory capacity, focusing on the immediate context.
- The Supervisor keeps a temporary record for each task plan, including commands issued and any changes to the swarm or environment. This aids in action sequencing, avoiding redundancies, and monitoring progress.
- After completing a task plan, the Supervisor clears this memory, initiating a new cycle aligned with its role as a reactive executor operating within finite-horizon plans.

## **Ablation Study**

The researchers conducted an ablation study to evaluate the impact of individual modules in the TACOS framework. Key points included:

- Assessment of the contribution of each module in TACOS.
- Metrics measured for each pilot request:
    - Success rate: indicates the percentage of trials where the task was completed successfully.

## **Average Number of Steps (L)**

The authors measure the performance of the system based on the average number of Supervisor cycles per task denoted as L.

**Evaluation Conditions:**

- The system performance is assessed under different conditions, including:
    - **TACOS Monolithic (MNL):**
        - Evaluating the impact of combining high-level reasoning and execution into a single unit.
        - Interaction history is compact with only executed actions tracked.
    - **TACOS without reasoning (w/oR):**
        - Examining the effect of providing the Coordinator's reasoning to the Supervisor.
        - Assessing if this improves the Supervisor's ability to accurately sequence and complete tasks.
    - **TACOS:**
        - Evaluating the complete framework as illustrated in Figure.

This evaluation helps in understanding the influence of reasoning and execution separation on system performance, shedding light on the effectiveness of different operational configurations.

## **Simulated Environment**

The simulated environment depicted in Figure includes 51 known landmarks distributed across five areas:

- Two parking lots with 10 and 5 parked cars respectively
- A residential neighborhood with 10 villas
- A park area with 20 trees
- A business district with 4 skyscrapers
- 2 drone takeoff and landing pads

**Key points:**

- The four skyscrapers serve as static obstacles to avoid
- Landmarks and obstacles are denoted as T = {T_i}51i=1 and O = {O_i}4i=1 respectively
- Parameters follow the ATOMICA framework:
    - Maximum velocity: v_max = 1.7 m/s
    - Maximum acceleration: a_max = 6.2 m/s^2

## **Model Configuration**

The researchers conducted 50 simulation runs for each configuration using the gpt-oss:20b model for both the Coordinator and the Supervisor.

### **Coordinator Configuration:**

- The temperature parameter was set to 1.0.
- The Coordinator interprets broad natural language commands to create a task plan and reasoning block.

### **Supervisor Configuration:**

- A temperature parameter of 0.4 was used.
- The Supervisor is responsible for executing task plans without generating new information, requiring more deterministic outputs.

This parameter tuning differentiates the roles of the Coordinator and the Supervisor, aligning with their distinct responsibilities within the system.

## **Mission**

The mission consists of two tasks assessing the framework's capabilities with increasing swarm sizes (6, 12, and 20 drones). The pilot's request involves locating a suspect in a car.

- **Description:**
    - Evaluation of performance with different swarm sizes.
    - Objective: finding a suspect hidden in a car.

### **Test Scenario**

- **Drone Failure Simulation:**
    - Before mission completion, a drone failure is simulated.
    - **Success Criteria:** The Coordinator must create a task plan assigning each car to at least one drone.

### **Post-Failure Scenario**

- **Response to Dynamic Events:**
    - After the simulated failure, the Coordinator must reassign unexecuted tasks to available drones, and the Supervisor must ensure correct task execution sequences.

## **User Request Prompt and Dynamic Event Prompt**

The section describes two key prompts that guide the behavior of the multi-UAV system:

- **User Request Prompt:**
    - The user asks the system to divide the swarm into two groups to quickly inspect cars, where a suspect might be hiding.
    - User's task request involves creating an efficient mission plan for the drones.
- **Dynamic Event Prompt:**
    - In response to changes in the swarm state, part of the original task plan has been executed, but some actions remain.
    - The system needs to allocate the remaining actions to drones without duplicating tasks already completed.

## **Results**

The results section presents findings using tables and figures, focusing on success rates and average steps computed in successful trials. Here's a breakdown of the key results and implications:

- The success rate and average steps are reported for successful trials, excluding Task 0 (takeoff) as it had a 100% success rate.
- Failures due to planning dead-ends or repeated command loops were considered in the overall success rate calculation.
- An ablation study revealed significant insights:
    1. Providing both reasoning and task plans allows for inferring correct action sequences, resulting in higher success rates with the full TACOS framework compared to TACOS w/oR.
    2. Explicitly separating task planning and execution aids in managing missions with multiple execution cycles.
- TACOS demonstrated a superior success rate over TACOS MNL, showcasing the benefits of structured planning and execution divisions.

## **TACOS demonstrates better parallelization capabilities compared with TACOS w/oR.**

TACOS, a framework for natural language control of multi-UAV systems, shows improved parallelization abilities compared to the version without reasoning (TACOS w/oR). Key points included:

- The number of Supervisor cycles required with six UAVs is noticeably lower in TACOS compared to TACOS w/oR, indicating more efficient parallelization.
- TACOS MNL displays repetitive actions across drones over iterations, contrasting with the sequential nature of TACOS w/oR.
- Even with simulated drone failures, TACOS manages tasks efficiently despite the need for multiple steps.
- Coordinator in TACOS avoids generating invalid API calls, which is attributed to the simplicity and defined parameters of the API.
- Inference times across different swarm sizes and framework versions remain consistent, with the monolithic version achieving lower inference times due to its single LLM approach rather than a dual-model architecture used in TACOS.

## **Comparison with Classical Task Assignment**

The comparison between TACOS and a classical non-LLM approach was carried out by executing a specific experiment involving tasking a drone swarm to inspect parked cars in an urban setting and introducing a dynamic failure.

- The baseline approach's pseudocode (Algorithm 1) initializes sets of landmarks, available drones, obstacles, and unvisited landmarks, ensuring drones are in flight and then assigns unvisited landmarks to drones to minimize travel distance.
- The algorithm continues in a loop until all unvisited landmarks have been visited.
- Results from the simulation show that the classical baseline outperforms in scenarios with entirely predefined tasks, as it is typically faster and more efficient.
- TACOS excels in leveraging semantic information for task allocation, enabling dynamic adaptability based on changing priorities, a capability lacking in non-LLM approaches.
- The modular architecture of TACOS allows for easy integration of classical algorithms as APIs, bridging performance differences observed in specific scenarios.

## **Target Search Case Study**

This section presents a target search experiment to assess TACOS's performance in coordinating a multi-drone system. Key points included:

- Demonstrating TACOS's assistance to a human operator in locating and tracking a target using multiple drones within a known environment.
- Evaluating system robustness by simulating multiple UAV failures during the mission.
- Utilizing fixed-altitude planar coordination (2.5D) with constant altitude z and a restricted 2D executable action set.
- Integrating ATOMICA for real-time, collision-free trajectory generation for Supervisor-issued actions like goto() and start_tracking().
- Applying a maximum velocity of 2 m/s and maximum acceleration of 6.2 m/s^2 to generated trajectories.
- Conducting experiments on Ubuntu22 LTS with an NVIDIA RTX 6000 GPU for communication using ROS Noetic.
- Employing a simulated environment with a known moving target vehicle evading the swarm during the search task.
- Assuming perfect low-level trajectory tracking for quadrotors in all simulated experiments.
- Demonstrating how TACOS enables seamless coordination of large multi-drone systems via a natural-language interface.
- Leaving the integration of on-board perception and autonomous target detection for future work.

## **Simulation Results**

The researchers conducted simulations to test TACOS, focusing on locating and tracking a moving target within the environment. Here are the key points from the simulation results:

- Simulations involved swarms of 6, 12, and 20 drones, with detailed observations reported for the 6-drone swarm.
- The framework's core capabilities were showcased, starting with the operator defining mission objectives using natural language commands.
- When drones failed during the mission, TACOS replanned and reassigned tasks, ensuring mission continuity.
- The Coordinator successfully integrated new tracking requests while managing pending subtasks from the previous plan.
- TACOS automatically reallocated drones to unexecuted tasks and adapted to changing mission requirements.
- Variability in the Coordinator's behavior was noted due to the stochastic nature of LLMs, which could be mitigated through model fine-tuning.
- TACOS allows for continuous interaction and real-time refinement of prompts by the operator to guide the framework's behavior.
- The framework supports high-level supervision by enabling the operator to specify task priorities during interruptions.
- The research provides a video demonstration of the simulations for all swarm sizes, showcasing TACOS' performance and functionality.

## **Real World Experiment**

The real-world experiment involved flight tests in an indoor arena with a 12-camera motion capture system tracking drones named Alfa, Bravo, and Charlie. The setup included a simplified map with different zones like small and large parks, a villa, and a business district.

The mission scenario centered around finding a lost dog in the small park, showcasing the interaction between the pilot's commands and TACOS's responses. Key points from the experiment include:

- TACOS demonstrated semantic reasoning by prioritizing park locations over the business district when searching for the dog.
- The system efficiently assigned tasks to drones based on proximity, showcasing dynamic decision-making capabilities.
- The experiment was repeated 10 times, showing consistent behavior during the initial task allocation but occasional variations when monitoring the dog and notifying the owner.
- A demonstration video illustrating the experiment is available for further reference.

## **Conclusions**

The authors investigated the application of large language models (LLMs) as interfaces for multi-drone systems, emphasizing natural language interaction between humans and drone swarms. Key points included:

- The framework establishes a connection between low-level planning/control algorithms and high-level mission execution.
- A lab-scale search-and-rescue simulation showcased improved search strategy efficiency with the language model's semantic reasoning.
- An ablation study assessed individual module contributions within the proposed architecture.
- Limitations of the framework were highlighted, including reliance on full worldstate knowledge, lack of onboard perception, and restriction to short-horizon missions.
- The work stands as a proof-of-concept for LLM-based swarm coordination, with future plans to integrate onboard perception modules and expand the API set.
- Strategies for addressing challenges in long-horizon missions were proposed, like implementing history management techniques such as Retrieval-Augmented Generation (RAG) architecture and periodic LLM-driven summarization to manage extended operations effectively.

## **Supplementary Materials**

The supplementary materials provide detailed information and guidelines crucial for understanding and implementing the LLM-based framework for controlling multi-UAV systems. Key points included are:

- The provided link allows access to supporting information, including a video showing TACOS simulation with different numbers of drones and the Coordinator's role in the framework.
- Available APIs and their required parameters are outlined for seamless interaction with the system.
- Specifications for output formats are clearly defined to ensure the LLM's responses are easily interpretable.
- Behavioral rules for the Coordinator dictate mission execution, enhancing scalability and robustness of UAV swarms.
- Guidelines are established to ensure safe and efficient operation of the drones, including rules for mission replanning, safe spacing, and precise movements.
- Examples demonstrate how to split the swarm into groups, assign tasks to drones in each group, and ensure coordinated movement around specified points or objects.
- Detailed task plans show how drones are assigned specific actions, ensuring efficient and accurate execution based on user requests.
- The system's reasoning capabilities are illustrated, showcasing how plans are adjusted to fulfill unexecuted tasks and new user requests seamlessly.
- Sequential tree inspection by drones is demonstrated, emphasizing efficient task allocation and execution strategies.
- The tasks assigned to drones are structured in a way that ensures systematic coverage and efficient utilization of the drone swarm resources.

## **System Implementation**

The system involves sending two drones to follow a suspect based on user commands. The task allocation plan includes assigning the first two drones to track the suspect from the front and back.

- System: {'reasoning': 'The user commanded to follow the suspect with two drones.'}
- Task Plan:
    1. Drone 0 assigned to follow the suspect from the front.
    2. Drone 1 assigned to follow the suspect from the back.

This system implementation is detailed in the paper available at [**https://doi.org/10.3390/drones10040251**](https://doi.org/10.3390/drones10040251).

## **Acknowledgments**

The authors of the paper extend their thanks to the ASCL laboratory members for their assistance during the experimental activities.

- Acknowledgment to the ASCL laboratory team for their valuable support
- Gratitude expressed for the assistance received during experimental work