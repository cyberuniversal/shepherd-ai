# Complete Summary

This paper focuses on introducing a multilingual voice-controlled framework for quadrotor drones to enable real-time operation in English and Arabic. By utilizing Speech-to-Text (STT) technology in combination with large language models (LLMs), the system interprets spoken commands, translating them into executable control code. The architecture leverages Vosk for bilingual STT and Google Gemini for semantic disambiguation and code generation, operating in a continuous, low-latency mode within an edge-cloud hybrid setup. Results demonstrate high accuracy in speech recognition and efficient command execution, validating the efficacy of this approach for safe and adaptable aerial autonomy, thus contributing to advancements in human-drone interaction.

## **Introduction**

Unmanned Aerial Vehicles (UAVs), commonly known as drones, have gained widespread use in various sectors for their agility and real-time data collection capabilities. Despite advancements in drone technology, traditional control interfaces like joysticks present challenges for non-experts, prompting the need for more user-friendly control methods.

- Early solutions for drone control relied on manual inputs like joysticks, limiting accessibility.
- Natural language interaction offers a more intuitive way to control drones, evolving from rule-based commands to AI-driven systems.
- Recent research integrates speech-to-text and neural models for richer human-drone dialogue, enhancing scalability and flexibility.
- Existing cloud-based voice control systems lack multilingual support and offline functionality, limiting usability in diverse environments.

### **Key Points:**

- Integrating large language models (LLMs) has revolutionized UAV command interpretation.
- Challenges of latency, reliability, and safety arise with LLM-driven UAV control.
- Previous studies influenced this work, leading to the development of a bilingual voice-based UAV control framework.
- The proposed architecture combines offline bilingual speech recognition (Vosk) and LLMs for real-time command interpretation and code generation.
- The framework ensures safety through command validation and supports English-Arabic interactions, including code-switching.
- Achieving sub-500 ms latency offline sets this approach apart from cloud-dependent systems.
- The paper details the bilingual framework's design, experimental results, and outlines for future research.

## **State of the Art**

The section discusses the integration of advanced computational paradigms in unmanned aerial systems, revolutionizing aerial robotics by combining linguistic intelligence and autonomous decision-making. It focuses on two key technologies:

- Speech-to-text (STT) systems
- Large language models (LLMs)

### **Key Points:**

- **STT Systems:**
    - Essential for intuitive human-UAV interaction.
    - Enables language-based control interfaces for drones.
- **LLMs:**
    - Support real-time reasoning and context-aware mission control.
    - Enhance embedded autonomy in UAV operations.

This integration addresses challenges in natural communication, improving the efficiency and effectiveness of human-drone interaction in dynamic scenarios.

## **Natural Language Processing and Large Language Models**

Natural Language Processing (NLP) combines computational algorithms with linguistic theory to analyze and generate text or speech, evolving from rule-based and statistical models to neural transformer architectures like BERT and GPT, which use self-supervised pretraining for strong generalization and semantic reasoning.

- Transformer-based systems like BERT and GPT represent a significant advancement in contextual understanding, zero-shot learning, and text generation.
- Current NLP models, while successful, are primarily optimized for textual inference in cloud settings, which limits their use in latency-sensitive or multilingual UAV environments.
- Speech recognition and language understanding are often treated as separate modules in existing studies, lacking a unified framework connecting linguistic intent to actionable control logic.
- Recent research focuses on integrated NLP-control pipelines for real-time reasoning and command synthesis on edge hardware, aiming to reduce external computation dependency while ensuring high interpretive accuracy for embedded linguistic autonomy in aerial robotics.

## **Speech-to-Text Systems**

Speech-to-Text (STT) technology has advanced from traditional Hidden Markov Model (HMM) designs to modern neural frameworks that merge acoustic and language modeling for enhanced accuracy and adaptability:

- Early STT models separated acoustic and language components, while newer systems combine both in neural structures for better results.
- Connectionist Temporal Classification (CTC) networks aligned speech with token sequences, and attention-based encoder-decoder setups improved focus on relevant sounds.
- Recurrent Neural Network Transducers (RNN-Ts) extended these models for real-time transcription, crucial for interactive UAV control settings.
- Conformer architectures, like the Conformer model, utilize convolutional and transformer layers to capture local and global speech patterns effectively.
- The VOSK toolkit showcases lightweight, multilingual STT optimized for offline use, maintaining high accuracy with reduced computational load.

These STT systems are ideal for embedded UAV environments, emphasizing on-device inference, privacy, and responsiveness:

- Offline STT engines, when integrated with task-specific natural language understanding components, ensure context-aware and dependable UAV command interpretation.

## **Voice-Based UAV Control**

Voice-based UAV control allows users to verbally command autonomous drones, streamlining operation and enhancing usability in critical situations. This method reduces manual input and promotes hands-free interaction.

- Early systems used rule-based grammars and keywords for limited commands, hindering adaptability and scalability.
- Modern frameworks employ neural Speech-to-Text (STT) and advanced language models for improved noise tolerance and comprehensive speech understanding.
- Integration of STT with Large Language Models (LLMs) enables nuanced, context-aware communication with drones, facilitating free-form dialogue.
- Systems utilize prompt-driven planning and code generation to convert human intent into actionable flight commands, ensuring precise execution.
- Safety-focused designs include validation layers to confirm command feasibility and prevent risky maneuvers.
- Offline solutions like VOSK support secure, low-latency interactions, crucial for real-time usage in practical settings.

## **Large Language Models and UAV Systems**

Large Language Models (LLMs) are increasingly playing a crucial role in enhancing Unmanned Aerial Vehicle (UAV) intelligence by integrating visual, linguistic, and control modalities for tasks like mission planning, perception, and communication using natural language. Researchers like Tian et al. present a comprehensive framework for UAV-LLM integration, while others like Liu et al. develop specific applications like AerialVLN that pair UAV flight paths with textual commands.

### **Key points included:**

- Multimodal large language models (MLLMs) enhance UAV intelligence by combining visual, linguistic, and control modalities.
- AerialVLN pairs UAV flight paths with textual commands, while frameworks like OpenUAV focus on realistic flight dynamics for benchmarking.
- Distributed frameworks like Aero-LLM enhance communication security for UAV systems.
- Current MLLM-based UAV frameworks often prioritize vision-language fusion over linguistic comprehension, limiting robustness under ambiguous or sequential instructions.
- Computational overhead and cloud reliance hinder onboard deployment and real-time control in existing UAV-LLM systems.
- Challenges include limitations in linguistic diversity in datasets, focusing more on imperative phrases than rich semantic structures.
- Proposed solutions involve multi-UAV collaboration, hybrid edge-cloud architectures, and developing large-scale datasets capturing real-world dynamics to overcome existing limitations.
- Future research directions aim at improving interpretability, efficiency, and cross-domain generalization for LLM-based UAV systems.

## **System Architecture and Real-Time Workflow**

The system architecture for real-time UAV control utilizes a sequential processing pipeline to convert natural language voice commands into actionable drone tasks promptly. The workflow emphasizes quick response times and dependable bilingual functionality by combining efficient recognition models with advanced reasoning components.

The architecture comprises five interlinked stages for seamless functionality:

- **Audio acquisition**: Initial step to capture voice commands.
- **Bilingual speech recognition**: Utilizes offline speech recognition for accurate interpretation.
- **LLM-based command selection**: Large language models aid in selecting appropriate commands.
- **LLM-assisted code generation with safety validation**: Ensures generated code is safe and executable.
- **Drone command execution**: Executes the finalized drone commands effectively.

Key points included:

- The system optimizes for low latency and reliable bilingual operation.
- Combines lightweight recognition models with more elaborate reasoning modules.
- Integration of offline speech recognition with large language model (LLM) reasoning.

## **Continuous Audio Acquisition**

Audio acquisition in the system is fundamental, achieved through a lightweight microphone interface that streams audio continuously at 16 kHz using the sounddevice Python library, balancing command clarity and computational efficiency.

- **Audio Segmentation**:
    - Captured audio is segmented into 100 ms frames and stored in a thread-safe queue.Queue, enabling independent capture and recognition tasks for real-time processing without blocking.
    - This asynchronous buffering mechanism ensures stable latency during peak computational loads, preventing packet loss and maintaining operational efficiency.
- **Speech Detection**:
    - Active speech detection involves short-term energy thresholding, where frames meeting a specified energy level threshold are further processed to filter out silence and background noise empirically.
    - This method ensures that only relevant audio frames are considered for subsequent processing, enhancing the accuracy of speech recognition.
- **Enhancements for Robustness**:
    - To enhance system robustness in realistic environments, noise suppression and band-pass filtering (300-3400 Hz) techniques are applied pre-feature extraction.
    - Mel-Frequency Cepstral Coefficients (MFCCs), computed from Mel-scaled spectra, capture speech perceptual features and reduce inter-speaker variability. This process improves recognition stability, especially in noisy settings.

## **Bilingual Speech-to-Text Conversion**

The researchers utilize two Vosk offline models for speech-to-text conversion, tailored for English and Arabic, ensuring high accuracy (>95%) on brief drone-related commands. The decoding process, based on the maximum a posteriori (MAP) formulation, considers acoustic likelihood and language model priors for transcription. Additional details include:

- The Arabic model integrates morphological tokenization to handle complexities like inflections and clitics, preventing vocabulary size inflation.
- For English, a compact bigram language model suffices due to the short, predictable nature of command phrases.
- Parallel operation of both models minimizes delays, with subsequent outputs moving to the disambiguation stage for further processing.
- By employing lightweight models independently for English and Arabic, the dual-model strategy optimizes efficiency and coverage without the bulk of multilingual models.
- The Vosk engine's bilingual transcription incorporates script detection and probability scores for output reconciliation, enhancing processing robustness for various command types and language mixing scenarios. This bilingual setup ensures reliable processing before semantic analysis by the Large Language Models (LLMs).

## **LLM-Based Command Selection**

In the LLM-based command selection stage, the transcripts generated by the speech-to-text recognizers undergo processing by a fine-tuned Large Language Model (LLM) such as Gemini, GPT, or DeepSeek families. This stage focuses on three key responsibilities:

- **Language Disambiguation:**
    - Identifying whether the command is in English or Arabic, and filtering out any redundant outputs.

This phase of the process involves leveraging LLMs to refine and interpret the spoken commands, ensuring accurate language disambiguation and improving the efficiency of command selection for real-time UAV control.

## **Translation**

In the context of UAV control, the researchers focus on translating Arabic commands into English to facilitate consistent downstream processing. This translation step plays a crucial role in enabling seamless communication and interaction between human operators and the quadrotor drones.

**Key points included:**

- Ensuring a standardized language input for processing commands effectively.
- Facilitating a smooth transition from Arabic commands to English for better interpretability.
- Enhancing the overall control framework's efficiency by unifying the command language.
- This translation step contributes to the seamless integration of multilingual voice-driven control in real-time UAV operations.

## **Parameter Inference**

The authors discuss the process of extracting structured action intents from inputs for drone control, including inferring missing parameters using default values. Here are the key points included:

- The structured intent I is obtained from input S using the Large Language Model (LLM) f θ.
- An example is given where the Arabic utterance "Ascend two meters forward" is mapped to structured intent I = {ascend: 2 m, forward: 2 m}.
- Equivalent English translations are provided for dialectal or mixed-language phrases to ensure consistency and clarity.
- The choice of LLM impacts system trade-offs: smaller models offer faster responses and lower resource consumption, while larger models handle ambiguity better.
- Free-access models were utilized, proving sufficient for UAV command interpretation within a specific domain.

## **LLM Code Generation and Safety Validation**

The section details the translation of intents into Python code compatible with the pyparrot API and emphasizes safety validation in drone operations:

- Intent translation involves converting high-level actions like "move forward 2 m" into specific function calls with calibrated parameters.
- Relative terms like "go higher" are normalized into absolute increments, ensuring precise control.
- Safety measures include a formalized layer with explicit contracts and bounds on safe operational states constrained by altitude, velocity, ground proximity, and battery charge.
- Safety constraints are based on drone specifications and undergo empirical validation in controlled environments.
- A feasibility function evaluates each action against safety limits; if violated, the system rewrites the command or issues warnings for corrective action.
- Collision prevention primarily relies on ground-contact monitoring due to the absence of obstacle avoidance sensors.
- Battery protection mechanisms trigger safe landings when battery levels drop below 15%, overriding user commands to prevent mid-flight shutdowns.
- Stress tests near critical thresholds confirm stable operation and rule-based fallbacks without compromising responsiveness.
- The validation framework ensures energy-efficient and context-aware UAV operations, mitigating collision risks and energy depletion during missions.

## **Drone Command Execution**

The drone executes validated commands in a sandboxed Python interpreter to prevent system-wide crashes. High-level intents are translated into specific UAV actions, like flying in a particular direction or turning. The command execution process involves:

- Mapping high-level intents to UAV primitives like mambo.fly_direct() or mambo.turn()
- Employing telemetry monitoring to check command completion
- Automatically switching the drone to hover mode and triggering a system reset in case of failures detected through telemetry feedback, ensuring fault tolerance in the face of errors or environmental disturbances.

Execution has a total end-to-end latency of 300 to 500 ms, offering responsiveness suitable for interactive UAV control while maintaining a lightweight system compared to cloud-based alternatives.

## **Experimental Platform**

The experimental platform for real-time UAV control using multilingual voice commands involves an edge-cloud hybrid architecture to ensure efficient operation:

- The architecture is designed to support offline processing for speech recognition and control, combining edge device execution for real-time tasks with remote large language model (LLM) inference for high-level reasoning.
- Experimental evaluation included testing three LLM models (Gemini, GPT, DeepSeek) to analyze performance, with the Gemini model selected for autonomous demonstration on a Parrot Mambo drone due to its free API access and low latency.
- The Parrot Mambo drone utilized onboard sensors (IMU, accelerometer, gyroscope, ultrasonic) for stable altitude estimation, with external sensor fusion at different frequencies to minimize drift.
- Testing was conducted on a workstation with an Intel i7 CPU, 16 GB RAM, and an NVIDIA GTX GPU, connected to the drone via Wi-Fi to assess latency, recognition accuracy, and safety across various environments.
- Communication between the Parrot Mambo drone and the workstation was facilitated through the drone's proprietary Wi-Fi protocol to ensure stable connectivity for indoor testing.
- The primary goal of the experiments was to showcase the feasibility of bilingual voice control with low latency rather than focusing on extensive statistical benchmarking.

## **Algorithmic Overview**

The proposed framework's workflow is outlined in Algorithm 1, detailing the transformation of continuous audio streams into validated drone commands for robust and low-latency performance.

**Key Points:**

- The processing stages are organized as a pipeline to ensure real-time responsiveness.
- Intermediate results are promptly passed to subsequent modules without waiting for full sequences, reducing idle time and optimizing computational efficiency.

The algorithm initiates with continuous audio acquisition and buffering, followed by bilingual speech recognition for English and Arabic in parallel. Transcriptions are fed to a large language model (LLM) for intent extraction, disambiguation, and parameter inference.

The structured command obtained then undergoes a second LLM stage for generating executable Python code aligned with the pyparrot API, coupled with a safety-validation module to enforce operational constraints.

**Further Steps Include:**

- Execution of validated commands on the UAV.
- Telemetry-based feedback mechanisms for error recovery, including automatic hover and system reset as needed.

## **Case Study: Code Generation**

The code generation process in the voice-controlled drone system is illustrated through four scenarios using various LLMs models like Gemini, GPT, and DeepSeek:

- The system successfully processes valid English/Arabic commands, ranging from simple instructions like "Take off" to more complex multi-step commands, ensuring accurate interpretation and execution.
- Speech is transcribed by Vosk, the first LLM extracts structured drone actions, and the second LLM generates executable drone control code for action by the Parrot Mambo quadcopter.
- The system showcases its capability to handle English, Arabic, and mixed-language commands, filter out irrelevant inputs, and break down multi-step commands into precise sequential drone actions, enhancing the natural language-based control robustness.

## **Case Study: Gemini Execution**

In this case study, the researchers selected the longest query from a previous scenario to demonstrate the complete sequence of command execution. They intentionally included a failed command to showcase that the drone stays grounded when error messages are encountered.

- The integration of natural language processing and autonomous aerial control allows for intuitive interaction between humans and drones.
- Using the LLM (Gemini), human instructions like "Take off go up one meter do a left flip then sleep" are translated into drone commands, emphasizing the potential of merging speech, code generation, and robotics for intelligent UAV operation.
- The system can interpret various queries with similar structures, demonstrating flexibility in executing commands.
- Modifications in parameters, like adjusting the distance from one meter to three meters, result in the drone following the same operations but at a different altitude.
- The system can process commands expressed in different languages, dialects, or even through code-switching.

The case study also illustrates the robustness of the natural language interface:

- Commands remain executable despite variations in wording, measurements, or linguistic styles, showcasing the system's adaptability.
- The workflow of the system involves providing a spoken query to the language model, and if the input does not match a predefined drone control command, an error message is returned, and the drone remains grounded.
- This safety measure prevents unintended drone behavior when inputs do not align with the expected control vocabulary.
- Examples in English, Arabic, and mixed languages show how invalid commands lead to the drone staying grounded, ensuring strict command validation for safe and reliable drone execution.

## **Models Comparison**

The comparison of large language models (LLMs) for generating drone control code highlights key differences in safety, precision, and usability among three major models: GPT, Gemini, and DeepSeek. Here are the key points included in the comparison:

- **Evaluation Process**:
    - Experts from the Aeronautical Sciences Laboratory and computer science specialists evaluated code files generated by each model based on specific criteria.
    - Independent reviews by aeronautical engineering and computer science experts ensured evaluation consistency using a standardized rubric.
- **Criteria Considered**:
    - The evaluation focused on six weighted criteria: code structure, safety mechanisms, error handling, movement precision, connection reliability, and documentation clarity.
    - Inter-rater reliability assessment showed strong agreement among evaluators.
- **Model Suitability and Integration**:
    - Task-driven model selection: GPT for safety-critical code, Gemini for precision movement, and DeepSeek for user interaction.
    - Framework supports hybrid or sequential model integration based on the task requirements.
- **Key Model Characteristics**:
    - **GPT**:
        - Prioritized for safety-critical systems with robust safety features.
        - Optimal for production UAV systems but favors stability over performance.
    - **Gemini**:
        - Strong in precision movement control with unique navigation capabilities.
        - Faces challenges with API understanding leading to execution errors.
    - **DeepSeek**:
        - Emphasizes user experience with multilingual support and engaging interfaces.
        - Lacks essential safety mechanisms but excels in educational value.
- **Hierarchy for UAV Applications**:
    - GPT recommended for safety-critical systems, Gemini for precision research post-import corrections, and DeepSeek for educational purposes and prototyping.

The evaluation underscores the distinct strengths and weaknesses of each model, providing insights into their applicability in different UAV control scenarios.

## **Evaluation Protocol and Reproducibility**

The evaluation of LLMs in this study was carefully designed for reproducibility and quantitative accuracy:

- **Unified Configuration:**
    - Conducted evaluations under a consistent setup using pyparrot library v1.6.2, Parrot Mambo firmware v2.1.0, and identical Wi-Fi network conditions for all tests.
- **Model Evaluation Criteria:**
    - Evaluated each model using its respective API version available between September and October 2025.
    - Employed the same prompt template and command set for all models to maintain input uniformity.
- **System Robustness Metric:**
    - Introduced a metric (Mf) to measure system robustness based on unsafe code generations, critical execution errors, and total evaluated commands.
- **Resilience Assessment:**
    - Recorded average recovery time (Tr) and frequency of emergency landings (Fe) to evaluate resilience across LLMs.
- **Performance Insights:**
    - GPT exhibited the lowest unsafe code rate (Eu/N = 0.03) and fastest recovery time (Tr = 0.7 s).
    - Gemini showed intermediate robustness with occasional API import inconsistencies.
    - DeepSeek's performance varied due to non-standard method generation.
- **Key Findings:**
    - GPT demonstrated superior safety margins.
    - Highlighted the importance of prompt control and SDK alignment across models for consistent performance.
- **Visualizations:**
    - Comparative visualizations of metrics are presented in Figure to illustrate the performance differences among LLMs.

## **Conclusions**

The study introduces a new bilingual voice-controlled UAV framework that seamlessly combines offline speech recognition, large language models (LLMs), and real-time control mechanisms:

- Unlike previous systems, this architecture operates entirely offline, maintaining semantic depth and contextual reasoning through a dual-pass LLM interpretation pipeline.
- By integrating Vosk bilingual STT engine, Gemini-based command reasoning, and PyParrot actuation, the framework effectively links human linguistic intent with UAV behavior.
- Experimental findings show a 95% speech recognition accuracy and 300-500 ms end-to-end latency, endorsing its suitability for real-time flight control.
- The framework successfully processes complex instructions in English and Arabic, striking a balance between responsiveness, safety, and linguistic adaptability.
- A significant contribution is the demonstration of offline LLM-based natural language understanding for bilingual and code-switched commands, fostering human-centered UAV autonomy.

Further advancements and future research directions include:

- Expanding Arabic dialectal and phonetic coverage.
- Optimization for real-time reasoning to achieve latency below 200 ms.
- Defining benchmarks for linguistic coverage and system responsiveness.
- Exploring visual feedback integration for closed-loop, multimodal control and situational awareness.
- The framework sets the stage for integration with multimodal large language models (MLLMs) for enhanced environmental perception through linguistic, visual, and sensory understanding.
- Ongoing studies by Yu et al. and Hang and Ho support the potential of this direction.

## **Acknowledgments**

The researchers express gratitude to Princess Nourah bint Abdulrahman University for their support through the Researchers Supporting Project. The project number (PNURSP2025R196) is specifically acknowledged for its contribution to this research endeavor.