# #4, Taking Flight with Dialogue: Enabling Natural Language Control for PX4-based Drone Agent

[Complete Summary](#4,%20Taking%20Flight%20with%20Dialogue%20Enabling%20Natural%20L/Complete%20Summary%2038470de8b99080ccbf2df9d69b654a9a.md)

- **Journal:** The uploaded version is an **arXiv preprint.**
- **Year:** 2025.
- **Authors:** Shoon Kit Lim, Melissa Jia Ying Chong, Jing Huey Khor, and Ting Yang Ling.

## **Problem they are solving:**

The paper tries to make natural-language drone navigation accessible using locally hosted, open-source language and vision models rather than expensive closed-source systems. A user should be able to describe a target, after which a drone uses an LLM to generate movement commands and a VLM to determine whether the target is visible. The authors specifically study whether small open-source models can guide a PX4 quadcopter through a cluttered environment, locate a visible object, and approach it. Importantly, this is **not a swarm paper** and not a broad autonomous mission-planning system. It controls one quadcopter, using only simple turn and forward/backward movement commands.

## **Methodology:**

The authors build a ROS 2 agent framework connecting the PX4 flight stack with locally hosted models served through Ollama. The system contains a Visual Question Answering node, a path-planning node, and a map-encoder node. The VQA node receives a camera image and a question such as whether a drone or humanoid robot is visible, then returns a text response. The path-planning node receives the current pose and target location and converts the desired movement into PX4-compatible actions. The map encoder combines the UAV’s pose and semantic information extracted from images into text-based context for the agent. ROS 2 transports information among the models, perception components, planner, simulator, and drone.

The agent’s mission is represented as a sequence of UAV states from its initial state to a terminal state. At every step, the PX4 autopilot updates the drone’s state using the action selected by the agent. The LLM chooses that action from the current task context, the five most recent valid actions, and the VLM’s interpretation of the current camera image. The two available motion primitives are extremely restricted: `Turn(θ)`, where the drone can yaw at most 90 degrees left or right, and `Move(d)`, where it can travel at most 3 metres forward or backward. The drone flies at a fixed altitude of approximately 1 metre, so the evaluated navigation is effectively two-dimensional rather than full 3D flight.

Each mission begins with the drone entering PX4 `OFFBOARD` mode, taking off, and ascending to its nominal altitude. A human then provides the object category to locate and a textual description of the goal coordinate through a ROS 2 message. The LLM repeatedly decides whether to turn or move, while the VLM answers whether the requested target is visible. The mission succeeds when the UAV reaches within 0.5 metres of the target. A collision, leaving the allowed boundary, or exceeding the time or inference-step limit counts as failure.

## **Simulation and physical setup:**

Simulation uses NVIDIA Isaac Sim as the rendering and physics engine together with PX4 Software-In-The-Loop. The framework can use preset environments such as an outdoor car park, hospital, warehouse, co-working space, and data centre, although the main validation uses a digital twin of the indoor test arena. The simulation workstation runs Ubuntu 22.04 with an RTX 3080 Ti 16 GB GPU. A second Ubuntu workstation with the same GPU hosts Ollama remotely over the local network.

The physical drone is a custom quadcopter equipped with an NVIDIA Jetson Orin Nano, a ZED Mini stereo camera for visual-inertial odometry, and a Pixhawk 6C Mini flight controller. The indoor flying enclosure measures 7 m × 4.5 m × 2.2 m and contains cardboard-box obstacles. Obstacles are 1.5 m tall, their horizontal size is scaled around the drone’s 0.56 m wingspan, and at least 1 m separates the target from the obstacles. During real flight, a human safety operator can switch the UAV into PX4 `POSITION` mode, causing it to hover, if a crash appears likely. **Figure 2 on page 3** shows the physical quadcopter, its digital twin, the indoor arena, and the simulated arena. **Figure 3 on page 3** shows the top-down operational area and its occupancy-grid representation.

## **Models tested:**

Four LLM families generate navigation commands: Gemma 3 4B, Qwen 2.5 3B, Llama 3.2 3B, and DeepSeek-LLM 7B. Three VLM families process the camera images: Gemma 3 12B, Llama 3.2 Vision 11B, and LLaVA 1.6 7B. Proprietary systems such as GPT-4 and Claude were deliberately excluded because the goal was local open-source deployment. Larger models, alternative quantizations, and more model variants could not be tested because of GPU-memory limitations.

## **Experimental procedure:**

Every LLM–VLM pairing is evaluated over 20 episodes, producing 240 model-pair episodes in total. The target and obstacle placements are randomized within the operational boundary, while the UAV begins at the same starting point. The drone has at most 20 inference steps to finish. Model temperature is fixed at 0.2 to make outputs more deterministic. Internal chain-of-thought output is suppressed, built-in conversation memory is disabled, and the five most recent valid commands are manually supplied to the next LLM prompt. The VLM is asked about three object classes: humanoid robots, drones, and quadcopters.

## **Performance metrics:**

The LLM metric is **valid-command rate**. A response is valid only when it follows the required `Turn` or `Move` format and stays within the permitted parameter range. Extra explanations, markdown, symbols, reasoning, or AI disclaimers make the response invalid. The authors do not score whether the chosen turn angle or movement distance is mathematically optimal or even accurate.

The VLM metric is labelled “valid detections,” but it mainly measures whether the model returns the required binary `Yes` or `No` format. The paper explicitly states that actual object-detection correctness is not separately evaluated, so the reported 97–100% values should not be interpreted as true detection accuracy. Mission success is the percentage of episodes in which the complete LLM–VLM system reaches within 0.5 m of the target before colliding, leaving the boundary, or timing out.

## **Main results:**

Gemma 3, Qwen 2.5, and Llama 3.2 generate valid movement commands in 100% of their responses. DeepSeek-LLM achieves only 38% command validity because it often produces explanations or erratic reasoning instead of the required command format. Gemma 3 Vision and Llama 3.2 Vision produce valid binary answers in 100% of cases, while LLaVA reaches approximately 97–98%.

Despite these high format-validity numbers, complete navigation performance is low:

| LLM | Gemma 3 VLM | Llama 3.2 Vision | LLaVA 1.6 |
| --- | --- | --- | --- |
| Gemma 3 | **40%** | 30% | 30% |
| Qwen 2.5 | 30% | **35%** | 30% |
| Llama 3.2 | 30% | 30% | **35%** |
| DeepSeek-LLM | 0% | **5%** | 0% |

The best pairing is Gemma 3 as both LLM and VLM, with only **40% mission success**. Qwen and Llama pairings generally achieve 30–35%. DeepSeek is effectively unusable, reaching at most 5%. Because every pairing was tested on only 20 episodes, the small differences among the Gemma, Qwen, and Llama combinations may simply be random variation and are not shown to be statistically significant.

## **Why missions failed despite valid outputs:**

A syntactically valid movement command can still be a bad movement command. Models sometimes choose distances or angles that cause the UAV to undershoot or overshoot the required 0.5 m target radius. Low temperature also causes some LLMs to repeat nearly identical commands instead of exploring a different route. The VLM can produce false positives or false negatives, especially when obstacles block the camera’s view. Therefore, a model can achieve 100% command-format validity and a VLM can always return `Yes` or `No`, while the combined system still fails most missions.

The paper observes that mission success improves when the camera has a clear and unobstructed line of sight to the target. When the target is hidden behind randomly placed obstacles, performance decreases. Gemma is selected for the physical experiment because it achieved the highest simulated success and tends to generate smaller, more conservative movements, reducing collision risk. **Figure 4 on page 4** shows a successful real-flight sequence in which the UAV turns, detects another drone, and moves toward it.

## **Novelty:**

The main contribution is not a new navigation algorithm. It is an open-source integration framework combining PX4, ROS 2, Isaac Sim, Ollama-hosted LLMs and VLMs, visual question answering, and a custom physical quadcopter. Previous natural-language PX4 demonstrations often depended on OpenAI models and simple command translation. This work investigates whether small, locally hosted models can jointly interpret language and images while issuing constrained PX4 navigation actions. It also includes both simulation and a physical demonstration, addressing the common weakness of UAV language-navigation papers that remain simulation-only.

## **Limitations:**

The system controls only one drone, not a swarm. The operator provides a target category and goal-coordinate description, so this is not truly open-world exploration with no target information. The target is selected from visually obvious classes, and the agent only needs to approach it. The UAV flies at fixed altitude and can only yaw or move along its body’s forward axis, leaving most quadcopter maneuverability unused. It cannot directly strafe, adjust altitude during navigation, or exploit omnidirectional movement.

The reported VLM metric tests output formatting more than actual visual accuracy. LLM evaluation tests command syntax but not whether the angle and distance are geometrically correct. Mission success reaches only 40% at best. Every pairing uses only 20 episodes, limiting statistical confidence. The work does not report end-to-end latency, token usage, path length, trajectory optimality, control error, energy use, or inference speed. There is no comparison with A*, another classical path planner, or a non-LLM navigation baseline. There is also no ablation examining conversational history, system prompts, recent-command history, or few-shot examples.

The physical and robotic coordinate conventions differ: PX4 uses North-East-Down, while ROS usually uses East-North-Up, so transformations are needed to align commands correctly. Camera images are transmitted as RGB8 even though some models may have been trained on BGR-style representations. Simulation includes sensor and control noise through domain randomization but does not reproduce motion blur, exposure problems, electronic-shutter artifacts, or all other real UAV imaging effects. The Ollama inference server is a separate RTX 3080 Ti workstation, so the complete intelligence stack is not actually running onboard the Jetson.

## **Research gap:**

Most embodied AI research focuses on wheeled robots, manipulators, quadrupeds, or humanoids. Existing UAV language-navigation research often depends on proprietary cloud models, remains simulation-only, or studies benchmark datasets without demonstrating control of a physical PX4 platform. This paper addresses the gap by providing a locally hosted, open-source, ROS-based framework tested in both Isaac Sim and a custom real quadcopter. However, it does not solve robust aerial perception or navigation; instead, it demonstrates how difficult even a simple object-approach mission remains for current small LLM–VLM combinations.

## **Future scope:**

The authors suggest adding a dedicated object detector such as YOLO or DINO instead of relying entirely on binary VLM questioning. They propose building UAV-specific datasets and improving models through reinforcement learning from human feedback, knowledge distillation, and domain-specific training. Their longer-term goal is a single end-to-end Vision–Language–Action model with fewer than one billion parameters, capable of running fully at the edge with low latency and little or no cloud dependence. Other obvious extensions include full 3D control, better obstacle avoidance, actual onboard inference, longer memory, motion-blur training, path-optimality evaluation, larger physical environments, more target classes, and real search missions where the target location is unknown.

## **Keywords:**

PX4, UAV, ROS 2, natural-language drone control, LLM, VLM, embodied agent, Ollama, Isaac Sim, visual navigation, object search, open-source robotics, sim-to-real deployment.

## **Tools/dataset used:**

PX4 Autopilot, ROS 2, `ros-agents`, Ollama, NVIDIA Isaac Sim, PX4 SITL, Jetson Orin Nano, ZED Mini, Pixhawk 6C Mini, RTX 3080 Ti workstations, Gemma 3, Qwen 2.5, Llama 3.2, DeepSeek-LLM, Llama 3.2 Vision, and LLaVA 1.6. No external training dataset is introduced. Evaluation uses procedurally randomized target and obstacle placements in the simulated digital twin and a physical indoor arena.

## **How it is better—or not—than previous work:**

It is more open and locally deployable than ChatGPT-dependent PX4 demonstrations, more physically grounded than papers evaluated only on aerial-language datasets, and more modular than a single closed model because users can swap LLM and VLM families through Ollama. The physical quadcopter demonstration is also valuable. However, it is far less capable than a conventional navigation stack in reliability, geometric planning, and safety. It achieves only 40% success on a simple single-drone object-approach task, does not evaluate actual VLM detection accuracy properly, and restricts the aircraft to two primitive actions. The framework is therefore best viewed as an early proof of concept for open-source language-and-vision integration, not a dependable autonomous drone controller.

## **Possible real-world application:**

The authors primarily identify routine industrial inventory tracking and equipment inspection. A user could ask a drone to locate a visible piece of equipment, fly toward it, and capture imagery without entering exact low-level commands. Similar applications might include finding labelled warehouse assets, inspecting machinery, locating another robot, or navigating toward a clearly identifiable object in a controlled indoor area. Considerably stronger perception, path planning, safety validation, and mission reliability would be needed before deployment in cluttered industrial spaces or outdoor search-and-rescue operations.