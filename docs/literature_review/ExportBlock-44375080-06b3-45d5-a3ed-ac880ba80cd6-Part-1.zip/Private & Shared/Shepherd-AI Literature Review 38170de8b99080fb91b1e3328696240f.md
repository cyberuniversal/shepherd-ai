# Shepherd-AI Literature Review

[#1, TACOS: Task Agnostic Coordinator of a Multi-Drone System](Shepherd-AI%20Literature%20Review/#1,%20TACOS%20Task%20Agnostic%20Coordinator%20of%20a%20Multi-Dro%2038170de8b990800d8372c00d4b1c726a.md)

[#2, Swarm-Steward: Scalable and Reliable Natural-Language Coordination of Autonomous Aerial](Shepherd-AI%20Literature%20Review/#2,%20Swarm-Steward%20Scalable%20and%20Reliable%20Natural-La%2038170de8b99080219a1dee51a9fc8792.md)

[#3, Say the Mission, Execute the Swarm: Agent-Enhanced LLM Reasoning in the Web-of-Drones](Shepherd-AI%20Literature%20Review/#3,%20Say%20the%20Mission,%20Execute%20the%20Swarm%20Agent-Enhan%2038270de8b990802b83fbf5e9402655d7.md)

[#4, Taking Flight with Dialogue: Enabling Natural Language Control for PX4-based Drone Agent](Shepherd-AI%20Literature%20Review/#4,%20Taking%20Flight%20with%20Dialogue%20Enabling%20Natural%20L%2038470de8b99080e194d6febbaa557b1c.md)

[#5, Leveraging Large Language Models for Real-Time UAV Control](Shepherd-AI%20Literature%20Review/#5,%20Leveraging%20Large%20Language%20Models%20for%20Real-Time%2038570de8b99080dc8b7bc93984fcfd66.md)

[#6, Air-Ground Collaboration for Language-Specified Missions in  Unknown Environments](Shepherd-AI%20Literature%20Review/#6,%20Air-Ground%20Collaboration%20for%20Language-Specifie%2038670de8b99080bd8029f4918be06897.md)

[#7, Translating Natural Language to Planning Goals  with Large-Language Models](Shepherd-AI%20Literature%20Review/#7,%20Translating%20Natural%20Language%20to%20Planning%20Goals%2038770de8b99080a89734c67114474436.md)

[#8, CommandSwarm: Safety-Aware Natural Language-to-Behavior-Tree Generation for Robotic  Swarms](Shepherd-AI%20Literature%20Review/#8,%20CommandSwarm%20Safety-Aware%20Natural%20Language-to-%2038770de8b99080368ee0e91548f32444.md)

[**#9, Visual Language Maps for Robot Navigation**](Shepherd-AI%20Literature%20Review/#9,%20Visual%20Language%20Maps%20for%20Robot%20Navigation%2038770de8b99080aeb352d83fdbe1d1eb.md)

[#10, **Towards Natural Language-Guided Drones: GeoText-1652 Benchmark with Spatial Relation Matching**](Shepherd-AI%20Literature%20Review/#10,%20Towards%20Natural%20Language-Guided%20Drones%20GeoTex%2038870de8b99080adba13de50ff8e3d68.md)

[#11, **SkySim: A ROS2-based Simulation for Natural Language Control of Drone Swarms**](Shepherd-AI%20Literature%20Review/#11,%20SkySim%20A%20ROS2-based%20Simulation%20for%20Natural%20La%2038870de8b99080529d15f9470a4c9790.md)

[**#12, Comparative Analysis of Centralized and Distributed Multi-UAV Task Allocation Algorithms: A Unified Evaluation Framework**](Shepherd-AI%20Literature%20Review/#12,%20Comparative%20Analysis%20of%20Centralized%20and%20Distr%2038870de8b990807ba94cc9ed79f2f5ef.md)

[#13, PROGPROMPT: Generating Situated Robot Task Plans
using Large Language Models](Shepherd-AI%20Literature%20Review/#13,%20PROGPROMPT%20Generating%20Situated%20Robot%20Task%20Pla%2038870de8b990802a9107cf1310864cd2.md)

[#14, **GenSwarm: Scalable Multi-Robot Code-Policy Generation and Deployment via Language Models**](Shepherd-AI%20Literature%20Review/#14,%20GenSwarm%20Scalable%20Multi-Robot%20Code-Policy%20Gen%2038a70de8b99080f6bfb4e52e2d23ebaa.md)

[**#15, Hierarchical Language Models for Semantic Navigation and Manipulation in an Aerial-Ground Robotic System**](Shepherd-AI%20Literature%20Review/#15,%20Hierarchical%20Language%20Models%20for%20Semantic%20Nav%2038a70de8b9908044b582cea75927ae0a.md)